Controlled Minecraft1.12.2/Cleanroom Lightbench results.
See publication README, protocol and manifest. All timestamps in raw reports are UTC.
Warmup files are retained and must not be counted as scored trials.
Invalid light/capped workloads are not valid speed scores. No equal-output ranking where hashes differ.
Render callback intervals are not presented FPS; default client loaded chunk counts differ.
No Minecraft saves, mod binaries, account files or full game logs are distributed in this bundle.
