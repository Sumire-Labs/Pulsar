package com.sumirelabs.hotpathaudit;
import com.google.gson.GsonBuilder;
import com.sumirelabs.pulsar.light.WorldLightManager;
import com.sumirelabs.pulsar.world.PulsarWorld;
import java.nio.file.*;import java.util.*;
import net.minecraft.block.Block;import net.minecraft.block.material.Material;import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;import net.minecraft.util.math.BlockPos;import net.minecraft.world.*;
import net.minecraftforge.event.RegistryEvent;import net.minecraftforge.fml.common.Mod;import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
@Mod.EventBusSubscriber(modid="hotpathaudit")
public final class BatchSmoke {
 static final Block NESTED=new CallbackBlock("batch_nested",0),BARRIER=new CallbackBlock("batch_barrier",1),THROWING=new CallbackBlock("batch_throwing",2);
 @SubscribeEvent public static void register(RegistryEvent.Register<Block> event){event.getRegistry().registerAll(NESTED,BARRIER,THROWING);}
 private static final class Expected extends RuntimeException {}
 private static final class CallbackBlock extends Block {
  final int mode;
  CallbackBlock(String name,int mode){super(Material.ROCK);this.mode=mode;setRegistryName("hotpathaudit",name);setLightLevel(1.0F);}
  @Override public void onBlockAdded(World world,BlockPos pos,IBlockState state){
   if(world.isRemote)return;WorldLightManager m=((PulsarWorld)world).pulsar$getLightManager();int depth=depth(m);
   if(depth>=0&&depth!=1)throw new IllegalStateException("callback scope depth "+depth);
   if(mode==0){world.setBlockState(pos.east(),Blocks.GLOWSTONE.getDefaultState(),16);world.setBlockState(pos.north(),Blocks.GLOWSTONE.getDefaultState(),16);world.setBlockState(pos.up(32),Blocks.GLOWSTONE.getDefaultState(),16);world.setBlockState(pos.up(48),Blocks.GLOWSTONE.getDefaultState(),16);if(depth>=0&&depth(m)!=1)throw new IllegalStateException("nested scope leak");}
   else {m.queueBlockChange(pos.getX(),pos.getY(),pos.getZ());if(mode==1){drain((WorldServer)world);expect((WorldServer)world,pos,15);if(depth>=0&&depth(m)!=1)throw new IllegalStateException("barrier closed scope");}else throw new Expected();}
  }
 }
 static int depth(WorldLightManager m){try{var f=m.getClass().getDeclaredField("changeBatch");f.setAccessible(true);Object b=f.get(m);var d=b.getClass().getDeclaredField("depth");d.setAccessible(true);return d.getInt(b);}catch(NoSuchFieldException baseline){return -1;}catch(Exception e){throw new IllegalStateException(e);}}
 static void closed(WorldLightManager m)throws Exception{if(depth(m)<0)return;var f=m.getClass().getDeclaredField("changeBatch");f.setAccessible(true);Object b=f.get(m);var o=b.getClass().getDeclaredField("owner");o.setAccessible(true);if(depth(m)!=0||o.get(b)!=null)throw new IllegalStateException("scope leaked");}
 static void drain(WorldServer w){WorldLightManager m=((PulsarWorld)w).pulsar$getLightManager();long deadline=System.nanoTime()+10_000_000_000L;while(m.hasUpdates()){if(System.nanoTime()>deadline)throw new IllegalStateException("callback drain timeout");Thread.yield();}}
 static void expect(WorldServer w,BlockPos p,int n){int actual=w.getChunk(p).getLightFor(EnumSkyBlock.BLOCK,p);if(actual!=n)throw new IllegalStateException("Block light "+p+": "+actual+" expected "+n);}
 public static void run(WorldServer w)throws Exception{
  for(int z=1247;z<=1253;z++)for(int x=1247;x<=1253;x++)w.getChunk(x,z);drain(w);
  WorldLightManager m=((PulsarWorld)w).pulsar$getLightManager();BlockPos p=new BlockPos(20015,8,20015);List<String> cases=new ArrayList<>();
  w.setBlockState(p,NESTED.getDefaultState(),16);closed(m);drain(w);expect(w,p,15);expect(w,p.east(),15);expect(w,p.north(),15);expect(w,p.up(32),15);expect(w,p.up(48),15);expect(w,p.west(),14);cases.add("nested_cross_chunk");
  w.setBlockState(p,Blocks.AIR.getDefaultState(),16);w.setBlockState(p.east(),Blocks.AIR.getDefaultState(),16);w.setBlockState(p.north(),Blocks.AIR.getDefaultState(),16);w.setBlockState(p.up(32),Blocks.AIR.getDefaultState(),16);w.setBlockState(p.up(48),Blocks.AIR.getDefaultState(),16);drain(w);expect(w,p,0);
  w.setBlockState(p,BARRIER.getDefaultState(),16);closed(m);drain(w);expect(w,p,15);cases.add("barrier_inside_callback");w.setBlockState(p,Blocks.AIR.getDefaultState(),16);drain(w);
  boolean caught=false;try{w.setBlockState(p,THROWING.getDefaultState(),16);}catch(Expected e){caught=true;}
  if(!caught)throw new IllegalStateException("expected exception did not propagate");closed(m);drain(w);expect(w,p,15);cases.add("exception_finally_publication");
  w.setBlockState(p,Blocks.AIR.getDefaultState(),16);closed(m);drain(w);expect(w,p,0);cases.add("edit_after_exception");
  w.getChunk(p).setBlockState(p,Blocks.GLOWSTONE.getDefaultState());drain(w);expect(w,p,15);cases.add("direct_chunk_fallback");w.setBlockState(p,Blocks.AIR.getDefaultState(),16);drain(w);
  BlockPos high=p.up(32);w.setBlockState(high,Blocks.GLOWSTONE.getDefaultState(),16);drain(w);expect(w,high,15);expect(w,high.east(),14);w.setBlockState(high,Blocks.AIR.getDefaultState(),16);drain(w);expect(w,high,0);cases.add("new_section_materialization");
  Map<String,Object> report=new LinkedHashMap<>();report.put("valid",true);report.put("batch_scope_present",depth(m)>=0);report.put("cases",cases);
  Path out=w.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/batch-callbacks.json");Files.createDirectories(out.getParent());Files.writeString(out,new GsonBuilder().setPrettyPrinting().create().toJson(report));
 }
}
