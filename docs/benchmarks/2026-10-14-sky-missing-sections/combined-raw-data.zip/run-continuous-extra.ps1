$ErrorActionPreference='Stop'
$root='E:\Github\pulsar-submission-implementation-20261014'
$py='C:\Users\s12kuma01\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$lock=[IO.File]::Open("$root\runner.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try{
 $orders=@(@('baseline','candidate'),@('candidate','baseline'))
 for($rep=3;$rep -le 4;$rep++){
  foreach($variant in $orders[$rep-3]){
   $run="continuous-r$rep-$variant"
   @{status='continuous-confirmation';next=$run}|ConvertTo-Json|Set-Content "$root\progress.json"
   & "$root\run.ps1" -Engine $variant -Run $run -Mode tps -Command 'lightbench tps 2048 5'
   & $py "$root\tools\validate_run.py" "$root\runs\$run"
   if($LASTEXITCODE -ne 0){throw "Invalid $run"}
  }
 }
 @{status='measurements-complete'}|ConvertTo-Json|Set-Content "$root\progress.json"
}finally{$lock.Dispose()}
