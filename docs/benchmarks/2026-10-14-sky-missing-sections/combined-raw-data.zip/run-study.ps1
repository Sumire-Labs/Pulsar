$ErrorActionPreference='Stop'
$root='E:\Github\pulsar-submission-implementation-20261014'
$py='C:\Users\s12kuma01\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$lock=[IO.File]::Open("$root\runner.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
function RunCase($variant,$run,$mode,$command){
 @{status='measuring';next=$run;updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\progress.json"
 if(-not(Test-Path "$root\runs\$run\status.json")){& "$root\run.ps1" -Engine $variant -Run $run -Mode $mode -Command $command}
 & $py "$root\tools\validate_run.py" "$root\runs\$run"
 if($LASTEXITCODE -ne 0){throw "Invalid $run"}
}
try{
 foreach($variant in @('candidate','baseline')){
  RunCase $variant "callbacks-$variant" audit 'hotpathaudit batch'
  RunCase $variant "shapes-$variant" audit 'hotpathaudit'
  RunCase $variant "generation-$variant" gen 'lightbench gen 8 1 8'
  RunCase $variant "probe-$variant" updates 'lightbench updates 10000 10000'
 }
 $orders=@(@('baseline','candidate','starlight'),@('candidate','baseline','starlight'),@('starlight','baseline','candidate'),@('starlight','candidate','baseline'))
 for($rep=1;$rep -le 4;$rep++){
  foreach($variant in $orders[$rep-1]){RunCase $variant "blocks-r$rep-$variant" updates 'lightbench blockupdates 5000 10000'}
  $reverse=@($orders[$rep-1]);[array]::Reverse($reverse)
  foreach($variant in $reverse){RunCase $variant "sky-r$rep-$variant" updates 'lightbench updates 2000 1000'}
 }
 $pairs=@(@('baseline','candidate'),@('candidate','baseline'))
 for($rep=1;$rep -le 2;$rep++){
  foreach($variant in $pairs[$rep-1]){RunCase $variant "continuous-r$rep-$variant" tps 'lightbench tps 2048 5'}
  foreach($variant in $pairs[$rep-1]){RunCase $variant "long-r$rep-$variant" updates 'lightbench updates 10000 10000'}
 }
 @{status='measurements-complete';updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\progress.json"
}catch{
 @{status='needs-investigation';failure=$_.Exception.Message}|ConvertTo-Json|Set-Content "$root\progress.json";throw
}finally{$lock.Dispose()}
