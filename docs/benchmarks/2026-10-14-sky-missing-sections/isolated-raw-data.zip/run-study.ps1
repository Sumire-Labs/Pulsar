$ErrorActionPreference='Stop'
$root='E:\Github\pulsar-sky-shortcut-20261014'
$py='C:\Users\s12kuma01\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$lock=[IO.File]::Open("$root\runner.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
function RunCase($variant,$run,$mode,$command){
 @{status='measuring';next=$run;updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\progress.json"
 if(-not(Test-Path "$root\runs\$run\status.json")){& "$root\run.ps1" -Engine $variant -Run $run -Mode $mode -Command $command}
 & $py "$root\tools\validate_run.py" "$root\runs\$run"
 if($LASTEXITCODE -ne 0){throw "Invalid $run"}
}
try{
 foreach($variant in @('candidate','baseline')){
  RunCase $variant "callbacks-$variant" audit 'hotpathaudit batch'
  RunCase $variant "shapes-$variant" audit 'hotpathaudit'
  RunCase $variant "generation-$variant" gen 'lightbench gen 8 1 8'

 }
 $orders=@(@('baseline','candidate'),@('candidate','baseline'),@('candidate','baseline'),@('baseline','candidate'))
 for($rep=1;$rep -le 4;$rep++){
  foreach($variant in $orders[$rep-1]){RunCase $variant "sky-r$rep-$variant" updates 'lightbench updates 2000 1000'}
  $reverse=@($orders[$rep-1]);[array]::Reverse($reverse)
  foreach($variant in $reverse){RunCase $variant "continuous-r$rep-$variant" tps 'lightbench tps 2048 5'}
  if($rep -le 2){foreach($variant in $orders[$rep-1]){RunCase $variant "blocks-r$rep-$variant" updates 'lightbench blockupdates 5000 10000'}}
 }
 @{status='measurements-complete';updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\progress.json"
}catch{
 @{status='needs-investigation';failure=$_.Exception.Message}|ConvertTo-Json|Set-Content "$root\progress.json";throw
}finally{$lock.Dispose()}
