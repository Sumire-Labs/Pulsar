from pathlib import Path
import json,statistics,math,csv,collections
R=Path(__file__).resolve().parents[1];OUT=R/'analysis';OUT.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
manifest={x['file']:x['sha256'] for x in load(R/'manifest-final.json')['artifacts']}
rows=[];trials=[];environments=[];mods=[];counts=[]
for r in sorted((R/'runs').iterdir()):
 if r.name.startswith(('pilot-','jfr-')) or not (r/'status.json').exists():continue
 assert load(r/'status.json')['valid'],r
 stage=load(r/'stage.json');assert stage['sha256']==manifest[stage['engine_jar']]
 trials.append(dict(run=r.name,engine=stage['engine'],jar=stage['engine_jar'],sha256=stage['sha256']))
 family=r.name.split('-')[0]
 for p in (r/'results').glob('*.json'):
  d=load(p)
  if 'benchmark' not in d:continue
  b=d['benchmark'];mode=b['mode']
  if mode=='updates':
   assert b['preflight']['initial_light_verified'] and b['preflight']['post_measurement_volume_verified']
   if family in ['blocks','sky','long']:
    environments.append(d['environment']);mods.append([m for m in d['mods'] if m['id'] not in ['pulsar','starlight']])
   for phase in b['phases']:
    ss=phase['samples'];assert phase['all_samples_verified'] and len(ss)==b['plan']['measured_pairs'] and all(s['light_verified'] for s in ss)
    vs=sorted(s['completion_nanos'] for s in ss)
    rows.append(dict(run=r.name,family=family,engine=stage['engine'],metric=phase['name'],mean_ns=statistics.mean(vs),p50_ns=statistics.median(vs),p95_ns=vs[math.ceil(len(vs)*.95)-1],p99_ns=vs[math.ceil(len(vs)*.99)-1],submission_mean_ns=statistics.mean(s['submission_nanos'] for s in ss)))
  elif mode=='tps':
   assert b['roof_and_light_verified'] and not b['wall_capped'] and b['rate']==2048
   assert b['requested_ticks']==100 and b['measured_ticks']==100 and b['edits']==204800
   assert b['roof_mismatch_count']==0 and b['light_mismatch_count']==0
   rows.append(dict(run=r.name,family=family,engine=stage['engine'],metric='main_mspt',mean_ns=statistics.mean(b['ticks_nanos'])))
   rows.append(dict(run=r.name,family=family,engine=stage['engine'],metric='post_drain',mean_ns=b['post_run_drain_nanos']))
 p=r/'results/sampled-timing.json'
 if p.exists():
  ss=load(p)['samples'];assert not any(s['overlap'] for s in ss)
  for phase in sorted({s['phase'] for s in ss}):
   s=[x for x in ss if x['phase']==phase]
   counts.append(dict(run=r.name,engine=stage['engine'],phase=phase,n=len(s),sky_extra=sum(x['sky_engines']>1 for x in s),block_extra=sum(x['block_engines']>1 for x in s),work={lane:[dict(signature=k,count=v) for k,v in collections.Counter((x[lane+'engines'],x[lane+'positions'],x[lane+'increase_entries'],x[lane+'decrease_entries']) for x in s).items()] for lane in ['sky_','block_']}))
groups=[]
for key in sorted({(r['family'],r['engine'],r['metric']) for r in rows}):
 rs=[r for r in rows if (r['family'],r['engine'],r['metric'])==key];vs=[r['mean_ns'] for r in rs]
 groups.append(dict(family=key[0],engine=key[1],metric=key[2],jvms=len(rs),median_ns=statistics.median(vs),min_ns=min(vs),max_ns=max(vs),p99_median_ns=statistics.median(r['p99_ns'] for r in rs) if 'p99_ns' in rs[0] else None))
checks=dict(completed_scored_jvms=len(trials),same_native_environment=all(e==environments[0] for e in environments),same_native_non_engine_mods=all(m==mods[0] for m in mods))
assert checks['same_native_environment'] and checks['same_native_non_engine_mods'],checks
result=dict(checks=checks,summary=groups,rows=rows,probes=counts,trials=trials)
(OUT/'results.json').write_text(json.dumps(result,indent=2))
with (OUT/'summary.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
print(json.dumps(checks))
for g in groups:
 if (g['family']=='blocks' and g['metric'] in ['block_place','block_remove']) or (g['family']=='sky' and g['metric'] in ['sky_remove','sky_place']) or g['family']=='continuous':print(g['family'],g['engine'],g['metric'],'n',g['jvms'],'median_us',round(g['median_ns']/1000,2),'range_us',round(g['min_ns']/1000,2),round(g['max_ns']/1000,2))
