from pathlib import Path
import json,sys
from validate_updates import validate
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
r=Path(sys.argv[1]);stage=load(r/'stage.json');assert load(r/'status.json')['valid'],r
obs=load(r/'results/observer.json');assert not obs.get('failure')
if stage['engine']!='starlight':assert obs['pulsar_parallel_worker_count']==10
cmd=stage['command']
if cmd.startswith('lightbench updates') or cmd.startswith('lightbench blockupdates'):
 v=validate(r)
 if r.name=='probe-candidate':
  ss=load(r/'results/sampled-timing.json')['samples']
  assert all(x['sky_engines']==1 and x['block_engines']==1 for x in ss), 'Publication still splits tasks'
 print(json.dumps(v))
elif cmd=='hotpathaudit batch':
 d=load(r/'results/batch-callbacks.json');assert d['valid'] and len(d['cases'])==6
 assert not d['batch_scope_present'];print(r.name,'six callbacks passed')
elif cmd=='hotpathaudit':
 d=load(r/'results/hotpath-audit.json');assert len(d['cases'])==15;print(r.name,'15 shapes passed')
elif cmd.startswith('lightbench gen'):
 ps=list((r/'results').glob('*-gen-audit-*.json'));assert len(ps)==1 and load(ps[0])['valid'];print(r.name,'generation passed')
elif cmd.startswith('lightbench tps'):
 ps=list((r/'results').glob('*-tps-*.json'));assert len(ps)==1
 b=load(ps[0])['benchmark'];assert b['roof_and_light_verified'] and not b['wall_capped'];print(r.name,'continuous edits passed')

if r.name=='probe-baseline':
    root=r.parents[1]
    a=load(root/'runs/shapes-baseline/results/hotpath-audit.json');b=load(root/'runs/shapes-candidate/results/hotpath-audit.json');assert a['cases']==b['cases']
    def hashes(variant):
        d=load(next((root/'runs'/('generation-'+variant)/'results').glob('*-gen-audit-*.json')))
        return {(c['x'],c['z']):{k:v for k,v in c.items() if 'hash' in k or 'sha' in k} for reg in d['regions'] if reg['core_hashes_recorded'] for c in reg['chunks'] if c['role']=='core'}
    a,b=hashes('baseline'),hashes('candidate');assert len(a)==289 and a==b and all(v for v in a.values());print('45 shape snapshots and289 generated-core terrain/light hashes match')
