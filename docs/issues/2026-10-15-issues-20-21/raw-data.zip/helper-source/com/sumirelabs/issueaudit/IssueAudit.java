package com.sumirelabs.issueaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.light.WorldLightManager;
import com.sumirelabs.pulsar.light.engine.LightInfo;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.*;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerChunkMapEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import java.nio.file.*;
import java.util.*;

/** Disposable real-game diagnostics; never included in Pulsar's production jar. */
@Mod(modid="issueaudit",name="Pulsar Issue Audit",version="1",dependencies="required-after:pulsar")
public class IssueAudit {
    public static volatile boolean cornerReady;
    public static volatile int racePhase;
    public static final BlockPos RACE_POS=new BlockPos(20056,80,20056);
    public static final BlockPos WATCH_POS=new BlockPos(20056,80,20024);
    private static java.util.concurrent.locks.Lock raceLock;
    private static PlayerChunkMapEntry raceEntry;
    private static boolean watchProbe;
    private static int watchEventsPending,watchEventsAfter;
    private static WorldServer world;
    private static MinecraftServer server;
    private static final List<BlockPos> sources=new ArrayList<>();
    private static final List<IBlockState> states=new ArrayList<>();
    private static final JsonObject report=new JsonObject();
    private static final JsonArray cases=new JsonArray();
    private static int phase=-1, ticks;
    private static boolean ship,saveLegacy,loadedShip;
    @Mod.EventHandler public void init(net.minecraftforge.fml.common.event.FMLInitializationEvent e){MinecraftForge.EVENT_BUS.register(new IssueClientAudit());}
    @Mod.EventHandler public void start(FMLServerStartingEvent e){
        MinecraftForge.EVENT_BUS.register(this);
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "issueaudit";}
            public String getUsage(ICommandSender s){return "/issueaudit";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer s,ICommandSender sender,String[] a){
                server=s;world=(WorldServer)sender.getEntityWorld();phase=0;ticks=0;ship=a.length>0&&a[0].equals("ship");saveLegacy=Arrays.asList(a).contains("legacy");loadedShip=a.length>0&&a[0].equals("loadedship");
                report.add("cases",cases);report.addProperty("valid",false);
                System.out.println("ISSUE_AUDIT_STARTED");
            }
        });
    }
    @SubscribeEvent public void tick(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||phase<0||++ticks<40)return;
        ticks=0;
        try{
            if(loadedShip){
                switch(phase++){
                    case 0 -> {for(int cx=1246;cx<=1258;cx++)for(int cz=1246;cz<=1258;cz++)world.getChunkProvider().provideChunk(cx,cz);ShipAudit.loaded();}
                    case 1 -> {drain();cases.add(ShipAudit.before(world));}
                    case 2 -> {if(!ShipAudit.clientBeforeDone){phase--;break;}for(int cx=1250;cx<=1254;cx++)for(int cz=1250;cz<=1255;cz++)manager().forceRelightChunk(cx,cz);}
                    case 3 -> {drain();cases.add(ShipAudit.after(world));}
                    case 4 -> {if(ShipAudit.clientAfterDone)finish(null);else phase--;}
                }
                return;
            }
            switch(phase++){
                case 0 -> prepare();
                case 1 -> measure("world-placement");
                case 2 -> beginRace();
                case 3 -> endRace();
                case 4 -> beginExistingWatch();
                case 5 -> endExistingWatch();
                case 6 -> { for(int i=0;i<sources.size();i++)world.setBlockState(sources.get(i),Blocks.AIR.getDefaultState(),18);drain();for(int i=0;i<sources.size();i++)world.getChunk(sources.get(i)).setBlockState(sources.get(i),states.get(i)); }
                case 7 -> measure("direct-chunk-placement");
                case 8 -> {drain();WorldLightManager m=manager();for(int cx=1248;cx<=1256;cx++)for(int cz=1248;cz<=1256;cz++)m.forceRelightChunk(cx,cz);}
                case 9 -> {measure("full-relight");corner();}
                case 10 -> {measureCorner();if(ship)ShipAudit.generate(world);else finish(null);}
                case 11 -> {drain();cases.add(ShipAudit.before(world));if(saveLegacy)ShipAudit.saveLegacy(world,server);}
                case 12 -> {if(!ShipAudit.clientBeforeDone){phase--;break;}for(int cx=1250;cx<=1254;cx++)for(int cz=1250;cz<=1255;cz++)manager().forceRelightChunk(cx,cz);}
                case 13 -> {drain();cases.add(ShipAudit.after(world));}
                case 14 -> {if(ShipAudit.clientAfterDone)finish(null);else phase--;}
            }
        }catch(Throwable t){t.printStackTrace();finish(t);}
    }
    private static WorldLightManager manager(){return ((PulsarWorld)world).pulsar$getLightManager();}
    @SubscribeEvent public void watch(net.minecraftforge.event.world.ChunkWatchEvent.Watch e){
        if(watchProbe&&e.getChunk().x==(WATCH_POS.getX()>>4)&&e.getChunk().z==(WATCH_POS.getZ()>>4)){
            if(raceLock!=null)watchEventsPending++;else watchEventsAfter++;
        }
    }
    private static void beginRace() throws Exception {
        drain();var m=manager();var field=WorldLightManager.class.getDeclaredField("lightingGate");field.setAccessible(true);
        raceLock=((java.util.concurrent.locks.ReentrantReadWriteLock)field.get(m)).writeLock();raceLock.lock();
        world.setBlockState(RACE_POS.down(),Blocks.STONE.getDefaultState(),0);
        world.setBlockState(RACE_POS,states.get(0),0);
        raceEntry=new PlayerChunkMapEntry(world.getPlayerChunkMap(),RACE_POS.getX()>>4,RACE_POS.getZ()>>4);
        raceEntry.addPlayer(server.getPlayerList().getPlayers().get(0));
        JsonObject c=new JsonObject();c.addProperty("name","initial-send-race");c.addProperty("context_pending",m.contextualLight().hasPending(RACE_POS.getX()>>4,RACE_POS.getZ()>>4));
        c.addProperty("already_light_ready",((com.sumirelabs.pulsar.light.PulsarChunk)world.getChunk(RACE_POS)).pulsar$isLightReady());
        c.addProperty("sent_while_pending",raceEntry.sendToPlayers());cases.add(c);racePhase=1;
        System.out.println("ISSUE_AUDIT_RACE "+c);
    }
    private static void endRace(){
        raceLock.unlock();raceLock=null;drain();
        JsonObject c=new JsonObject();c.addProperty("name","initial-send-after-drain");c.addProperty("stored",world.getLightFor(EnumSkyBlock.BLOCK,RACE_POS));c.addProperty("retry_sent",raceEntry.sendToPlayers());cases.add(c);racePhase=2;
        System.out.println("ISSUE_AUDIT_RACE_AFTER "+c);
    }
    private static void beginExistingWatch() throws Exception {
        drain();var m=manager();var field=WorldLightManager.class.getDeclaredField("lightingGate");field.setAccessible(true);
        raceLock=((java.util.concurrent.locks.ReentrantReadWriteLock)field.get(m)).writeLock();raceLock.lock();
        var player=server.getPlayerList().getPlayers().get(0);
        raceEntry=world.getPlayerChunkMap().getEntry(WATCH_POS.getX()>>4,WATCH_POS.getZ()>>4);
        if(raceEntry==null||!raceEntry.containsPlayer(player))throw new IllegalStateException("No live entry for existing-watch test");
        for(var f:PlayerChunkMapEntry.class.getDeclaredFields())if(f.getType()==java.util.List.class){f.setAccessible(true);((java.util.List<?>)f.get(raceEntry)).remove(player);break;}
        world.setBlockState(WATCH_POS.down(),Blocks.STONE.getDefaultState(),0);world.setBlockState(WATCH_POS,states.get(0),0);
        watchProbe=true;raceEntry.addPlayer(player);
        JsonObject c=new JsonObject();c.addProperty("name","existing-entry-watch-race");c.addProperty("watching_while_pending",world.getPlayerChunkMap().isPlayerWatchingChunk(player,WATCH_POS.getX()>>4,WATCH_POS.getZ()>>4));cases.add(c);racePhase=3;
    }
    private static void endExistingWatch(){
        raceLock.unlock();raceLock=null;drain();manager().processDeferredChunkUpdates();
        JsonObject c=new JsonObject();c.addProperty("name","existing-entry-watch-after-drain");c.addProperty("stored",world.getLightFor(EnumSkyBlock.BLOCK,WATCH_POS));c.addProperty("watching_after_drain",world.getPlayerChunkMap().isPlayerWatchingChunk(server.getPlayerList().getPlayers().get(0),WATCH_POS.getX()>>4,WATCH_POS.getZ()>>4));c.addProperty("watch_events_while_pending",watchEventsPending);c.addProperty("watch_events_after_drain",watchEventsAfter);cases.add(c);watchProbe=false;racePhase=4;
    }
    private static void drain(){
        WorldLightManager m=manager();m.publishContextualLight();
        for(int n=0;n<4;n++){
            for(int cx=1248;cx<=1256;cx++)for(int cz=1248;cz<=1256;cz++)m.awaitPendingWork(cx,cz);
            m.publishContextualLight();if(!m.hasUpdates())return;
        }
        if(m.hasUpdates())throw new IllegalStateException("Lighting did not drain");
    }
    private static void prepare(){
        for(int cx=1246;cx<=1258;cx++)for(int cz=1246;cz<=1258;cz++)world.getChunkProvider().provideChunk(cx,cz);
        int i=0;
        for(Block b:ForgeRegistries.BLOCKS){
            if(!b.getClass().getName().equals("thaumcraft.common.blocks.world.ore.BlockCrystal"))continue;
            for(IBlockState state:b.getBlockState().getValidStates()){
                BlockPos p=new BlockPos(20000+(i%16)*5,65,20000+(i/16)*5);i++;
                // Every orientation has solid attachment without covering adjacent air probes.
                for(net.minecraft.util.EnumFacing f:net.minecraft.util.EnumFacing.VALUES)world.setBlockState(p.offset(f),Blocks.STONE.getDefaultState(),18);
                world.setBlockState(p,state,18);sources.add(p);states.add(state);
            }
        }
        report.addProperty("crystal_states",i);
        if(i==0)throw new IllegalStateException("No Thaumcraft crystals found");
        System.out.println("ISSUE_AUDIT_CRYSTALS "+i);
    }
    private static void measure(String name){
        drain();JsonObject c=new JsonObject();c.addProperty("name",name);JsonArray values=new JsonArray();int bad=0;
        for(int i=0;i<sources.size();i++){
            BlockPos p=sources.get(i);IBlockState s=world.getBlockState(p);JsonObject v=new JsonObject();
            v.addProperty("state",s.toString());v.addProperty("x",p.getX());v.addProperty("y",p.getY());v.addProperty("z",p.getZ());
            int emission=s.getLightValue(world,p),raw=world.getLightFor(EnumSkyBlock.BLOCK,p);
            v.addProperty("emission",emission);v.addProperty("stored",raw);v.addProperty("packed_static",LightInfo.of(s));
            if(emission!=10||raw!=emission)bad++;
            values.add(v);
        }
        c.addProperty("mismatches",bad);c.add("sources",values);cases.add(c);
        System.out.println("ISSUE_AUDIT "+name+" mismatches="+bad);
    }
    private static void corner(){
        // Expose the exterior to sky, then create a sealed one-block oak-log shell.
        for(int x=20080;x<=20092;x++)for(int z=20000;z<=20012;z++)for(int y=90;y<=255;y++)world.setBlockState(new BlockPos(x,y,z),Blocks.AIR.getDefaultState(),18);
        for(int x=20082;x<=20090;x++)for(int z=20002;z<=20010;z++)for(int y=92;y<=100;y++){
            boolean wall=x==20082||x==20090||z==20002||z==20010||y==92||y==100;
            world.setBlockState(new BlockPos(x,y,z),wall?Blocks.LOG.getDefaultState():Blocks.AIR.getDefaultState(),18);
        }
        for(var player:server.getPlayerList().getPlayers())player.connection.setPlayerLocation(20086.5,94,20006.5,135,0);
        report.addProperty("corner_ready",true);cornerReady=true;
    }
    private static void measureCorner(){
        drain();JsonObject c=new JsonObject();c.addProperty("name","sealed-oak-room");int nonzero=0,max=0;
        for(int x=20083;x<=20089;x++)for(int z=20003;z<=20009;z++)for(int y=93;y<=99;y++){
            int v=world.getLightFor(EnumSkyBlock.SKY,new BlockPos(x,y,z));if(v!=0)nonzero++;max=Math.max(max,v);
        }
        c.addProperty("lit_interior_cells",nonzero);c.addProperty("max_sky",max);cases.add(c);
        System.out.println("ISSUE_AUDIT_CORNER lit="+nonzero+" max="+max);
    }
    private static void finish(Throwable failure){
        if(raceLock!=null){raceLock.unlock();raceLock=null;}
        phase=-1;report.addProperty("valid",failure==null);if(failure!=null)report.addProperty("failure",failure.toString());
        try{Path p=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/issue-audit.json");Files.createDirectories(p.getParent());Files.writeString(p,new GsonBuilder().setPrettyPrinting().create().toJson(report));}catch(Exception e){throw new RuntimeException(e);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("ISSUE_AUDIT_COMPLETED");
    }
}
