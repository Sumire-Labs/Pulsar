package com.sumirelabs.pulsar.light;
import java.lang.management.ManagementFactory;
import it.unimi.dsi.fastutil.ints.IntSet;
public final class PendingBenchmark {
 static volatile long sink;
 static long batches(ContextualLightSnapshot<Object> s,int count){
  long sum=0;
  for(int batch=0;batch<count;batch++){
   for(int i=0;i<4096;i++)s.request((80<<8)+(i&2047));
   var positions=s.takePending();
   if(positions instanceof IntSet ints){var it=ints.iterator();while(it.hasNext())sum+=it.nextInt();}
   else for(int position:positions)sum+=position;
  }
  return sum;
 }
 public static void main(String[] args){
  var s=new ContextualLightSnapshot<Object>();
  for(int i=0;i<10;i++)sink=batches(s,100);
  var mx=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();long id=Thread.currentThread().threadId();
  long before=mx.getThreadAllocatedBytes(id),start=System.nanoTime();long value=batches(s,1000);long time=System.nanoTime()-start,bytes=mx.getThreadAllocatedBytes(id)-before;
  sink=value;if(value!=44039168000L)throw new AssertionError("Lost work: "+value);
  System.out.println("{\"elapsed_nanos\":"+time+",\"allocated_bytes\":"+bytes+",\"batches\":1000,\"requests\":4096000,\"unique_per_batch\":2048,\"checksum\":"+value+"}");
 }
}
