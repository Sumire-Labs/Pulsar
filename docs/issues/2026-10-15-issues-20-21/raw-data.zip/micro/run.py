from pathlib import Path
import subprocess,json
r=Path(r'E:/Github/Pulsar-Issues-20261015/micro');java=Path(r'C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot/bin');fast=next(p for p in Path(r'C:/Users/s12kuma01/.gradle/caches/modules-2/files-2.1/it.unimi.dsi/fastutil/7.1.0').rglob('*.jar') if not p.name.endswith('-sources.jar'))
for kind in ['baseline','candidate']:
 dest=r/kind;dest.mkdir(exist_ok=True);sources=list((r/(kind+'-src')).rglob('*.java'));subprocess.run([str(java/'javac.exe'),'-encoding','UTF-8','-cp',str(fast),'-d',str(dest),*map(str,sources),str(r/'PendingBenchmark.java')],check=True)
results=[]
for rep,order in enumerate([['baseline','candidate'],['candidate','baseline'],['candidate','baseline'],['baseline','candidate']],1):
 for kind in order:
  p=subprocess.run([str(java/'java.exe'),'-Xms512m','-Xmx512m','-XX:+UseCompactObjectHeaders','-cp',str(r/kind)+';'+str(fast),'com.sumirelabs.pulsar.light.PendingBenchmark'],text=True,capture_output=True)
  if p.returncode:raise RuntimeError(p.stderr)
  d=json.loads(p.stdout);d.update(rep=rep,variant=kind);results.append(d);print(kind,rep,d,flush=True)
(r/'results.json').write_text(json.dumps(results,indent=2))
