$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-Issues-20261015'
$py='C:\Users\s12kuma01\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$lock=[IO.File]::Open("$root\runner.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try{
 $orders=@(@('baseline','candidate'),@('candidate','baseline'),@('candidate','baseline'),@('baseline','candidate'))
 for($rep=1;$rep -le 4;$rep++){
  foreach($variant in $orders[$rep-1]){
   $run="timing2-tps-r$rep-$variant"
   @{status='measuring';next=$run;updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\formal-progress.json"
   & "$root\run.ps1" -Engine $variant -Run $run -Mode tps -Command 'lightbench tps 2048 5'
   & $py "$root\tools\validate-native.py" "$root\runs\$run"
   if($LASTEXITCODE -ne 0){throw "Invalid $run"}
  }
  if($rep -le 2){
   $reverse=@($orders[$rep-1]);[array]::Reverse($reverse)
   foreach($variant in $reverse){
    $run="timing2-updates-r$rep-$variant"
    @{status='measuring';next=$run;updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\formal-progress.json"
    & "$root\run.ps1" -Engine $variant -Run $run -Mode updates -Command 'lightbench updates 2000 1000'
    & $py "$root\tools\validate-native.py" "$root\runs\$run"
    if($LASTEXITCODE -ne 0){throw "Invalid $run"}
   }
  }
 }
 @{status='measurements-complete';updated=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$root\formal-progress.json"
}catch{
 @{status='needs-investigation';failure=$_.Exception.Message}|ConvertTo-Json|Set-Content "$root\formal-progress.json";throw
}finally{$lock.Dispose()}
