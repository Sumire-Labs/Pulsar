from pathlib import Path
import json,sys,statistics,math,collections,csv
R=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def validate(r):
 stage=load(r/'stage.json');assert load(r/'status.json')['valid'],r
 manifest={x['file']:x['sha256'] for x in load(R/'manifest-final.json')['artifacts']};assert stage['sha256']==manifest[stage['engine_jar']]
 obs=load(r/'results/observer.json');assert not obs.get('failure') and obs['pulsar_parallel_worker_count']==10
 rows=[];envs=[];mods=[];reports=[]
 for p in (r/'results').glob('*.json'):
  d=load(p);b=d.get('benchmark',{});mode=b.get('mode')
  if mode not in ['updates','tps']:continue
  envs.append(d['environment']);mods.append([m for m in d['mods'] if m['id']!='pulsar']);reports.append(p.name)
  if mode=='updates':
   assert b['preflight']['initial_light_verified'] and b['preflight']['post_measurement_volume_verified']
   assert b['plan']['measured_pairs']==1000
   for phase in b['phases']:
    ss=phase['samples'];assert len(ss)==1000 and phase['all_samples_verified'] and all(s['light_verified'] for s in ss)
    v=sorted(s['completion_nanos'] for s in ss)
    rows.append(dict(run=r.name,engine=stage['engine'],metric=phase['name'],mean_ns=statistics.mean(v),p99_ns=v[math.ceil(.99*len(v))-1]))
  else:
   assert b['rate']==2048 and b['requested_ticks']==b['measured_ticks']==100 and b['edits']==204800
   assert b['roof_and_light_verified'] and not b['wall_capped'] and b['roof_mismatch_count']==b['light_mismatch_count']==0
   rows.append(dict(run=r.name,engine=stage['engine'],metric='main_mspt',mean_ns=statistics.mean(b['ticks_nanos'])))
   rows.append(dict(run=r.name,engine=stage['engine'],metric='post_run_drain',mean_ns=b['post_run_drain_nanos']))
 assert len(reports)==1,(r,reports)
 return rows,envs,mods
if len(sys.argv)>1:
 rows,_,_=validate(Path(sys.argv[1]));print(json.dumps(dict(run=Path(sys.argv[1]).name,verified=True,metrics=[x['metric'] for x in rows])))
else:
 rows=[];envs=[];mods=[];runs=[]
 for r in sorted((R/'runs').glob('timing2-*')):
  if not (r/'status.json').exists():continue
  a,b,c=validate(r);rows+=a;envs+=b;mods+=c;runs.append(r.name)
 assert rows
 assert all(x==envs[0] for x in envs),'Runtime mismatch'
 assert all(x==mods[0] for x in mods),'Non-engine mod mismatch'
 summary=[]
 for engine,metric in sorted({(x['engine'],x['metric']) for x in rows}):
  rs=[x for x in rows if x['engine']==engine and x['metric']==metric];v=[x['mean_ns'] for x in rs]
  summary.append(dict(engine=engine,metric=metric,jvms=len(v),median_ns=statistics.median(v),min_ns=min(v),max_ns=max(v)))
 out=R/'analysis';out.mkdir(exist_ok=True)
 (out/'timing-results.json').write_text(json.dumps(dict(runs=runs,same_environment=True,same_non_engine_mods=True,summary=summary,rows=rows),indent=2))
 print('Verified independent JVMs:',len(runs))
 for g in summary:print(g['engine'],g['metric'],g['jvms'],'median_us',round(g['median_ns']/1000,3),'range_us',round(g['min_ns']/1000,3),round(g['max_ns']/1000,3))
