package com.sumirelabs.deliveryaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.command.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.nio.file.*;

/** Vanilla-block control for the parity fixture; runs against the pre-change Pulsar too. */
@Mod(modid="deliveryaudit",name="Chunk Delivery Control",version="1",dependencies="required-after:pulsar")
public final class DeliveryAudit {
    private static final int X=20000,Y=80,Z=20032;
    private static final BlockPos SOURCE=new BlockPos(X+2,Y+2,Z+4);
    private static volatile String client="not observed";
    private static volatile boolean accepted;
    private WorldServer world; private int stage=-1, ticks; private boolean assisted, attempted, waitReady, prepared;
    public DeliveryAudit(){MinecraftForge.EVENT_BUS.register(this);}
    @Mod.EventHandler public void start(FMLServerStartingEvent e){e.registerServerCommand(new CommandBase(){
        public String getName(){return "parityaudit";}
        public String getUsage(ICommandSender s){return "/parityaudit";}
        public int getRequiredPermissionLevel(){return 0;}
        public void execute(MinecraftServer server,ICommandSender sender,String[] args){world=(WorldServer)sender.getEntityWorld();assisted=args.length>0&&args[0].equals("assist");waitReady=args.length>0&&args[0].equals("ready");stage=0;}
    });}
    private String progress(){var c=world.getChunk(SOURCE);var m=((PulsarWorld)world).pulsar$getLightManager();var e=world.getPlayerChunkMap().getEntry(c.x,c.z);
        return "canonical="+c.getLightFor(EnumSkyBlock.BLOCK,SOURCE)+" pending="+m.hasPendingLightWorkNear(c.x,c.z)
                +" populated="+c.isPopulated()+" position="+world.playerEntities.get(0).getPosition()+" entry="+(e==null?"null":e.isSentToPlayers())+" client="+client;}
    @SubscribeEvent public void server(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||stage<0)return;
        try {
            if(stage==0){ if(waitReady&&!prepared){for(int cx=(X>>4)-2;cx<=(X>>4)+2;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+2;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);var p=(EntityPlayerMP)world.playerEntities.get(0);p.setGameType(GameType.CREATIVE);p.capabilities.isFlying=true;p.sendPlayerAbilities();p.connection.setPlayerLocation(X+10.5,Y+3,Z+13.5,180,0);world.getPlayerChunkMap().updateMovingPlayer(p);prepared=true;return;} if(waitReady&&(!world.getChunk(SOURCE).isPopulated()||((PulsarWorld)world).pulsar$getLightManager().hasPendingLightWorkNear(X>>4,Z>>4)))return; System.out.println("DELIVERY_FIXTURE_PRE populated="+world.getChunk(SOURCE).isPopulated()+" ticked="+world.getChunk(SOURCE).wasTicked());
                for(int cx=(X>>4)-2;cx<=(X>>4)+2;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+2;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
                for(int x=0;x<16;x++)for(int y=0;y<=6;y++)for(int z=0;z<16;z++)world.setBlockState(new BlockPos(X+x,Y+y,Z+z),
                        x==0||x==15||y==0||y==6||z==0||z==15?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
                for(int x=1;x<15;x++)for(int y=1;y<=3;y++)for(int z=3;z<=5;z++)world.setBlockState(new BlockPos(X+x,Y+y,Z+z),
                        y==2&&z==4&&x!=1&&x!=8&&x!=14?Blocks.AIR.getDefaultState():Blocks.STONE.getDefaultState(),2);
                world.setBlockState(SOURCE,Blocks.GLOWSTONE.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+4,Y+2,Z+4),Blocks.GLASS.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+10,Y+6,Z+10),Blocks.GLASS.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+11,Y+2,Z+4),Blocks.GLOWSTONE.getDefaultState(),3);
                var p=(EntityPlayerMP)world.playerEntities.get(0);p.setGameType(GameType.CREATIVE);p.capabilities.isFlying=true;p.sendPlayerAbilities();
                p.connection.setPlayerLocation(X+10.5,Y+3,Z+13.5,180,0);world.getPlayerChunkMap().updateMovingPlayer(p);stage=1;return;
            }
            if(assisted&&!attempted&&ticks>100&&!((PulsarWorld)world).pulsar$getLightManager().hasPendingLightWorkNear(X>>4,Z>>4)){attempted=true;var entry=world.getPlayerChunkMap().getEntry(X>>4,Z>>4);System.out.println("DIAGNOSTIC_REFRESH "+progress());entry.sendToPlayer((EntityPlayerMP)world.playerEntities.get(0));} if(++ticks%100==0)System.out.println("DELIVERY_PROGRESS "+progress());
            if(accepted||ticks>600){JsonObject result=new JsonObject();result.addProperty("valid",accepted);result.addProperty("vanilla_block_control",true);
                result.addProperty("progress",progress());result.addProperty("forced_refresh",attempted);result.addProperty("waited_for_populated_fixture",waitReady);
                Path out=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/parity-audit.json");Files.createDirectories(out.getParent());
                Files.writeString(out,new GsonBuilder().setPrettyPrinting().create().toJson(result));stage=-1;
                world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("DELIVERY_FINISHED "+result);
            }
        }catch(Throwable failure){failure.printStackTrace();throw new RuntimeException(failure);}
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;var mc=net.minecraft.client.Minecraft.getMinecraft();if(mc.world==null)return;
        var state=mc.world.getBlockState(SOURCE);int light=mc.world.getChunk(SOURCE).getLightFor(EnumSkyBlock.BLOCK,SOURCE);
        client=state+" light="+light+" position="+(mc.player==null?"null":mc.player.getPosition())+" loaded="+(mc.world.getChunkProvider().getLoadedChunk(X>>4,Z>>4)!=null)+" floor="+mc.world.getBlockState(new BlockPos(X+2,Y,Z+4));
        if(state.getBlock()==Blocks.GLOWSTONE&&light==15)accepted=true;
    }
}
