package com.sumirelabs.deliveryaudit.mixin;
import net.minecraft.network.play.server.SPacketChunkData;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(SPacketChunkData.class)
public abstract class DeliveryChunkConstructorProbe {
    @Inject(method="<init>(Lnet/minecraft/world/chunk/Chunk;I)V",at=@At("RETURN"),remap=false)
    private void record(Chunk chunk,int mask,CallbackInfo ci){
        if(chunk.x!=1250||chunk.z!=1252)return;
        SPacketChunkData packet=(SPacketChunkData)(Object)this;
        System.out.println("DELIVERY_PACKET_CONSTRUCT full="+packet.isFullChunk()+" requested="+mask+" available="+packet.getExtractedSize()
                +" source="+chunk.getBlockState(new BlockPos(20002,82,20036))+" floor="+chunk.getBlockState(new BlockPos(20002,80,20036)));
    }
}
