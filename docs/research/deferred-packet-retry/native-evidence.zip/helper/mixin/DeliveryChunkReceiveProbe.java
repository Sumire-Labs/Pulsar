package com.sumirelabs.deliveryaudit.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.SPacketChunkData;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(NetHandlerPlayClient.class)
public abstract class DeliveryChunkReceiveProbe {
    @Inject(method={"handleChunkData","func_147263_a"},at=@At("HEAD"),remap=false)
    private void before(SPacketChunkData packet,CallbackInfo ci){record("before",packet);}
    @Inject(method={"handleChunkData","func_147263_a"},at=@At("RETURN"),remap=false)
    private void after(SPacketChunkData packet,CallbackInfo ci){record("after",packet);}
    private static void record(String stage,SPacketChunkData packet){
        Minecraft mc=Minecraft.getMinecraft();
        if(!mc.isCallingFromMinecraftThread()||packet.getChunkX()!=1250||packet.getChunkZ()!=1252)return;
        System.out.println("DELIVERY_PACKET_RECEIVE "+stage+" full="+packet.isFullChunk()+" available="+packet.getExtractedSize()
                +" source="+(mc.world==null?"null":mc.world.getBlockState(new BlockPos(20002,82,20036)))
                +" floor="+(mc.world==null?"null":mc.world.getBlockState(new BlockPos(20002,80,20036))));
    }
}
