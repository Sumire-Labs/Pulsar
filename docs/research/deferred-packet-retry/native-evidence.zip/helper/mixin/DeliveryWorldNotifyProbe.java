package com.sumirelabs.deliveryaudit.mixin;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(World.class)
public abstract class DeliveryWorldNotifyProbe {
    private static boolean target(BlockPos pos){return pos.getX()==20002&&pos.getZ()==20036&&(pos.getY()==80||pos.getY()==82);}
    private String data(BlockPos pos){World w=(World)(Object)this;
        StringBuilder out=new StringBuilder(" capture="+w.captureBlockSnapshots+" populated="+w.getChunk(pos).isPopulated());
        if(w instanceof WorldServer){var entry=((WorldServer)w).getPlayerChunkMap().getEntry(1250,1252);
            if(entry!=null)for(var field:entry.getClass().getDeclaredFields())if(field.getType()==int.class||field.getType()==boolean.class)
                try{field.setAccessible(true);out.append(' ').append(field.getName()).append('=').append(field.get(entry));}catch(Exception ignored){}
        }return out.toString();}
    @Inject(method={"setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z","func_180501_a"},at=@At("HEAD"),remap=false)
    private void before(BlockPos pos,IBlockState state,int flags,CallbackInfoReturnable<Boolean> cir){
        if(!((World)(Object)this).isRemote&&target(pos))System.out.println("DELIVERY_WORLD_SET pos="+pos+" state="+state+" flags="+flags+data(pos));}
    @Inject(method="markAndNotifyBlock",at=@At("HEAD"),remap=false)
    private void notifyBefore(BlockPos pos,Chunk chunk,IBlockState old,IBlockState state,int flags,CallbackInfo ci){
        if(!((World)(Object)this).isRemote&&target(pos))System.out.println("DELIVERY_WORLD_NOTIFY_BEFORE pos="+pos+" flags="+flags+data(pos));}
    @Inject(method="markAndNotifyBlock",at=@At("RETURN"),remap=false)
    private void notifyAfter(BlockPos pos,Chunk chunk,IBlockState old,IBlockState state,int flags,CallbackInfo ci){
        if(!((World)(Object)this).isRemote&&target(pos))System.out.println("DELIVERY_WORLD_NOTIFY_AFTER pos="+pos+" flags="+flags+data(pos));}
}
