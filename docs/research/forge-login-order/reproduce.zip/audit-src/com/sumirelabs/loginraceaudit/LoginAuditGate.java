package com.sumirelabs.loginraceaudit;
import io.netty.channel.Channel;
import net.minecraft.network.NetworkManager;
import java.util.concurrent.*;
public final class LoginAuditGate {
 private static final ConcurrentHashMap<NetworkManager,CountDownLatch> GATES=new ConcurrentHashMap<>();
 public static void hold(NetworkManager manager){
  if(!Boolean.getBoolean("pulsar.loginAudit.gate"))return;
  Channel channel=manager.channel();if(channel.getClass().getName().contains("LocalChannel")||channel.eventLoop().inEventLoop())return;
  CountDownLatch release=new CountDownLatch(1),started=new CountDownLatch(1);
  if(GATES.putIfAbsent(manager,release)!=null)throw new IllegalStateException("Duplicate login gate");
  channel.eventLoop().execute(()->{started.countDown();try{if(!release.await(5,TimeUnit.SECONDS))System.out.println("LOGIN_AUDIT_GATE_TIMEOUT");}catch(InterruptedException e){throw new RuntimeException(e);}});
  try{if(!started.await(5,TimeUnit.SECONDS))throw new IllegalStateException("Gate did not start");}catch(InterruptedException e){throw new RuntimeException(e);}
  System.out.println("LOGIN_AUDIT_GATE_HELD channel="+channel.id());
 }
 public static void release(NetworkManager manager){CountDownLatch gate=GATES.remove(manager);if(gate!=null){System.out.println("LOGIN_AUDIT_GATE_RELEASED channel="+manager.channel().id());gate.countDown();}}
}
