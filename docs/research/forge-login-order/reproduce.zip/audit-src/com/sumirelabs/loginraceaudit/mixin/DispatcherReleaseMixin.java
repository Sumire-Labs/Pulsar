package com.sumirelabs.loginraceaudit.mixin;
import com.sumirelabs.loginraceaudit.LoginAuditGate;
import net.minecraft.network.NetworkManager;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.handshake.NetworkDispatcher;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=NetworkDispatcher.class,remap=false)
public abstract class DispatcherReleaseMixin {
 @Shadow(remap=false) @Final private NetworkManager manager;
 @Inject(method="serverToClientHandshake",at=@At("RETURN"),remap=false,require=1)
 private void audit$release(EntityPlayerMP player,CallbackInfo ci){LoginAuditGate.release(manager);}
}
