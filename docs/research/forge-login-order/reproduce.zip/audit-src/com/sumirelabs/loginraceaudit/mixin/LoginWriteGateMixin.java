package com.sumirelabs.loginraceaudit.mixin;
import com.sumirelabs.loginraceaudit.LoginAuditGate;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.login.server.SPacketLoginSuccess;
import io.netty.util.concurrent.GenericFutureListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=NetworkManager.class,remap=false)
public abstract class LoginWriteGateMixin {
 @Inject(method="func_150732_b(Lnet/minecraft/network/Packet;[Lio/netty/util/concurrent/GenericFutureListener;)V",at=@At("HEAD"),remap=false,require=1)
 private void audit$hold(Packet<?> packet,GenericFutureListener[] listeners,CallbackInfo ci){if(packet instanceof SPacketLoginSuccess)LoginAuditGate.hold((NetworkManager)(Object)this);}
}
