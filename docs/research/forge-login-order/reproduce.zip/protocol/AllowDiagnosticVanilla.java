import org.objectweb.asm.*;
import java.nio.file.*;
import java.util.zip.*;
public final class AllowDiagnosticVanilla {
 public static void main(String[] args)throws Exception{
  int[] changed={0};
  try(var in=new ZipInputStream(Files.newInputStream(Path.of(args[0])));var out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
   ZipEntry entry;
   while((entry=in.getNextEntry())!=null){byte[] bytes=in.readAllBytes();
    if(entry.getName().endsWith(".class")){
     var reader=new ClassReader(bytes);var writer=new ClassWriter(0);
     reader.accept(new ClassVisitor(Opcodes.ASM9,writer){
      public AnnotationVisitor visitAnnotation(String name,boolean visible){
       var original=super.visitAnnotation(name,visible);
       if(!name.equals("Lnet/minecraftforge/fml/common/Mod;"))return original;
       changed[0]++;
       return new AnnotationVisitor(Opcodes.ASM9,original){
        boolean seen;
        public void visit(String key,Object value){if(key.equals("acceptableRemoteVersions")){seen=true;value="*";}super.visit(key,value);}
        public void visitEnd(){if(!seen)super.visit("acceptableRemoteVersions","*");super.visitEnd();}
       };
      }
     },0);bytes=writer.toByteArray();
    }
    out.putNextEntry(new ZipEntry(entry.getName()));out.write(bytes);out.closeEntry();
   }
  }
  System.out.println(Path.of(args[0]).getFileName()+" optional diagnostic containers="+changed[0]);
  if(changed[0]==0)throw new IllegalStateException("No diagnostic @Mod container patched");
 }
}
