$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar/benchmarks/login-race-20261019'
& "$root/run.ps1" -Run fixed-gated-scalar-rgb -HostMode SCALAR -ClientMode RGB
& "$root/run.ps1" -Run fixed-gated-rgb-rgb -HostMode RGB -ClientMode RGB
& "$root/run.ps1" -Run fixed-gated-rgb-scalar -HostMode RGB -ClientMode SCALAR
& "$root/run.ps1" -Run fixed-gated-scalar-scalar -HostMode SCALAR -ClientMode SCALAR
& "$root/run.ps1" -Run fixed-natural-rgb-rgb -HostMode RGB -ClientMode RGB -Gate $false
