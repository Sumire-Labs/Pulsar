from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path('E:/Github/Pulsar/benchmarks/login-race-20261019')
repo=Path('C:/Users/s12kuma01/.codex/worktrees/rgb-completion/Pulsar')
out=repo/'docs/research/forge-login-order';raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
names=['baseline-gated-scalar-rgb','fixed-gated-scalar-rgb','fixed-gated-rgb-rgb','fixed-gated-rgb-scalar','fixed-gated-scalar-scalar','fixed-natural-rgb-rgb','baseline-vanilla-gated','fixed-vanilla-gated']
summary={}
for name in names:
 folder=r/'runs'/name
 status=json.loads((folder/'status.json').read_text())
 assert status['pass'] and status['gate_timeouts']==0,(name,status)
 if name.startswith('baseline'):
  expected=8 if 'vanilla' in name else 6
  assert status['expected_failure'] and status['login_state_errors']==expected and status['held_gates']==expected
 else:
  assert not status['expected_failure'] and status['login_state_errors']==0
  if 'vanilla' in name:
   assert status['vanilla_valid'] and status['held_gates']==8 and status['test_only_optional_diagnostic_mods']
   vanilla=json.loads((folder/'vanilla.json').read_text())
   assert len(vanilla['cases'])==8 and all(c['login_success'] and c['joined'] and c['compression_threshold']==256 for c in vanilla['cases'])
  else:
   assert status['peer_valid'] and status['attempts']==2
   assert status['held_gates']==(0 if 'natural' in name else 2)
   peer=json.loads((folder/'peer-result.json').read_text())
   assert peer['connected_remote'] and peer['rejoin_new_connection'] and len(peer['world_transitions'])==4
   assert not peer['test_only_login_state_workaround'] and not peer['test_only_initial_send_retry']
 stage=json.loads((folder/'stage.json').read_text())
 ready=json.loads((folder/'host-ready.json').read_text())
 assert ready['rgb_server']==(stage['host_mode']=='RGB'),(name,'host mode')
 if not name.startswith('baseline') and 'vanilla' not in name:
  assert peer['rgb_client_config']==(stage['client_mode']=='RGB')
  assert peer['rgb_buffer_fields']==(stage['client_mode']=='RGB')
  assert peer['rgb_channel_active']==(stage['host_mode']=='RGB' and stage['client_mode']=='RGB')
 data={};dest=raw/name;dest.mkdir(exist_ok=True)
 for filename in ['status.json','stage.json','peer-result.json','vanilla.json','host-ready.json']:
  file=folder/filename
  if file.exists():
   shutil.copy2(file,dest/filename);data[filename[:-5]]=json.loads(file.read_text())
 with zipfile.ZipFile(dest/'logs.zip','w',zipfile.ZIP_DEFLATED) as z:
  for filename in ['host.log','client.log']:
   file=folder/filename
   if file.exists():z.write(file,filename)
 summary[name]=data
(out/'summary.json').write_text(json.dumps(summary,indent=2))
for filename in ['engine-byte-proof.json','unit-tests.json']:shutil.copy2(r/filename,out/filename)
source_paths=['src/main/java/com/sumirelabs/pulsar/compat/LoginProtocolOrder.java','src/main/java/com/sumirelabs/pulsar/mixin/MixinForgeLoginProtocol.java','src/test/java/com/sumirelabs/pulsar/compat/LoginProtocolOrderTest.java','src/main/resources/pulsar.mixin.json','build.gradle']
freeze={'baseline_commit':'d1a40083d2062b4d85138eacef7944bd0ee4fea4','branch':'feat/rgb-engine','build_target':'Cleanroom 0.6.13-alpha','native_platform':'Cleanroom 0.7.7-alpha','source_normalization':'UTF-8 bytes with CRLF normalized to LF','source_sha256_lf':{name:hashlib.sha256((repo/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for name in source_paths}}
(out/'source-freeze.json').write_text(json.dumps(freeze,indent=2))
with zipfile.ZipFile(r/'artifacts/candidate.jar') as z:
 names_in=z.namelist();assert not any(n.startswith(('com/sumirelabs/loginraceaudit/','com/sumirelabs/peeraudit/','io/netty/')) for n in names_in)
 ref=json.loads(z.read('pulsar.mixin-refmap.json'))['mappings']['com/sumirelabs/pulsar/mixin/MixinForgeLoginProtocol']
 target='Lnet/minecraft/network/NetworkManager;setConnectionState(Lnet/minecraft/network/EnumConnectionState;)V'
 assert ref[target]=='Lnet/minecraft/network/NetworkManager;func_150723_a(Lnet/minecraft/network/EnumConnectionState;)V'
 (out/'refmap-check.json').write_text(json.dumps(ref,indent=2))
with zipfile.ZipFile(out/'reproduce.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in (r/'audit-src').rglob('*.java'):z.write(file,'audit-src/'+file.relative_to(r/'audit-src').as_posix())
 for file in (r/'diagnostics').rglob('*.java'):z.write(file,'diagnostics/'+file.relative_to(r/'diagnostics').as_posix())
 for filename in ['AllowDiagnosticVanilla.java','audit-classpath.gradle','reset-world.py','vanilla-login.py','run.ps1','run-vanilla.ps1','fixed-matrix.ps1','vanilla-matrix.ps1','publish.py']:
  z.write(r/filename,'protocol/'+filename)
 z.write(r/'artifacts/login-audit.jar','diagnostics/login-audit.jar')
 z.write(repo/'LICENSE.md','LICENSE.md')
 z.writestr('README.txt','Original private diagnostic helper/source: LGPL-3.0-only. Never part of production Pulsar. Uses two disposable Prism native profiles and loopback endpoints; five-second test-only Netty gates. Diagnostic metadata is made optional only in vanilla-specific profiles. No protocol rewrite, assisted initial chunk send, external Minecraft/Forge code or third-party jar is included. The standalone vanilla client validates protocol340 LoginSuccess/JoinGame with compression256. Local absolute paths and existing isolated profile seed dependencies are documented by the scripts. The normal Gradle test suite independently reproduces the FIFO bug without a game.\n')
for file in out.rglob('*'):
 if file.is_file() and file.suffix in ['.json','.md']:file.write_bytes(file.read_bytes().replace(b'\r\n',b'\n'))
checks={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'}
(out/'SHA256SUMS').write_bytes(''.join(f'{v}  {k}\n' for k,v in checks.items()).encode())
print('Published',len(checks),'files; all expected controls and candidate checks accepted')
