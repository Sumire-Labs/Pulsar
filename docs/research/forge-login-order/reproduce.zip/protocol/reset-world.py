from pathlib import Path
import gzip,struct,sys
p=Path(sys.argv[1]).resolve()
assert any(n in str(p) for n in ['Pulsar-LoginRace-20261019-host','Pulsar-LoginRace-Vanilla-20261019-host']) and p.name=='level.dat'
s=gzip.decompress(p.read_bytes())
for key,value in [('gameLoopFunction','perfbench:wait'),('fourbench_complete','false')]:
 name=key.encode(); token=b'\x08'+struct.pack('>H',len(name))+name
 assert s.count(token)==1,(key,s.count(token))
 start=s.index(token)+len(token);old=struct.unpack('>H',s[start:start+2])[0];v=value.encode()
 s=s[:start]+struct.pack('>H',len(v))+v+s[start+2+old:]
p.write_bytes(gzip.compress(s))
