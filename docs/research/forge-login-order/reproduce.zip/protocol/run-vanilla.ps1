param([string]$Run,[string]$HostMode='RGB',[string]$ClientMode='RGB',[string]$Artifact='candidate.jar',[bool]$Gate=$true,[switch]$ExpectFailure,[int]$RawCount=0,[switch]$VanillaOnly)
$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar/benchmarks/login-race-20261019'
$prism='C:/Users/s12kuma01/AppData/Roaming/PrismLauncher/instances'
$prefix='Pulsar-LoginRace-Vanilla-20261019'
$out="$root/runs/$Run"
if($Run -notmatch '^[a-z0-9-]+$' -or (Test-Path $out)){throw 'Invalid/existing run'}
New-Item -ItemType Directory -Force $out | Out-Null
function Owned([string]$Role){@(Get-CimInstance Win32_Process -Filter "Name='javaw.exe'"|Where-Object CommandLine -like "*$prefix-$Role*")}
foreach($role in @('host','client')){
 if((Owned $role).Count){throw 'Previous test is running'}
 $source="$prism/Pulsar-RGB-PeerFinal077-20261018-$role"
 $instance="$prism/$prefix-$role";$game="$instance/minecraft"
 New-Item -ItemType Directory -Force $instance | Out-Null
 foreach($file in @('instance.cfg','mmc-pack.json')){Copy-Item "$source/$file" "$instance/$file" -Force}
 if(Test-Path $game){
  if([IO.Path]::GetFullPath($game) -ne [IO.Path]::GetFullPath("$prism/$prefix-$role/minecraft")){throw 'Unexpected game path'}
  Rename-Item -LiteralPath $game -NewName "minecraft-backup-$Run"
 }
 New-Item -ItemType Directory -Force "$game/mods","$game/config" | Out-Null
 Copy-Item "$source/minecraft/mods/*" "$game/mods" -Recurse
 Copy-Item "$source/minecraft/config/*" "$game/config" -Recurse
 Copy-Item "$source/minecraft/options.txt" "$game/options.txt"
 Copy-Item "$root/artifacts/$Artifact" "$game/mods/pulsar.jar" -Force
 Copy-Item "$root/artifacts/login-audit.jar" "$game/mods/peer-audit.jar" -Force
 if($VanillaOnly -and $role -eq 'host'){
  $auditCp=(Get-Content "$root/classpath.txt" -Raw)+";$root/audit-classes"
  foreach($jar in @('four-engine-driver.jar','lightbench-1.1.0-bench9.jar','peer-audit.jar')){
   & 'C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot/bin/java.exe' -cp $auditCp AllowDiagnosticVanilla "$game/mods/$jar" "$game/mods/$jar.tmp"
   if($LASTEXITCODE -ne 0){throw 'Diagnostic metadata preparation failed'}
   Move-Item -LiteralPath "$game/mods/$jar.tmp" -Destination "$game/mods/$jar" -Force
  }
 }
 $cfg=Get-Content "$game/config/pulsar.cfg" -Raw
 $mode=if($role -eq 'host'){$HostMode}else{$ClientMode}
 $cfg=[regex]::Replace($cfg,'(?m)^\s*S:(lightingMode|rgbGameplayLight)=.*$','')
 [IO.File]::WriteAllText("$game/config/pulsar.cfg",$cfg.Replace('general {',"general {`n    S:lightingMode=$mode`n    S:rgbGameplayLight=RGB_MAX"))
 $colors=if($role -eq 'host' -and $HostMode -eq 'RGB'){"minecraft:glowstone = 0, 0, 0`n"}else{"# Default diagnostic palette`n"}
 [IO.File]::WriteAllText("$game/config/pulsar-colors.cfg",$colors)
 $config=Get-Content "$game/config/relauncher.json" -Raw|ConvertFrom-Json
 $config.javaPath='C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot/bin/javaw.exe'
 $gateEnabled=if($role -eq 'host' -and $Gate){'true'}else{'false'}
 $config.args="-XX:+UseCompactObjectHeaders -Djdk.net.unixdomain.tmpdir=E:/Github/Pulsar -Dpulsar.loginAudit.gate=$gateEnabled"
 $config|ConvertTo-Json|Set-Content "$game/config/relauncher.json" -Encoding UTF8
 $roleConfig=@{role=$role;port=25397;output=$out;expected_rgb=($HostMode -eq 'RGB' -and $ClientMode -eq 'RGB');expected_authority=($HostMode -eq 'RGB');zero_source=($HostMode -eq 'RGB')}
 [IO.File]::WriteAllText("$game/peer-role.json",($roleConfig|ConvertTo-Json))
 if($role -eq 'host'){
  New-Item -ItemType Directory -Force "$game/saves" | Out-Null
  Copy-Item "$source/minecraft/saves/Bench Updates" "$game/saves/Bench Updates" -Recurse
  $env:PYTHONUTF8='1'
  & 'C:/Users/s12kuma01/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' "$root/reset-world.py" "$game/saves/Bench Updates/level.dat"
  if($LASTEXITCODE -ne 0){throw 'NBT staging failed'}
 }
}
[IO.File]::WriteAllText("$out/stage.json",(@{host_mode=$HostMode;client_mode=$ClientMode;gate=$Gate;vanilla_only=[bool]$VanillaOnly;raw_count=$RawCount;expect_failure=[bool]$ExpectFailure;candidate=(Get-FileHash "$root/artifacts/$Artifact").Hash;helper=(Get-FileHash "$root/artifacts/login-audit.jar").Hash;fixture_mods=@{driver=(Get-FileHash "$prism/$prefix-host/minecraft/mods/four-engine-driver.jar").Hash;lightbench=(Get-FileHash "$prism/$prefix-host/minecraft/mods/lightbench-1.1.0-bench9.jar").Hash;helper=(Get-FileHash "$prism/$prefix-host/minecraft/mods/peer-audit.jar").Hash}}|ConvertTo-Json))
$launcher='C:/Users/s12kuma01/AppData/Local/Programs/PrismLauncher/prismlauncher.exe'
Start-Process $launcher -ArgumentList '-l',"$prefix-host",'--offline','RGBHost' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(6)
while(-not(Test-Path "$out/host-ready.json")){
 if(Test-Path "$out/host-failure.json"){throw 'Host failed'}
 if([DateTime]::UtcNow -gt $deadline){throw 'Host startup timeout; retained'}
 Start-Sleep -Seconds 2
}
if($RawCount -gt 0 -and -not $VanillaOnly){
 & 'C:/Users/s12kuma01/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' "$root/vanilla-login.py" "$out/vanilla.json" $RawCount 25397
 if($LASTEXITCODE -ne 0){throw 'Vanilla LOGIN/PLAY boundary failed'}
}
if($VanillaOnly){
 & 'C:/Users/s12kuma01/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' "$root/vanilla-login.py" "$out/vanilla.json" $RawCount 25397
 $raw=Get-Content "$out/vanilla.json" -Raw|ConvertFrom-Json
 Owned host|ForEach-Object{Stop-Process -Id $_.ProcessId -Force}
 Start-Sleep -Seconds 2
 Copy-Item "$prism/$prefix-host/minecraft/logs/latest.log" "$out/host.log"
 $log=Get-Content "$out/host.log" -Raw
 $bad=([regex]::Matches($log,'PEER_PACKET_STATE packet=net.minecraft.network.login.server.SPacketLoginSuccess')).Count
 $held=([regex]::Matches($log,'LOGIN_AUDIT_GATE_HELD')).Count
 $timeouts=([regex]::Matches($log,'LOGIN_AUDIT_GATE_TIMEOUT')).Count
 $pass=if($ExpectFailure){-not $raw.valid -and $bad -eq $RawCount -and $held -eq $RawCount -and $timeouts -eq 0}else{$raw.valid -and $bad -eq 0 -and $held -eq $RawCount -and $timeouts -eq 0}
 [IO.File]::WriteAllText("$out/status.json",(@{pass=$pass;expected_failure=[bool]$ExpectFailure;vanilla_valid=$raw.valid;login_state_errors=$bad;held_gates=$held;gate_timeouts=$timeouts;test_only_optional_diagnostic_mods=$true}|ConvertTo-Json))
 Write-Output "Vanilla login audit $Run pass=$pass mismatches=$bad gates=$held"
 if(-not $pass){throw 'Vanilla audit failed'}
 return
}
Start-Process $launcher -ArgumentList '-l',"$prefix-client",'--offline','RGBPeer' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(7)
while(-not(Test-Path "$out/peer-result.json")){
 if([DateTime]::UtcNow -gt $deadline){throw 'Client timeout; retained'}
 Start-Sleep -Seconds 2
}
$result=Get-Content "$out/peer-result.json" -Raw|ConvertFrom-Json
if($ExpectFailure){foreach($role in @('host','client')){Owned $role|ForEach-Object{Stop-Process -Id $_.ProcessId -Force}}}
$deadline=[DateTime]::UtcNow.AddSeconds(25)
while(((Owned host).Count -or (Owned client).Count) -and [DateTime]::UtcNow -lt $deadline){Start-Sleep -Seconds 2}
foreach($role in @('host','client')){Copy-Item "$prism/$prefix-$role/minecraft/logs/latest.log" "$out/$role.log"}
$log=Get-Content "$out/host.log" -Raw
$bad=([regex]::Matches($log,'PEER_PACKET_STATE packet=net.minecraft.network.login.server.SPacketLoginSuccess')).Count
$held=([regex]::Matches($log,'LOGIN_AUDIT_GATE_HELD')).Count
$timeouts=([regex]::Matches($log,'LOGIN_AUDIT_GATE_TIMEOUT')).Count
$pass=if($ExpectFailure){-not $result.valid -and $bad -ge 1 -and $held -ge 1 -and $timeouts -eq 0}else{$result.valid -and $bad -eq 0 -and $timeouts -eq 0 -and $result.connection_attempts -eq 2 -and (-not $Gate -or $held -eq (2+$RawCount))}
[IO.File]::WriteAllText("$out/status.json",(@{pass=$pass;expected_failure=[bool]$ExpectFailure;login_state_errors=$bad;held_gates=$held;gate_timeouts=$timeouts;attempts=$result.connection_attempts;peer_valid=$result.valid}|ConvertTo-Json))
Write-Output "Login audit $Run pass=$pass mismatches=$bad gates=$held"
if(-not $pass){throw 'Login audit failed'}