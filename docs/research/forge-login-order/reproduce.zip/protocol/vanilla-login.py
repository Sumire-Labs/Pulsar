import socket,struct,zlib,json,time,sys
from pathlib import Path
def vi(v):
 out=bytearray()
 while True:
  b=v&127;v>>=7;out.append(b|(128 if v else 0))
  if not v:return bytes(out)
def rv(data,at=0):
 value=0
 for i in range(5):
  b=data[at];at+=1;value|=(b&127)<<(7*i)
  if not b&128:return value,at
 raise ValueError('Invalid varint')
def string(s):
 b=s.encode();return vi(len(b))+b
def exact(sock,n):
 out=b''
 while len(out)<n:
  b=sock.recv(n-len(out))
  if not b:raise EOFError('Closed before join')
  out+=b
 return out
def frame(sock):
 header=b''
 while True:
  b=exact(sock,1);header+=b
  if not b[0]&128:break
 n,_=rv(header)
 if n>8388608:raise ValueError('Oversize frame')
 return exact(sock,n)
def send(sock,payload,compressed=False):
 if compressed:payload=vi(0)+payload
 sock.sendall(vi(len(payload))+payload)
results=[]
for i in range(int(sys.argv[2])):
 case={'name':'VanillaAudit'+str(i),'login_success':False,'joined':False}
 try:
  with socket.create_connection(('127.0.0.1',int(sys.argv[3]) if len(sys.argv)>3 else 25396),10) as sock:
   sock.settimeout(10)
   send(sock,vi(0)+vi(340)+string('127.0.0.1')+struct.pack('>H',int(sys.argv[3]) if len(sys.argv)>3 else 25396)+vi(2))
   send(sock,vi(0)+string(case['name']))
   compressed=False
   for _ in range(1024):
    data=frame(sock)
    if compressed:
     n,at=rv(data);data=zlib.decompress(data[at:]) if n else data[at:]
    kind,at=rv(data)
    if not case['login_success']:
     if kind==3:
      threshold,_=rv(data,at);case['compression_threshold']=threshold;compressed=True
     elif kind==2:
      case['login_success']=True
      send(sock,vi(4)+string('en_us')+bytes([2])+vi(0)+bytes([1,127])+vi(1),compressed)
     elif kind==0:raise RuntimeError('Login disconnect '+repr(data[at:])[:200])
     else:raise RuntimeError('Unexpected login packet '+str(kind))
    else:
     if kind==0x23:case['joined']=True;time.sleep(.15);break
     if kind==0x1A:raise RuntimeError('Play disconnect before join')
   if not case['joined']:raise RuntimeError('No join packet')
 except Exception as e:case['error']=str(e)
 results.append(case)
 time.sleep(.15)
out={'valid':all(c['login_success'] and c['joined'] for c in results),'cases':results,'protocol':340,'compression_supported':True,'forge_marker':False}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2));print(json.dumps(out))
if not out['valid']:sys.exit(1)
