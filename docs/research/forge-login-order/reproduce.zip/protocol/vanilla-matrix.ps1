$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar/benchmarks/login-race-20261019'
& "$root/run-vanilla.ps1" -Run baseline-vanilla-gated -HostMode SCALAR -ClientMode SCALAR -Artifact baseline.jar -VanillaOnly -RawCount 8 -ExpectFailure
& "$root/run-vanilla.ps1" -Run fixed-vanilla-gated -HostMode SCALAR -ClientMode SCALAR -VanillaOnly -RawCount 8
