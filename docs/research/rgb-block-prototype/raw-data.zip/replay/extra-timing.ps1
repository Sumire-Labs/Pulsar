$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
foreach($trial in @(
    @{run='timing-baseline-3';artifact='baseline.jar'},
    @{run='timing-scalar-3';artifact='candidate.jar'},
    @{run='timing-scalar-4';artifact='candidate.jar'},
    @{run='timing-baseline-4';artifact='baseline.jar'}
)) {
    [IO.File]::WriteAllText("$root\progress.json",(@{stage='extra-timing';run=$trial.run;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
    & "$root\run.ps1" -Run $trial.run -Mode SCALAR -Command 'lightbench updates 2000 1000' -Artifact $trial.artifact
    if((Get-Content "$root\runs\$($trial.run)\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw 'Timing failed'}
}
[IO.File]::WriteAllText("$root\progress.json",(@{stage='complete';utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
