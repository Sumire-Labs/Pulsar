$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
function Audit([string]$run,[string]$mode='RGB',[string]$command='rgbaudit',[string]$template='flat') {
    [IO.File]::WriteAllText("$root\progress.json",(@{stage='correctness';run=$run;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
    & "$root\run.ps1" -Run $run -Mode $mode -Command $command -Template $template
    $file=if($command -like 'issueaudit*'){'issue-audit.json'}else{'rgb-audit.json'}
    $report=Get-Content "$root\runs\$run\results\$file" -Raw|ConvertFrom-Json
    if($report.valid -ne $true){throw "Audit failed: $run"}
}
Audit 'rgb-vanilla-final'
$game='C:\Users\s12kuma01\AppData\Roaming\PrismLauncher\instances\Pulsar-RGB-20261016\minecraft'
Copy-Item "$game\saves\Bench Updates" "$root\templates\cache" -Recurse
Audit 'rgb-cache-reload' 'RGB' 'rgbaudit reload' 'cache'
Audit 'scalar-mode-audit' 'SCALAR' 'rgbaudit scalar'
Audit 'rgb-cqr-regression' 'RGB' 'issueaudit ship' 'normal'
# Formal timing starts only after every build and correctness audit has finished.
$trials=@(
    @{run='timing-baseline-1';artifact='baseline.jar';mode='SCALAR'},
    @{run='timing-scalar-1';artifact='candidate.jar';mode='SCALAR'},
    @{run='timing-scalar-2';artifact='candidate.jar';mode='SCALAR'},
    @{run='timing-baseline-2';artifact='baseline.jar';mode='SCALAR'},
    @{run='timing-rgb-1';artifact='candidate.jar';mode='RGB'},
    @{run='timing-rgb-2';artifact='candidate.jar';mode='RGB'}
)
foreach($trial in $trials) {
    [IO.File]::WriteAllText("$root\progress.json",(@{stage='timing';run=$trial.run;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
    & "$root\run.ps1" -Run $trial.run -Mode $trial.mode -Command 'lightbench updates 2000 1000' -Artifact $trial.artifact
    $status=Get-Content "$root\runs\$($trial.run)\status.json" -Raw|ConvertFrom-Json
    if($status.valid -ne $true){throw "Timing failed: $($trial.run)"}
}
[IO.File]::WriteAllText("$root\progress.json",(@{stage='complete';utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
