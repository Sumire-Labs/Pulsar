from pathlib import Path
import json, hashlib, zipfile, statistics, subprocess, shutil
import xml.etree.ElementTree as E
study=Path("E:/Github/Pulsar-RGB-20261016")
repo=Path("E:/Github/Pulsar")
out=repo/"docs/research/rgb-filters"
out.mkdir(exist_ok=True,parents=True)
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d): (out/n).write_text(json.dumps(d,indent=2)+"\n",encoding="utf-8",newline="\n")
freeze=read(study/"phase2/source-freeze.json")
assert all(sha(repo/p)==v for p,v in freeze.items())
subprocess.run(["git","diff","--exit-code","HEAD","--","LICENSE.md","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarBlockEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarSkyEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/LightEngineCache.java"],cwd=repo,check=True)
core=["filters-vanilla-final-2","filters-cache-reload","filters-cache-migration","filters-celeritas-fast","filters-scalar-audit"]
validation={}
for run in core:
 d=read(study/"runs"/run/"results/rgb-audit.json")
 assert d["valid"]
 assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts/phase2.jar")
 for case in d["cases"]: assert case["mismatches"]==case["server_scalar_mismatches"]==case["server_snapshot_canonical_mismatches"]==0
 for key,c in d.items():
  if key.startswith("client-"): assert c["valid"] and c["mismatches"]==c["scalar_mismatches"]==c["snapshot_canonical_mismatches"]==0 and c["colored_vertices"]>0
 validation[run]=d
assert len(validation[core[0]]["cases"])==len(validation[core[3]]["cases"])==10
assert validation["filters-cache-reload"]["cached_light_valid_0"]
assert not validation["filters-cache-migration"]["cached_light_valid_0"]
assert validation["filters-celeritas-fast"]["client-2"]["celeritas_hook"]
assert validation["filters-scalar-audit"]["scalar_has_no_rgb_chunk_fields"]
reg=study/"runs/filters-cqr/results"
d=read(reg/"issue-audit.json");assert d["valid"] and d["crystal_states"]==112
cases={c["name"]:c for c in d["cases"]}
for n in ["world-placement","direct-chunk-placement","full-relight"]: assert cases[n]["mismatches"]==0
assert cases["initial-send-race"]["context_pending"] and not cases["initial-send-race"]["sent_while_pending"]
assert cases["initial-send-after-drain"]["stored"]==10 and cases["initial-send-after-drain"]["retry_sent"]
assert not cases["existing-entry-watch-race"]["watching_while_pending"]
assert cases["existing-entry-watch-after-drain"]["watch_events_while_pending"]==0
assert cases["existing-entry-watch-after-drain"]["watch_events_after_drain"]==1
assert cases["sealed-oak-room"]["lit_interior_cells"]==0
assert cases["native-cqr-generation"]["cells"]==68800
assert cases["native-cqr-vs-full-relight"]["sky_differences"]==cases["native-cqr-vs-full-relight"]["block_differences"]==0
corner=read(reg/"issue-client.json");assert corner["lit_interior_cells"]==corner["max_sky"]==0
assert all(v["sky"]==v["block"]==0 for m in corner["models"] for v in m["interior_face_lightmap"])
ship=read(reg/"issue-ship-client.json");assert all(v["sky_mismatches"]==v["block_mismatches"]==0 for v in ship)
validation["filters-cqr"]={"server":d,"corner_client":corner,"ship_client":ship}
xml=[E.parse(p).getroot().attrib for p in (repo/"build/test-results/test").glob("TEST-*.xml")]
tests={k:sum(int(r.get(k,0)) for r in xml) for k in ["tests","failures","errors","skipped"]}
assert tests=={"tests":204,"failures":0,"errors":0,"skipped":0}
validation["junit"]=tests
write("validation.json",validation)
runs=[]; groups={}
for mode in ["rgb","scalar"]:
 for version in ["before","after"]:
  for i in [1,2,3,4]:
   run=f"filters-perf-{mode}-{version}-{i}"
   paths=list((study/"runs"/run/"results").glob("*updates*.json"));assert len(paths)==1
   d=read(paths[0])["benchmark"]
   assert d["preflight"]["initial_light_verified"] and d["preflight"]["post_measurement_volume_verified"]
   assert d["plan"]["warmup_pairs"]==2000 and d["plan"]["measured_pairs"]==1000
   row={"run":run,"mode":mode,"version":version,"gc":d["measurement_gc"]}
   artifact="candidate.jar" if version=="before" else "phase2.jar"
   assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts"/artifact)
   for phase in d["phases"]:
    assert phase["all_samples_verified"] and phase["sample_count"]==1000
    assert all(s["light_verified"] for s in phase["samples"])
    row[phase["name"]]=phase["completion_summary_nanos"]["average"]/1000
    groups.setdefault((mode,version,phase["name"]),[]).append(row[phase["name"]])
   runs.append(row)
timing={"unit":"microseconds","summary":"median of independent JVM run means; four JVMs per variant", "runs":runs,"groups":[{"mode":k[0],"version":k[1],"phase":k[2],"median":statistics.median(v),"minimum":min(v),"maximum":max(v)} for k,v in groups.items()]}
write("timing.json",timing)
protocol=read(repo/"docs/research/rgb-block-prototype/protocol.json")
protocol["baseline_source"]="078df48"
protocol["order"]=[f"filters-perf-{mode}-{v}-{i}" for cohort in [1,3] for mode in ["rgb","scalar"] for v,i in [("before",cohort),("after",cohort),("after",cohort+1),("before",cohort+1)]]
protocol["repetitions_per_mode_per_version"]=4
protocol["summary"]="Median of independent JVM run means; retain every valid run and report ranges."
protocol["input_sha256"]={str(p.relative_to(study)).replace(chr(92),"/"):sha(p) for p in (study/"common-mods").rglob("*.jar")}
for n in ["frozen/options.txt","frozen/config/pulsar.cfg","frozen/config/relauncher.json"]:protocol["input_sha256"][n]=sha(study/n)
write("protocol.json",protocol)
write("artifacts.json",{"baseline_commit":"078df48","license":"LGPL-3.0 unchanged","sha256":{n:sha(study/"artifacts"/n) for n in ["candidate.jar","phase2.jar","filter-audit.jar","issue-audit-fresh.jar"]},"production_source_sha256":freeze})
shutil.copy2(study/"runs/filters-vanilla-final-2/screenshots/rgb-red-glass.png",out/"red-glass.png")
with zipfile.ZipFile(out/"raw-data.zip","w",zipfile.ZIP_DEFLATED) as z:
 for run in core+["filters-cqr"]+[r["run"] for r in runs]:
  for p in (study/"runs"/run/"results").glob("*.json"): z.write(p,f"runs/{run}/{p.name}")
  z.write(study/"runs"/run/"stage.json",f"runs/{run}/stage.json")
 for n in ["phase2-run.ps1","phase2-finish.ps1","phase2-extra.ps1","world.cjs"]:z.write(study/n,"reproduction/"+n)
 z.write(study/"helper/src/main/java/com/sumirelabs/rgbaudit/RgbAudit.java","reproduction/RgbAudit.java")
 for n in ["IssueAudit.java","IssueClientAudit.java","ShipAudit.java"]: z.write(study/"helper/src/main/java/com/sumirelabs/issueaudit"/n,"reproduction/"+n)
 z.write(study/"tools/nbt-read.mjs","reproduction/tools/nbt-read.mjs")
 z.write(Path(__file__),"reproduction/evidence.py")
assert zipfile.ZipFile(out/"raw-data.zip").testzip() is None
write("SHA256SUMS.json",{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!="SHA256SUMS.json"})
print(json.dumps(timing,indent=2))
