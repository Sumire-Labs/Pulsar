$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
if((Get-Content "$root\phase2\progress.json" -Raw|ConvertFrom-Json).stage -ne 'complete'){throw 'Initial cohort still running'}
$trials=@(
 @{run='filters-perf-rgb-before-3';artifact='candidate.jar';mode='RGB'},
 @{run='filters-perf-rgb-after-3';artifact='phase2.jar';mode='RGB'},
 @{run='filters-perf-rgb-after-4';artifact='phase2.jar';mode='RGB'},
 @{run='filters-perf-rgb-before-4';artifact='candidate.jar';mode='RGB'},
 @{run='filters-perf-scalar-before-3';artifact='candidate.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-after-3';artifact='phase2.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-after-4';artifact='phase2.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-before-4';artifact='candidate.jar';mode='SCALAR'}
)
foreach($trial in $trials){
 [IO.File]::WriteAllText("$root\phase2\extra-progress.json",(@{stage='timing';run=$trial.run}|ConvertTo-Json))
 & "$root\phase2-run.ps1" -Run $trial.run -Mode $trial.mode -Command 'lightbench updates 2000 1000' -Artifact $trial.artifact
 if((Get-Content "$root\runs\$($trial.run)\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw 'Extra timing failed'}
}
[IO.File]::WriteAllText("$root\phase2\extra-progress.json",'{"stage":"complete"}')
