$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
$game='C:\Users\s12kuma01\AppData\Roaming\PrismLauncher\instances\Pulsar-RGB-20261016\minecraft'
$first=Get-Content "$root\runs\filters-vanilla-final-2\results\rgb-audit.json" -Raw|ConvertFrom-Json
if($first.valid -ne $true){throw 'First filter validation failed'}
Copy-Item "$game\saves\Bench Updates" "$root\templates\filters-cache" -Recurse
function Audit([string]$run,[string]$mode='RGB',[string]$command='rgbaudit',[string]$template='flat',[switch]$Fast){
 [IO.File]::WriteAllText("$root\phase2\progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root\phase2-run.ps1" -Run $run -Artifact phase2.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}else{'rgb-audit.json'}
 $report=Get-Content "$root\runs\$run\results\$file" -Raw|ConvertFrom-Json
 if($report.valid -ne $true){throw "Audit failed $run"}
}
Audit 'filters-cache-reload' 'RGB' 'rgbaudit reload' 'filters-cache'
Audit 'filters-cache-migration' 'RGB' 'rgbaudit reload' 'cache'
Audit 'filters-celeritas-fast' 'RGB' 'rgbaudit' 'flat' -Fast
Audit 'filters-scalar-audit' 'SCALAR' 'rgbaudit scalar'
Audit 'filters-cqr' 'RGB' 'issueaudit ship' 'fresh-normal'
$trials=@(
 @{run='filters-perf-rgb-before-1';artifact='candidate.jar';mode='RGB'},
 @{run='filters-perf-rgb-after-1';artifact='phase2.jar';mode='RGB'},
 @{run='filters-perf-rgb-after-2';artifact='phase2.jar';mode='RGB'},
 @{run='filters-perf-rgb-before-2';artifact='candidate.jar';mode='RGB'},
 @{run='filters-perf-scalar-before-1';artifact='candidate.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-after-1';artifact='phase2.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-after-2';artifact='phase2.jar';mode='SCALAR'},
 @{run='filters-perf-scalar-before-2';artifact='candidate.jar';mode='SCALAR'}
)
foreach($trial in $trials){
 [IO.File]::WriteAllText("$root\phase2\progress.json",(@{stage='timing';run=$trial.run}|ConvertTo-Json))
 & "$root\phase2-run.ps1" -Run $trial.run -Mode $trial.mode -Command 'lightbench updates 2000 1000' -Artifact $trial.artifact
 $report=Get-Content "$root\runs\$($trial.run)\status.json" -Raw|ConvertFrom-Json
 if($report.valid -ne $true){throw "Timing failed $($trial.run)"}
}
[IO.File]::WriteAllText("$root\phase2\progress.json",'{"stage":"complete"}')
