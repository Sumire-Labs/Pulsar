param([string]$Run,[string]$Mode='RGB',[string]$Command='rgbaudit',[switch]$Celeritas,[switch]$FastCeleritas,[string]$Template='flat',[string]$Artifact='candidate.jar')
$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
$instance='C:\Users\s12kuma01\AppData\Roaming\PrismLauncher\instances\Pulsar-RGB-20261016'
$game="$instance\minecraft"
function Owned { @(Get-CimInstance Win32_Process -Filter "Name='javaw.exe'" | Where-Object CommandLine -like '*Pulsar-RGB-20261016*') }
if((Owned).Count){throw 'Owned RGB game is already running'}
if($Run -notmatch '^[a-z0-9-]+$'){throw 'Invalid run name'}
$out="$root\runs\$Run"
if(Test-Path $out){throw 'Run already exists'}
New-Item -ItemType Directory -Force $out | Out-Null
if(Test-Path $game){
    $resolved=[IO.Path]::GetFullPath($game)
    if($resolved -ne [IO.Path]::GetFullPath("$instance\minecraft")){throw 'Unexpected game path'}
    Rename-Item -LiteralPath $resolved -NewName "minecraft-backup-$Run"
    [IO.File]::WriteAllText("$out\previous-instance-path.txt", "$instance\minecraft-backup-$Run")
}
New-Item -ItemType Directory -Force "$game\mods","$game\saves" | Out-Null
Copy-Item "$root\common-mods\*" "$game\mods" -Recurse
Copy-Item "$root\frozen\config" "$game\config" -Recurse
Copy-Item "$root\frozen\options.txt" "$game\options.txt"
Copy-Item "$root\artifacts\$Artifact" "$game\mods\pulsar.jar"
if($Command -like 'issueaudit*'){
    Copy-Item "$root\artifacts\issue-audit-fresh.jar" "$game\mods\issue-audit.jar"
    if($Command -like 'issueaudit ship*'){Copy-Item 'E:\Github\Pulsar-Issues-20261015\cqr-mods\*.jar' "$game\mods"}
}
if($Command -like 'rgbaudit*'){Copy-Item "$root\artifacts\filter-audit.jar" "$game\mods\filter-audit.jar"}
if($FastCeleritas){
    $relaunch=Get-Content "$game\config\relauncher.json" -Raw|ConvertFrom-Json
    $relaunch.args += ' -Dceleritas.useVintageFastBlockRenderer=true'
    $relaunch|ConvertTo-Json|Set-Content "$game\config\relauncher.json" -Encoding UTF8
}
if($Celeritas){Copy-Item 'E:\Github\Pulsar-Issues-20261015\compat-mods\celeritas*.jar' "$game\mods"}
$cfg=Get-Content "$game\config\pulsar.cfg" -Raw
$cfg=[regex]::Replace($cfg,'(?m)^\s*S:lightingMode=.*$','')
$cfg=$cfg.Replace('general {',"general {`n    S:lightingMode=$Mode")
[IO.File]::WriteAllText("$game\config\pulsar.cfg",$cfg)
Copy-Item "$root\templates\$Template" "$game\saves\Bench Updates" -Recurse
& node "$root\world.cjs" "$game\saves\Bench Updates" candidate updates $Run $Command
if($LASTEXITCODE -ne 0){throw 'World setup failed'}
$resultPath="$game\saves\Bench Updates\lightbench-results"
if(Test-Path $resultPath){
    if([IO.Path]::GetFullPath($resultPath) -ne [IO.Path]::GetFullPath("$instance\minecraft\saves\Bench Updates\lightbench-results")){throw 'Unexpected result path'}
    $archive=[IO.Path]::GetFullPath("$out\inherited-results")
    if(-not $archive.StartsWith([IO.Path]::GetFullPath("$root\runs")+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected results archive'}
    Move-Item -LiteralPath $resultPath -Destination $archive
}
New-Item -ItemType Directory -Force $resultPath | Out-Null
[IO.File]::WriteAllText("$game\lightbench-variant.txt",'candidate')
[IO.File]::WriteAllText("$game\four-engine-bench.marker",'disposable RGB validation')
[IO.File]::WriteAllText("$game\four-engine-mode.txt",'updates')
[IO.File]::WriteAllText("$out\stage.json",(@{mode=$Mode;command=$Command;artifact=$Artifact;sha256=(Get-FileHash "$game\mods\pulsar.jar").Hash;celeritas=[bool]$Celeritas;fast_celeritas=[bool]$FastCeleritas}|ConvertTo-Json))
Start-Process 'C:\Users\s12kuma01\AppData\Local\Programs\PrismLauncher\prismlauncher.exe' -ArgumentList '-l','Pulsar-RGB-20261016','--offline','Serrecable' -WindowStyle Hidden
$seen=$false;$deadline=[DateTime]::UtcNow.AddMinutes(15)
while([DateTime]::UtcNow -lt $deadline){
    Start-Sleep -Seconds 2
    $processes=Owned
    if($processes.Count){$seen=$true}
    if($seen -and -not $processes.Count){break}
}
if((Owned).Count){throw 'RGB game timed out; retained for diagnosis'}
Copy-Item "$game\logs\latest.log" "$out\game.log"
if(Test-Path "$game\saves\Bench Updates\lightbench-results"){Copy-Item "$game\saves\Bench Updates\lightbench-results" "$out\results" -Recurse}
if(Test-Path "$game\screenshots"){Copy-Item "$game\screenshots" "$out\screenshots" -Recurse}
$valid=Test-Path "$out\results\observer.json"
if($Command -like 'rgbaudit*'){$valid=(Test-Path "$out\results\rgb-audit.json") -and ((Get-Content "$out\results\rgb-audit.json" -Raw|ConvertFrom-Json).valid -eq $true)}
[IO.File]::WriteAllText("$out\status.json",(@{valid=$valid;finished=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
Write-Output "RGB run $Run valid=$valid"
