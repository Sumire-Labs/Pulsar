package com.sumirelabs.actoraudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.*;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.light.WorldLightManager;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.client.*;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.command.*;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.*;
import java.nio.*;
import java.nio.file.*;
import java.util.concurrent.CompletableFuture;

/** Owned disposable native diagnostics; never part of the production mod. */
@Mod(modid="actoraudit",name="RGB Actor Audit",version="1",dependencies="required-after:pulsar",clientSideOnly=true)
public final class ActorAudit {
    private static final int X=20000,Y=80,Z=20032;
    private WorldServer world;
    private int serverStep=-1,serverTicks,waited;
    private boolean sent;
    private static volatile CompletableFuture<JsonObject> result;
    private static boolean clientSetup,active,skyFixture,dayFixture;
    private static int clientTicks;
    private static final JsonObject CLIENT=new JsonObject();
    private static Framebuffer target;
    private static boolean captured,sheep,tile,hand,fast;
    private static BufferBuilder fastBuffer;
    private static int fastStart,fastStride,fastOffset;
    private static int[][] fastExpected;
    private static BufferBuilder particleBuffer;
    private static int particleStart,particleStride,particleOffset;
    private static int[][] particleExpected;
    private static String particleLabel;
    private static int list;
    private static int[] savedUnit;
    private static final int[] ENV_PROBE={GL11.GL_TEXTURE_ENV_MODE,GL13.GL_COMBINE_RGB,GL13.GL_SOURCE0_RGB,GL13.GL_SOURCE1_RGB,GL13.GL_OPERAND0_RGB,GL13.GL_OPERAND1_RGB,GL13.GL_COMBINE_ALPHA,GL13.GL_SOURCE0_ALPHA,GL13.GL_OPERAND0_ALPHA,GL13.GL_RGB_SCALE,GL11.GL_ALPHA_SCALE};
    @Mod.EventHandler public void preInit(FMLPreInitializationEvent e) {
        RenderingRegistry.registerEntityRenderingHandler(Probe.class,ProbeRenderer::new);
        ClientRegistry.bindTileEntitySpecialRenderer(ProbeSign.class,new SignRenderer());
        ClientRegistry.bindTileEntitySpecialRenderer(ProbeFastSign.class,new FastSignRenderer());
    }
    @Mod.EventHandler public void init(FMLInitializationEvent e) {
        BlockLightColors.register(Blocks.GLOWSTONE.getDefaultState(),15,0,0);
        BlockLightColors.register(Blocks.LIT_PUMPKIN.getDefaultState(),0,15,0);
        BlockLightColors.register(Blocks.SEA_LANTERN.getDefaultState(),0,0,15);
        BlockLightFilters.register(Blocks.GLASS.getDefaultState(),15,0,0);
        MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "actoraudit";}
            public String getUsage(ICommandSender s){return "/actoraudit";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer s,ICommandSender sender,String[] args){dayFixture=args.length>0&&args[0].equals("day");skyFixture=dayFixture||args.length>0&&args[0].equals("sky");world=(WorldServer)sender.getEntityWorld();serverStep=0;serverTicks=0;}
        });
    }
    private WorldLightManager manager(){return ((PulsarWorld)world).pulsar$getLightManager();}
    @SubscribeEvent public void server(TickEvent.ServerTickEvent e) {
        if(e.phase!=TickEvent.Phase.END||serverStep<0||++serverTicks<20)return;serverTicks=0;
        try {
            if(serverStep==0) {
                if(dayFixture){world.getGameRules().setOrCreateGameRule("doDaylightCycle","false");world.setWorldTime(6000);}
                for(int cx=(X>>4)-2;cx<=(X>>4)+3;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
                for(int x=X;x<X+32;x++)for(int y=Y;y<Y+13;y++)for(int z=Z;z<Z+32;z++)
                    world.setBlockState(new BlockPos(x,y,z),skyFixture&&y==Y+12?Blocks.GLASS.getDefaultState():x==X||x==X+31||y==Y||y==Y+12||z==Z||z==Z+31?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
                world.setBlockState(new BlockPos(X+11,Y+2,Z+11),Blocks.STANDING_SIGN.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+12,Y+2,Z+10),Blocks.STANDING_SIGN.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+8,Y+3,Z+8),Blocks.GLOWSTONE.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+24,Y+3,Z+8),Blocks.LIT_PUMPKIN.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+16,Y+3,Z+24),Blocks.SEA_LANTERN.getDefaultState(),3);
                if(skyFixture)for(int cx=X>>4;cx<=(X+31)>>4;cx++)for(int cz=Z>>4;cz<=(Z+31)>>4;cz++)manager().forceRelightChunk(cx,cz);
                var player=(EntityPlayerMP)world.playerEntities.get(0);
                player.setGameType(GameType.CREATIVE);player.capabilities.isFlying=true;player.sendPlayerAbilities();
                player.connection.setPlayerLocation(X+16.5,Y+7,Z+29.5,180,15);
                world.getPlayerChunkMap().updateMovingPlayer(player);
                serverStep=1;return;
            }
            if(serverStep==1) {
                if(manager().hasUpdates()){if(++waited>120)throw new IllegalStateException("Actor lighting did not drain");return;}
                if(!sent){
                    for(int cx=X>>4;cx<=(X+31)>>4;cx++)for(int cz=Z>>4;cz<=(Z+31)>>4;cz++){
                        var entry=world.getPlayerChunkMap().getEntry(cx,cz);if(entry!=null)for(var p:world.playerEntities)entry.sendToPlayer((EntityPlayerMP)p);
                    }
                    sent=true;result=new CompletableFuture<>();serverStep=2;return;
                }
            }
            if(serverStep==2&&result.isDone())finish(result.join());
        }catch(Throwable t){t.printStackTrace();var d=new JsonObject();d.addProperty("valid",false);d.addProperty("failure",t.toString());finish(d);}
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent e) {
        if(e.phase!=TickEvent.Phase.END||result==null||result.isDone())return;
        Minecraft mc=Minecraft.getMinecraft();
        try {
            if(mc.world==null)return;
            if(++clientTicks>600)throw new IllegalStateException("Actor setup/render timeout: "+CLIENT);
            boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();
            if(!clientSetup) {
                if(mc.world.getBlockState(new BlockPos(X+8,Y+3,Z+8)).getBlock()!=Blocks.GLOWSTONE || rgb&&!RgbClient.active())return;
                if(skyFixture&&rgb&&!RgbClient.skyActive())return;
                CLIENT.addProperty("colored_sky_fixture",skyFixture);
                int tint=rgb?RgbClient.tintAbgr(-1,X+10.5,Y+5,Z+10.5):-1;
                if(rgb&&(tint&0xFFFFFF)==0xFFFFFF)return;
                if(dayFixture&&rgb){
                    var anchor=new BlockPos(X+10,Y+5,Z+10);var snapshot=((RgbChunk)mc.world.getChunk(anchor.getX()>>4,anchor.getZ()>>4)).pulsar$getRgbSkySnapshot();
                    CLIENT.addProperty("setup_tint",Integer.toHexString(tint));CLIENT.addProperty("setup_sky",snapshot==null?-1:snapshot.get(anchor.getX(),anchor.getY(),anchor.getZ()));
                    CLIENT.addProperty("setup_sky_canonical",mc.world.getLightFor(EnumSkyBlock.SKY,anchor));CLIENT.addProperty("setup_sky_subtracted",mc.world.getSkylightSubtracted());CLIENT.addProperty("setup_column_height",mc.world.getHeight(anchor).getY());
                    if((tint&255)>=(tint>>>8&255))return;
                }
                CLIENT.addProperty("daylight_sky_fixture",dayFixture);
                target=new Framebuffer(32,32,true);mc.getFramebuffer().bindFramebuffer(true);
                Probe entity=new Probe(mc.world);anchor(entity,X+10.5,Y+4,Z+10.5);mc.world.addEntityToWorld(-42001,entity);
                EntitySheep animal=new EntitySheep(mc.world);animal.setNoAI(true);animal.setNoGravity(true);anchor(animal,X+12.5,Y+1,Z+12.5);mc.world.addEntityToWorld(-42002,animal);
                ProbeSign sign=new ProbeSign();mc.world.setTileEntity(new BlockPos(X+11,Y+2,Z+11),sign);
                mc.world.setTileEntity(new BlockPos(X+12,Y+2,Z+10),new ProbeFastSign());
                for(String kind:new String[]{"normal","bulk","negative","fullbright","sentinel"})mc.effectRenderer.addEffect(new ProbeParticle(mc.world,kind));
                active=true;clientSetup=true;clientTicks=0;return;
            }
            if(++clientTicks>400)throw new IllegalStateException("Actor renderer probe timed out: "+CLIENT);
            if(fastExpected!=null&&!fast){
                for(int i=0;i<4;i++)for(int c=0;c<4;c++){
                    int actual=Byte.toUnsignedInt(fastBuffer.getByteBuffer().duplicate().clear().get((fastStart+i)*fastStride+fastOffset+c));
                    if(Math.abs(actual-fastExpected[i][c])>1)throw new IllegalStateException("Fast TESR vertex mismatch: "+actual+" expected "+fastExpected[i][c]);
                }
                fast=true;CLIENT.addProperty("fast_tesr_vertices",true);
            }
            if(captured&&sheep&&tile&&hand&&fast&&CLIENT.has("particle_normal")&&CLIENT.has("particle_bulk")&&CLIENT.has("particle_negative")&&CLIENT.has("particle_fullbright")&&CLIENT.has("reserved_texture_state_restored")&&clientTicks>5){
                net.minecraft.util.ScreenShotHelper.saveScreenshot(mc.gameDir,"actor-audit.png",mc.displayWidth,mc.displayHeight,mc.getFramebuffer());
                active=false;mc.world.removeEntityFromWorld(-42001);mc.world.removeEntityFromWorld(-42002);
                CLIENT.addProperty("draw_depth_after_frame",RgbDrawContext.state().depth());
                CLIENT.addProperty("world_scope_after_frame",RgbDrawContext.state().worldPass());
                CLIENT.addProperty("valid",RgbDrawContext.state().depth()==0&&!RgbDrawContext.state().worldPass());
                result.complete(CLIENT);
            }
        }catch(Throwable t){t.printStackTrace();active=false;CLIENT.addProperty("valid",false);CLIENT.addProperty("failure",t.toString());result.complete(CLIENT);}
    }
    private static void anchor(Entity entity,double x,double y,double z){entity.setPosition(x,y,z);entity.lastTickPosX=entity.prevPosX=x;entity.lastTickPosY=entity.prevPosY=y;entity.lastTickPosZ=entity.prevPosZ=z;}
    @SubscribeEvent public void living(RenderLivingEvent.Pre<?> e) {
        if(!active||!(e.getEntity() instanceof EntitySheep))return;
        boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();
        if(RgbDrawContext.state().active()!=rgb)throw new IllegalStateException("Living renderer scope missing");
        CLIENT.addProperty("living_scope",true);sheep=true;
    }
    private static int[] unitState(){
        int activeUnit=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE),last=GL11.glGetInteger(GL13.GL_MAX_TEXTURE_UNITS)-1;
        GL13.glActiveTexture(GL13.GL_TEXTURE0+last);
        try {
            int[] values=new int[23];
            for(int i=0;i<ENV_PROBE.length;i++)values[i]=GL11.glGetTexEnvi(GL11.GL_TEXTURE_ENV,ENV_PROBE[i]);
            int n=11;for(int target:new int[]{GL11.GL_TEXTURE_1D,GL11.GL_TEXTURE_2D,GL12.GL_TEXTURE_3D,GL13.GL_TEXTURE_CUBE_MAP})values[n++]=GL11.glIsEnabled(target)?1:0;
            for(int binding:new int[]{GL11.GL_TEXTURE_BINDING_1D,GL11.GL_TEXTURE_BINDING_2D,GL12.GL_TEXTURE_BINDING_3D,GL13.GL_TEXTURE_BINDING_CUBE_MAP})values[n++]=GL11.glGetInteger(binding);
            FloatBuffer color=BufferUtils.createFloatBuffer(4);GL11.glGetTexEnv(GL11.GL_TEXTURE_ENV,GL11.GL_TEXTURE_ENV_COLOR,color);
            for(int i=0;i<4;i++)values[n++]=Float.floatToIntBits(color.get(i));return values;
        }finally {GL13.glActiveTexture(activeUnit);}
    }
    @SubscribeEvent public void renderFrame(TickEvent.RenderTickEvent e){
        if(!active)return;
        try {
            if(e.phase==TickEvent.Phase.START)savedUnit=unitState();
            else if(savedUnit!=null){
                int[] after=unitState();if(!java.util.Arrays.equals(savedUnit,after))throw new IllegalStateException("Reserved texture unit leaked across frame: "+java.util.Arrays.toString(savedUnit)+" -> "+java.util.Arrays.toString(after));
                CLIENT.addProperty("reserved_texture_state_restored",true);savedUnit=null;
            }
        }catch(Throwable t){t.printStackTrace();active=false;CLIENT.addProperty("valid",false);CLIENT.addProperty("failure",t.toString());result.complete(CLIENT);}
    }
    @SubscribeEvent public void hand(RenderSpecificHandEvent e) {
        if(!active)return;
        boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();
        if(RgbDrawContext.state().active()!=rgb)throw new IllegalStateException("Hand renderer scope missing");
        CLIENT.addProperty("hand_scope",true);hand=true;
    }
    private static final class ProbeParticle extends Particle {
        private final String kind;
        ProbeParticle(World world,String kind){super(world,X+10.5,Y+4,Z+10.5);this.kind=kind;particleMaxAge=1000;particleRed=.4f;particleGreen=.7f;particleBlue=.2f;particleAlpha=.25f;}
        public void onUpdate(){prevPosX=posX;prevPosY=posY;prevPosZ=posZ;}
        public int getBrightnessForRender(float partial){return kind.equals("fullbright")?0xF000F0:kind.equals("negative")?-1:super.getBrightnessForRender(partial);}
        public void renderParticle(BufferBuilder buffer,Entity camera,float partial,float rx,float rz,float ryz,float rxy,float rxz){
            if(!active)return;
            try {
                if(particleExpected!=null){
                    ByteBuffer bytes=particleBuffer.getByteBuffer();
                    for(int i=0;i<4;i++)for(int c=0;c<4;c++){
                        int actual=Byte.toUnsignedInt(bytes.get((particleStart+i)*particleStride+particleOffset+c));
                        if(Math.abs(actual-particleExpected[i][c])>1)throw new IllegalStateException("Particle "+particleLabel+" vertex mismatch channel "+c+": "+actual+" expected "+particleExpected[i][c]);
                    }
                    CLIENT.addProperty("particle_"+particleLabel,true);particleExpected=null;
                }
                if(kind.equals("sentinel"))return;
                int start=buffer.getVertexCount();
                if(kind.equals("bulk")){
                    BufferBuilder temp=new BufferBuilder(256);temp.begin(GL11.GL_QUADS,buffer.getVertexFormat());
                    super.renderParticle(temp,camera,partial,rx,rz,ryz,rxy,rxz);buffer.addVertexData(temp.getVertexState().getRawBuffer());
                }else super.renderParticle(buffer,camera,partial,rx,rz,ryz,rxy,rxz);
                if(buffer.getVertexCount()!=start+4)throw new IllegalStateException("Unexpected particle geometry");
                particleBuffer=buffer;particleStart=start;particleStride=buffer.getVertexFormat().getSize();particleOffset=buffer.getVertexFormat().getColorOffset();particleLabel=kind;
                particleExpected=new int[4][4];int tint=kind.equals("fullbright")?-1:RgbDrawContext.state().tint();
                for(int i=0;i<4;i++)for(int c=0;c<4;c++){
                    int value=Byte.toUnsignedInt(buffer.getByteBuffer().get((start+i)*particleStride+particleOffset+c));
                    particleExpected[i][c]=c==3?value:value*(tint>>>(c*8)&255)/255;
                }
            }catch(Throwable t){t.printStackTrace();active=false;CLIENT.addProperty("valid",false);CLIENT.addProperty("failure",t.toString());result.complete(CLIENT);}
        }
    }
    public static final class ProbeFastSign extends TileEntitySign { public boolean hasFastRenderer(){return true;} }
    private static final class FastSignRenderer extends TileEntitySpecialRenderer<ProbeFastSign> {
        public void renderTileEntityFast(ProbeFastSign sign,double x,double y,double z,float partial,int destroy,float alpha,BufferBuilder buffer){
            if(!active||fast)return;
            if(RgbDrawContext.state().active()!=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled())throw new IllegalStateException("Fast TESR RGB scope missing");
            int start=buffer.getVertexCount();
            for(int i=0;i<4;i++)buffer.pos(x+(i==1||i==2?.9:.1),y+(i>=2?.9:.1),z).color(.4f,.7f,.2f,.25f).tex(0,0).lightmap(0,0).endVertex();
            fastBuffer=buffer;fastStart=start;fastStride=buffer.getVertexFormat().getSize();fastOffset=buffer.getVertexFormat().getColorOffset();
            fastExpected=new int[4][4];int tint=RgbDrawContext.state().tint();
            for(int i=0;i<4;i++)for(int c=0;c<4;c++){
                int value=Byte.toUnsignedInt(buffer.getByteBuffer().get((start+i)*fastStride+fastOffset+c));fastExpected[i][c]=c==3?value:value*(tint>>>(c*8)&255)/255;
            }
        }
    }
    public static final class ProbeSign extends TileEntitySign {}
    private static final class SignRenderer extends TileEntitySpecialRenderer<ProbeSign> {
        public void render(ProbeSign sign,double x,double y,double z,float partial,int destroy,float alpha) {
            if(!active||tile)return;
            try {
                boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();
                if(RgbDrawContext.state().active()!=rgb)throw new IllegalStateException("TESR scope missing");
                int tint=rgb?RgbDrawContext.state().tint():-1;
                int[] colored=pixel(false);int token=RgbDrawContext.enterUnlit();int[] neutral;
                try {neutral=pixel(false);}finally {RgbDrawContext.close(token);}
                for(int c=0;c<3;c++)if(Math.abs(colored[c]-Math.round(neutral[c]*((tint>>>(c*8)&255)/255f)))>2)throw new IllegalStateException("TESR GPU mismatch");
                if(colored[3]!=neutral[3])throw new IllegalStateException("TESR alpha changed");
                CLIENT.addProperty("tesr_gpu_pixel",true);CLIENT.add("tesr_rgba",new Gson().toJsonTree(colored));tile=true;
            }catch(Throwable t){t.printStackTrace();active=false;CLIENT.addProperty("valid",false);CLIENT.addProperty("failure",t.toString());result.complete(CLIENT);}
        }
    }
    public static final class Probe extends Entity {
        boolean fail;
        public Probe(World world){super(world);setSize(1,1);setNoGravity(true);}
        protected void entityInit(){}
        protected void readEntityFromNBT(NBTTagCompound nbt){}
        protected void writeEntityToNBT(NBTTagCompound nbt){}
    }
    private static final class ProbeRenderer extends Render<Probe> {
        ProbeRenderer(RenderManager manager){super(manager);}
        protected ResourceLocation getEntityTexture(Probe entity){return new ResourceLocation("minecraft","textures/blocks/wool_colored_white.png");}
        public void doRender(Probe entity,double x,double y,double z,float yaw,float partial) {
            if(entity.fail){OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit,240,240);throw new IllegalStateException("intentional audit renderer exception");}
            if(active&&!captured)capture(entity);
            GL11.glPushAttrib(GL11.GL_ENABLE_BIT|GL11.GL_CURRENT_BIT);
            GlStateManager.pushMatrix();GlStateManager.translate(x,y,z);
            try {GL11.glDisable(GL11.GL_TEXTURE_2D);GL11.glDisable(GL11.GL_LIGHTING);quad();}
            finally {GlStateManager.popMatrix();GL11.glPopAttrib();}
        }
    }
    private static void quad(){
        GL11.glColor4f(.4f,.7f,.2f,.25f);GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex3d(.1,.1,0);GL11.glVertex3d(.9,.1,0);GL11.glVertex3d(.9,.9,0);GL11.glVertex3d(.1,.9,0);GL11.glEnd();
    }
    private static int[] pixel(boolean displayList) {
        int framebuffer=GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);int matrix=GL11.glGetInteger(GL11.GL_MATRIX_MODE);
        GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
        GlStateManager.matrixMode(GL11.GL_PROJECTION);GlStateManager.pushMatrix();GlStateManager.loadIdentity();GlStateManager.ortho(0,1,0,1,-1,1);
        GlStateManager.matrixMode(GL11.GL_MODELVIEW);GlStateManager.pushMatrix();GlStateManager.loadIdentity();
        try {
            target.bindFramebuffer(true);GL11.glClearColor(0,0,0,0);GL11.glClear(GL11.GL_COLOR_BUFFER_BIT|GL11.GL_DEPTH_BUFFER_BIT);
            GL11.glColorMask(true,true,true,true);GL11.glDisable(GL11.GL_SCISSOR_TEST);GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK,GL11.GL_FILL);GL11.glDisable(GL11.GL_BLEND);GL11.glDisable(GL11.GL_ALPHA_TEST);GL11.glDisable(GL11.GL_DEPTH_TEST);GL11.glDisable(GL11.GL_LIGHTING);GL11.glDisable(GL11.GL_CULL_FACE);GL11.glDisable(GL11.GL_FOG);
            int last=GL11.glGetInteger(GL13.GL_MAX_TEXTURE_UNITS)-1;
            for(int i=0;i<=last;i++)if(i!=last){GL13.glActiveTexture(GL13.GL_TEXTURE0+i);GL11.glDisable(GL11.GL_TEXTURE_1D);GL11.glDisable(GL11.GL_TEXTURE_2D);GL11.glDisable(GL12.GL_TEXTURE_3D);GL11.glDisable(GL13.GL_TEXTURE_CUBE_MAP);}
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            if(displayList)GL11.glCallList(list);else quad();
            ByteBuffer bytes=BufferUtils.createByteBuffer(4);GL11.glReadPixels(16,16,1,1,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,bytes);
            return new int[]{Byte.toUnsignedInt(bytes.get(0)),Byte.toUnsignedInt(bytes.get(1)),Byte.toUnsignedInt(bytes.get(2)),Byte.toUnsignedInt(bytes.get(3))};
        }finally{
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER,framebuffer);GlStateManager.matrixMode(GL11.GL_MODELVIEW);GlStateManager.popMatrix();
            GlStateManager.matrixMode(GL11.GL_PROJECTION);GlStateManager.popMatrix();GlStateManager.matrixMode(matrix);GL11.glPopAttrib();
        }
    }
    private static void capture(Probe entity) {
        try {
            boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();
            if(RgbDrawContext.state().active()!=rgb)throw new IllegalStateException("Entity scope was not entered");
            int tint=rgb?RgbDrawContext.state().tint():-1;
            if(rgb&&(tint&0xFFFFFF)==0xFFFFFF)return;
            int token=RgbDrawContext.enterUnlit();int[] neutral;
            try {neutral=pixel(false);}finally{RgbDrawContext.close(token);}
            int[] colored=pixel(false);
            if(rgb){
                int depth=RgbDrawContext.state().depth();float oldU=OpenGlHelper.lastBrightnessX,oldV=OpenGlHelper.lastBrightnessY;
                Probe nested=new Probe(entity.world);anchor(nested,X+16.5,Y+4,Z+23.5);nested.fail=true;boolean threw=false;
                try {Minecraft.getMinecraft().getRenderManager().renderEntity(nested,0,0,0,0,0,false);}
                catch(net.minecraft.util.ReportedException expected){
                    Throwable cause=expected;while(cause.getCause()!=null)cause=cause.getCause();
                    if(!"intentional audit renderer exception".equals(cause.getMessage()))throw expected;threw=true;
                }
                if(!threw||RgbDrawContext.state().depth()!=depth||RgbDrawContext.state().tint()!=tint||OpenGlHelper.lastBrightnessX!=oldU||OpenGlHelper.lastBrightnessY!=oldV)throw new IllegalStateException("Nested renderer exception leaked state");
                int[] restored=pixel(false);for(int c=0;c<4;c++)if(restored[c]!=colored[c])throw new IllegalStateException("Nested renderer exception leaked GPU tint");
                CLIENT.addProperty("nested_renderer_exception_restored",true);
            }
            list=GL11.glGenLists(1);GL11.glNewList(list,GL11.GL_COMPILE);quad();GL11.glEndList();
            int[] cached=pixel(true);
            for(int c=0;c<4;c++)if(Math.abs(cached[c]-colored[c])>1)throw new IllegalStateException("Cached model differed from immediate geometry");
            int neutralToken=RgbDrawContext.enterUnlit();
            try {int[] cachedNeutral=pixel(true);for(int c=0;c<4;c++)if(Math.abs(cachedNeutral[c]-neutral[c])>1)throw new IllegalStateException("Cached model retained RGB from compilation");}
            finally {RgbDrawContext.close(neutralToken);GL11.glDeleteLists(list,1);list=0;}
            CLIENT.addProperty("display_list_replay",true);
            int[] expectedNeutral={102,179,51,64};for(int c=0;c<4;c++)if(Math.abs(neutral[c]-expectedNeutral[c])>2)throw new IllegalStateException("Neutral GPU probe did not draw: "+java.util.Arrays.toString(neutral));
            for(int c=0;c<3;c++)if(Math.abs(colored[c]-Math.round(neutral[c]*((tint>>>(c*8)&255)/255f)))>2)throw new IllegalStateException("GPU color mismatch neutral="+java.util.Arrays.toString(neutral)+" colored="+java.util.Arrays.toString(colored)+" tint="+Integer.toHexString(tint));
            if(colored[3]!=neutral[3])throw new IllegalStateException("RGB changed alpha");
            float u=OpenGlHelper.lastBrightnessX,v=OpenGlHelper.lastBrightnessY;int[] full;
            try {OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit,240,240);full=pixel(false);}
            finally{OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit,u,v);}
            for(int c=0;c<4;c++)if(Math.abs(full[c]-neutral[c])>1)throw new IllegalStateException("Fullbright changed");
            CLIENT.add("neutral_rgba",new Gson().toJsonTree(neutral));CLIENT.add("rgb_rgba",new Gson().toJsonTree(colored));CLIENT.add("fullbright_rgba",new Gson().toJsonTree(full));
            CLIENT.addProperty("entity_tint",Integer.toHexString(tint));CLIENT.addProperty("fixed_texture_units",GL11.glGetInteger(GL13.GL_MAX_TEXTURE_UNITS));
            int error=GL11.glGetError();if(error!=0)throw new IllegalStateException("OpenGL error "+error);
            CLIENT.addProperty("raw_gl_entity_pixel",true);captured=true;
        }catch(Throwable t){t.printStackTrace();CLIENT.addProperty("valid",false);CLIENT.addProperty("failure",t.toString());active=false;result.complete(CLIENT);}
    }
    private void finish(JsonObject report) {
        serverStep=-1;
        try{Path out=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/actor-audit.json");Files.createDirectories(out.getParent());Files.writeString(out,new GsonBuilder().setPrettyPrinting().create().toJson(report));}
        catch(Exception e){throw new RuntimeException(e);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("ACTOR_AUDIT_FINISHED "+report);
    }
}


