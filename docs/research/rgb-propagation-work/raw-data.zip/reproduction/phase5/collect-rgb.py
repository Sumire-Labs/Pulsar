from pathlib import Path
import json,statistics,hashlib
r=Path('E:/Github/Pulsar-RGB-20261016');rows=[]
for p in sorted((r/'runs').glob('trim-perf-*/results/*updates*.json')):
 d=json.loads(p.read_text())['benchmark'];run=p.parent.parent.name;parts=run.split('-')
 assert d['plan']['warmup_pairs']==2000 and d['plan']['measured_pairs']==1000
 assert d['preflight']['initial_light_verified'] and d['preflight']['post_measurement_volume_verified']
 stage=json.loads((p.parent.parent/'stage.json').read_text());assert stage['sha256'].lower()==hashlib.sha256((r/'artifacts'/stage['artifact']).read_bytes()).hexdigest()
 row={'run':run,'fixture':parts[2],'version':parts[3],'gc':d['measurement_gc']}
 for phase in d['phases']:
  assert phase['sample_count']==1000 and phase['all_samples_verified'] and all(s['light_verified'] for s in phase['samples'])
  row[phase['name']]=phase['completion_summary_nanos']['average']/1000
 rows.append(row)
(r/'phase5/rgb-partial.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Validated RGB JVMs:',len(rows))
for mode in ['rgb','filtered']:
 for v in ['before','after']:
  a=[x for x in rows if x['fixture']==mode and x['version']==v]
  if a:print(mode,v,'n='+str(len(a)),{p:round(statistics.median(x[p] for x in a),1) for p in ['sky_remove','sky_place','block_place','block_remove']})
