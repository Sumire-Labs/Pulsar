from pathlib import Path
import hashlib,json,struct,re
r=Path('E:/Github/Pulsar-RGB-20261016')
a=r/'runs/scalar-export-before-final/mixin-export/class';b=r/'runs/scalar-export-after-final/mixin-export/class'
required=['net/minecraft/world/chunk/BlockStateContainer.class','net/minecraft/world/chunk/Chunk.class','net/minecraft/block/state/BlockStateContainer$StateImplementation.class','net/minecraft/world/World.class','net/minecraft/world/WorldServer.class']
def parse(data):
 count=struct.unpack_from('>H',data,8)[0];i=1;off=10;pool=[]
 while i<count:
  tag=data[off];off+=1
  if tag==1:
   n=struct.unpack_from('>H',data,off)[0];off+=2;v=data[off:off+n];off+=n
  else:
   n={3:4,4:4,5:8,6:8,7:2,8:2,9:4,10:4,11:4,12:4,15:3,16:2,17:4,18:4,19:2,20:2}[tag];v=data[off:off+n];off+=n
  pool.append((tag,v));i+=2 if tag in [5,6] else 1
 return pool,data[off:]
uuid=re.compile(rb'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')
handler=re.compile(rb'(handler|redirect|modifyArg|modifyArgs|modifyConstant|modifyVariable)\$[a-z0-9]{6}\$(.+)')
proof={}
for n in required:
 assert (a/n).is_file() and (b/n).is_file(),n
 x=(a/n).read_bytes();y=(b/n).read_bytes();xp,xr=parse(x);yp,yr=parse(y)
 assert x[:10]==y[:10] and len(xp)==len(yp) and xr==yr,'Class structure/code/attributes changed: '+n
 differences=[];mapping={}
 for index,(u,v) in enumerate(zip(xp,yp)):
  if u==v:continue
  assert u[0]==v[0]==1,'Non-string constant changed: '+n
  if uuid.fullmatch(u[1]) and uuid.fullmatch(v[1]):kind='Mixin session UUID'
  else:
   um,vm=handler.fullmatch(u[1]),handler.fullmatch(v[1])
   assert um and vm and um.group(1,2)==vm.group(1,2),'Unexpected constant changed: '+repr((n,u,v))
   kind='Generated Mixin handler identifier'
  assert u[1] not in mapping or mapping[u[1]]==v[1]
  mapping[u[1]]=v[1]
  differences.append({'pool_entry':index,'kind':kind,'before':u[1].decode(),'after':v[1].decode()})
 assert len(set(mapping.values()))==len(mapping),'Non-bijective handler rename'
 proof[n]={'before_sha256':hashlib.sha256(x).hexdigest(),'after_sha256':hashlib.sha256(y).hexdigest(),'same_class_structure_fields_instructions_and_attributes':True,'only_changed_utf8_constants':differences}
for base in [a,b]:
 data=(base/'net/minecraft/world/chunk/BlockStateContainer.class').read_bytes()
 for field in [b'pulsar$filterRevision',b'pulsar$filterCache',b'pulsar$filterWriteDepth']:assert field not in data
for run in ['scalar-export-before-final','scalar-export-after-final']:
 paths=list((r/'runs'/run/'results').glob('*updates*.json'));assert len(paths)==1
 d=json.loads(paths[0].read_text())['benchmark']
 assert d['plan']['warmup_pairs']==d['plan']['measured_pairs']==20
 assert d['preflight']['initial_light_verified'] and d['preflight']['post_measurement_volume_verified']
 assert all(x['all_samples_verified'] and x['sample_count']==20 and all(v['light_verified'] for v in x['samples']) for x in d['phases'])
(r/'phase5/transformed-proof.json').write_text(json.dumps({'targets':proof,'both_export_light_checks_passed':True,'both_palette_classes_have_no_filter_cache_fields':True,'diagnostic_export_flag_excluded_from_timed_runs':True},indent=2)+'\n')
print('SCALAR transformed targets match except generated session/handler IDs:',len(proof))
