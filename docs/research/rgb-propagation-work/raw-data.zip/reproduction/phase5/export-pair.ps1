$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
if((Get-Content "$root/phase5/progress.json" -Raw|ConvertFrom-Json).stage -ne 'complete'){throw 'SCALAR cohort must finish first'}
foreach($item in @(@{run='scalar-export-before-final';artifact='sky.jar'},@{run='scalar-export-after-final';artifact='white.jar'})) {
 & "$root/phase5/export-run.ps1" -Run $item.run -Artifact $item.artifact -Mode SCALAR -Command 'lightbench updates 20 20'
 if((Get-Content "$root/runs/$($item.run)/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw 'SCALAR export diagnostic failed'}
}
