while((Get-Content 'E:/Github/Pulsar-RGB-20261016/phase5/trim-progress.json' -Raw|ConvertFrom-Json).stage -ne 'complete'){Start-Sleep -Seconds 5}
$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
foreach($cohort in @(1,3)) {
 $order=if($cohort -eq 1) {@(@{v='before';i=$cohort},@{v='after';i=$cohort},@{v='after';i=$cohort+1},@{v='before';i=$cohort+1})}else{@(@{v='after';i=$cohort},@{v='before';i=$cohort},@{v='before';i=$cohort+1},@{v='after';i=$cohort+1})}
 foreach($item in $order) {
  $run="trim-long-rgb-$($item.v)-$($item.i)"
  [IO.File]::WriteAllText("$root/phase5/rgb-long-progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
  $artifact=if($item.v -eq 'before') {'white.jar'}else{'trim.jar'}
  & "$root/phase5/run.ps1" -Run $run -Mode RGB -Command 'lightbench updates 10000 5000' -Artifact $artifact
  if((Get-Content "$root/runs/$run/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
 }
}
[IO.File]::WriteAllText("$root/phase5/rgb-long-progress.json",'{"stage":"complete"}')
