$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
foreach($cohort in @(1,3,5,7)) {
 $order=if($cohort -in @(1,5)) {@(@{v='before';i=$cohort},@{v='after';i=$cohort},@{v='after';i=$cohort+1},@{v='before';i=$cohort+1})}else{@(@{v='after';i=$cohort},@{v='before';i=$cohort},@{v='before';i=$cohort+1},@{v='after';i=$cohort+1})}
 foreach($item in $order) {
  $run="scalar-repeat-$($item.v)-$($item.i)"
  [IO.File]::WriteAllText("$root/phase5/progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
  $artifact=if($item.v -eq 'before') {'sky.jar'}else{'white.jar'}
  & "$root/phase4-run.ps1" -Run $run -Mode SCALAR -Command 'lightbench updates 10000 5000' -Artifact $artifact
  if((Get-Content "$root/runs/$run/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
 }
}
[IO.File]::WriteAllText("$root/phase5/progress.json",'{"stage":"complete"}')
