from pathlib import Path
import zipfile,json,hashlib,struct,re
r=Path('E:/Github/Pulsar-RGB-20261016');p=r/'artifacts'
def constants(data):
 count=struct.unpack_from('>H',data,8)[0];i=1;off=10;out=[]
 while i<count:
  tag=data[off];off+=1
  if tag==1:
   n=struct.unpack_from('>H',data,off)[0];off+=2;v=data[off:off+n];off+=n
   out.append((tag,re.sub(rb'0\.5\.2-feat-rgb-engine\.[23]\.local\.dirty',b'VERSION',v)))
  else:
   n={3:4,4:4,5:8,6:8,7:2,8:2,9:4,10:4,11:4,12:4,15:3,16:2,17:4,18:4,19:2,20:2}[tag];out.append((tag,data[off:off+n]));off+=n
   if tag in [5,6]:i+=1
  i+=1
 return out,data[off:]
with zipfile.ZipFile(p/'sky.jar') as a,zipfile.ZipFile(p/'white.jar') as b:
 same=[n for n in a.namelist() if n.endswith('.class') and n in b.namelist() and a.read(n)==b.read(n)]
 diff=[n for n in sorted(set(a.namelist())|set(b.namelist())) if n not in a.namelist() or n not in b.namelist() or a.read(n)!=b.read(n)]
 for n in ['com/sumirelabs/pulsar/Pulsar.class','com/sumirelabs/pulsar/Reference.class']:assert constants(a.read(n))==constants(b.read(n)),n
 old=json.loads(a.read('pulsar.mixin-refmap.json'));new=json.loads(b.read('pulsar.mixin-refmap.json'))
 def subset(x,y):
  if isinstance(x,dict):return all(k in y and subset(v,y[k]) for k,v in x.items())
  return x==y
 assert subset(old,new),'Existing refmap changed'
 for n in ['com/sumirelabs/pulsar/light/engine/ScalarBlockEngine.class','com/sumirelabs/pulsar/light/engine/ScalarSkyEngine.class','com/sumirelabs/pulsar/light/engine/PulsarEngine.class','com/sumirelabs/pulsar/light/ParallelLightScheduler.class','com/sumirelabs/pulsar/core/RgbMixinSelection.class']:assert n in same,n
 proof={'baseline':'0a291d9','candidate':'2258d6e','byte_identical_class_count':len(same),'byte_identical_classes':{n:hashlib.sha256(a.read(n)).hexdigest() for n in sorted(same)},'changed_jar_entries':diff,'Pulsar_and_Reference_equal_except_version_constant':True,'old_refmap_entries_unchanged':True}
 (r/'phase5/static-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
 print('Identical classes:',len(same),'Main and Reference only version constants differ; old refmap mappings unchanged')
