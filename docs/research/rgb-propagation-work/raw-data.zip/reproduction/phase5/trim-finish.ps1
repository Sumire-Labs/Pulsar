$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function CheckExit([string]$message){if($LASTEXITCODE -ne 0){throw $message}}
if((Get-Content "$root/phase5/progress.json" -Raw|ConvertFrom-Json).stage -ne 'complete'){throw 'SCALAR cohort must finish first'}
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot'
$env:JAVA_TOOL_OPTIONS='-Djdk.net.unixdomain.tmpdir=E:/Github/Pulsar'
Push-Location 'E:/Github/Pulsar'
try {
 & .\gradlew.bat build --no-watch-fs
 CheckExit 'Production build failed'
 $jar=Get-ChildItem build/libs -Filter 'pulsar-*.jar' | Where-Object Name -NotMatch 'sources|javadoc|shadow|dev' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
 Copy-Item -LiteralPath $jar.FullName -Destination "$root/artifacts/trim.jar"
 $frozen=@{};Get-ChildItem src/main -File -Recurse | ForEach-Object { $path=[IO.Path]::GetRelativePath((Get-Location).Path,$_.FullName).Replace('\','/');$frozen[$path]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower() }
 [IO.File]::WriteAllText("$root/phase5/source-freeze.json",($frozen|ConvertTo-Json))
}finally{Pop-Location}
& "C:/Users/s12kuma01/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe" "$root/phase5/check-production-isolation.py"
CheckExit "SCALAR production isolation failed"
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root/phase5/trim-progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root/phase4-run.ps1" -Run $run -Artifact trim.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 if((Get-Content "$root/runs/$run/results/$file" -Raw|ConvertFrom-Json).valid -ne $true){throw "Audit failed $run"}
}
Audit 'trim-vanilla-final' 'skyaudit range'
Audit 'trim-celeritas-final' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'trim-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'trim-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'trim-block-regression' 'rgbaudit'
Audit 'trim-block-celeritas' 'rgbaudit' 'flat' 'RGB' -Fast
Audit 'trim-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'trim-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)) {
 foreach($mode in @('rgb','filtered')) {
  foreach($item in @(@{v='before';i=$cohort;artifact='white.jar'},@{v='after';i=$cohort;artifact='trim.jar'},@{v='after';i=$cohort+1;artifact='trim.jar'},@{v='before';i=$cohort+1;artifact='white.jar'})) {
   $run="trim-perf-$mode-$($item.v)-$($item.i)"
   [IO.File]::WriteAllText("$root/phase5/trim-progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
   $command=if($mode -eq 'filtered'){'function perfbench:filteredupdates'}else{'lightbench updates 2000 1000'}
   & "$root/phase4-run.ps1" -Run $run -Mode RGB -Command $command -Artifact $item.artifact
   if((Get-Content "$root/runs/$run/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
  }
 }
}
[IO.File]::WriteAllText("$root/phase5/trim-progress.json",'{"stage":"complete"}')
