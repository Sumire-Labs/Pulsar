$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root/phase5/trim-progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root/phase5/run.ps1" -Run $run -Artifact trim.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 if((Get-Content "$root/runs/$run/results/$file" -Raw|ConvertFrom-Json).valid -ne $true){throw "Audit failed $run"}
}
Audit 'trim-vanilla-stable' 'skyaudit range'
Audit 'trim-celeritas-stable' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'trim-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'trim-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'trim-block-regression' 'rgbaudit'
Audit 'trim-block-celeritas' 'rgbaudit' 'flat' 'RGB' -Fast
Audit 'trim-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'trim-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)) {
 foreach($mode in @('rgb','filtered')) {
  foreach($item in @(@{v='before';i=$cohort;artifact='white.jar'},@{v='after';i=$cohort;artifact='trim.jar'},@{v='after';i=$cohort+1;artifact='trim.jar'},@{v='before';i=$cohort+1;artifact='white.jar'})) {
   $run="trim-perf-$mode-$($item.v)-$($item.i)"
   [IO.File]::WriteAllText("$root/phase5/trim-progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
   $command=if($mode -eq 'filtered'){'function perfbench:filteredupdates'}else{'lightbench updates 2000 1000'}
   & "$root/phase5/run.ps1" -Run $run -Mode RGB -Command $command -Artifact $item.artifact
   if((Get-Content "$root/runs/$run/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
  }
 }
}
[IO.File]::WriteAllText("$root/phase5/trim-progress.json",'{"stage":"complete"}')
