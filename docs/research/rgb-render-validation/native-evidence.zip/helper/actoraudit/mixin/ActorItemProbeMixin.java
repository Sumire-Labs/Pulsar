package com.sumirelabs.actoraudit.mixin;
import com.sumirelabs.actoraudit.ActorAudit;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraft.entity.item.EntityItem;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(RenderEntityItem.class)
public abstract class ActorItemProbeMixin {
    @WrapMethod(method={"doRender(Lnet/minecraft/entity/item/EntityItem;DDDFF)V","func_76986_a(Lnet/minecraft/entity/item/EntityItem;DDDFF)V"},remap=false)
    private void audit$item(EntityItem item,double x,double y,double z,float yaw,float partial,Operation<Void> original){
        ActorAudit.itemBegin(item);try{original.call(item,x,y,z,yaw,partial);}finally{ActorAudit.itemEnd();}
    }
}
