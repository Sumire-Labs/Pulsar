package com.sumirelabs.actoraudit.mixin;
import com.sumirelabs.actoraudit.ActorAudit;
import net.minecraft.client.renderer.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Checks completed item colors immediately before the actual vertex upload. */
@Mixin(WorldVertexBufferUploader.class)
public abstract class ActorUploadProbeMixin {
    @Inject(method={"draw(Lnet/minecraft/client/renderer/BufferBuilder;)V","func_181679_a(Lnet/minecraft/client/renderer/BufferBuilder;)V"},at=@At("HEAD"),remap=false)
    private void audit$item(BufferBuilder buffer,CallbackInfo callback){ActorAudit.itemVertices(buffer);}
}
