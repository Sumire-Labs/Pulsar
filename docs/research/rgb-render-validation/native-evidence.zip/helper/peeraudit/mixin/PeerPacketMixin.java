package com.sumirelabs.peeraudit.mixin;
import io.netty.buffer.ByteBuf;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Private transport harness; narrowly works around the independently reproduced LOGIN/PLAY race. */
@Mixin(NettyPacketEncoder.class)
public abstract class PeerPacketMixin {
    @WrapMethod(method="encode(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/Packet;Lio/netty/buffer/ByteBuf;)V",remap=false)
    private void peer$loginState(ChannelHandlerContext context,Packet<?> packet,ByteBuf bytes,Operation<Void> original){
        var attribute=context.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY);var state=attribute.get();
        boolean adjust=packet instanceof net.minecraft.network.login.server.SPacketLoginSuccess&&state==EnumConnectionState.PLAY;
        if(adjust){System.out.println("PEER_TEST_ONLY_LOGIN_STATE_WORKAROUND");attribute.set(EnumConnectionState.LOGIN);}
        try {original.call(context,packet,bytes);}
        finally {if(adjust)attribute.set(state);}
    }
    @Inject(method="encode(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/Packet;Lio/netty/buffer/ByteBuf;)V",at=@At("HEAD"),remap=false)
    private void peer$encoding(ChannelHandlerContext context,Packet<?> packet,ByteBuf bytes,CallbackInfo callback){
        var state=context.channel().attr(NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get();
        var required=EnumConnectionState.getFromPacket(packet);
        if(state!=required)System.out.println("PEER_PACKET_STATE packet="+packet.getClass().getName()+" state="+state+" required="+required);
    }
}
