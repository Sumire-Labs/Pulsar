package com.sumirelabs.renderperf;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.BlockLightColors;
import com.sumirelabs.pulsar.rgb.RgbClient;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.command.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.lang.management.ManagementFactory;
import java.nio.file.*;
import java.util.*;

/** Private benchmark without GPU readbacks, actor diagnostics or new draw API references. */
@Mod(modid="renderperf",name="RGB Render Timing",version="1",dependencies="required-after:pulsar",clientSideOnly=true)
public final class RenderPerf {
    private static final int X=20000,Y=80,Z=20032;
    private static volatile boolean ready,finished;
    private static volatile JsonObject report;
    private WorldServer world;
    private int stage=-1,ticks;
    private boolean started;
    private int warm=600,samples=1200,entities=64,particles=1024,frames;
    private long start,allocated,gcStart,wallStart;
    private final List<Long> times=new ArrayList<>(),allocations=new ArrayList<>();
    private final com.sun.management.ThreadMXBean memory=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();
    @Mod.EventHandler public void init(FMLInitializationEvent e){
        BlockLightColors.register(Blocks.GLOWSTONE.getDefaultState(),15,0,0);
        BlockLightColors.register(Blocks.SEA_LANTERN.getDefaultState(),0,0,15);
        memory.setThreadAllocatedMemoryEnabled(true);MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent e){
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "renderperf";}
            public String getUsage(ICommandSender s){return "/renderperf [warm samples entities particles]";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer server,ICommandSender sender,String[] args){
                if(args.length==4){warm=Integer.parseInt(args[0]);samples=Integer.parseInt(args[1]);entities=Integer.parseInt(args[2]);particles=Integer.parseInt(args[3]);}
                world=(WorldServer)sender.getEntityWorld();stage=0;
            }
        });
    }
    @SubscribeEvent public void server(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||stage<0||++ticks<20)return;ticks=0;
        if(stage==0){
            world.getGameRules().setOrCreateGameRule("doDaylightCycle","false");world.setWorldTime(6000);
            for(int cx=(X>>4)-2;cx<=(X>>4)+3;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
            for(int x=X;x<X+32;x++)for(int y=Y;y<Y+13;y++)for(int z=Z;z<Z+32;z++)world.setBlockState(new BlockPos(x,y,z),x==X||x==X+31||y==Y||y==Y+12||z==Z||z==Z+31?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
            world.setBlockState(new BlockPos(X+8,Y+3,Z+8),Blocks.GLOWSTONE.getDefaultState(),3);
            world.setBlockState(new BlockPos(X+24,Y+3,Z+8),Blocks.SEA_LANTERN.getDefaultState(),3);
            var player=(EntityPlayerMP)world.playerEntities.get(0);player.setGameType(GameType.CREATIVE);player.capabilities.isFlying=true;player.sendPlayerAbilities();player.connection.setPlayerLocation(X+16.5,Y+7,Z+25.5,180,15);world.getPlayerChunkMap().updateMovingPlayer(player);stage=1;
        }else if(stage==1&&!((PulsarWorld)world).pulsar$getLightManager().hasUpdates()){
            for(int cx=X>>4;cx<=(X+31)>>4;cx++)for(int cz=Z>>4;cz<=(Z+31)>>4;cz++){var entry=world.getPlayerChunkMap().getEntry(cx,cz);if(entry!=null)for(var p:world.playerEntities)entry.sendToPlayer((EntityPlayerMP)p);}
            ready=true;stage=2;
        }else if(stage==2&&finished){
            try {Path out=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/render-perf.json");Files.createDirectories(out.getParent());Files.writeString(out,new GsonBuilder().setPrettyPrinting().create().toJson(report));}
            catch(Exception failure){throw new RuntimeException(failure);}
            world.getGameRules().setOrCreateGameRule("fourbench_complete","true");stage=-1;System.out.println("RENDER_PERF_FINISHED "+report.get("valid"));
        }
    }
    private static void anchor(Entity e,double x,double y,double z){e.setPosition(x,y,z);e.prevPosX=e.lastTickPosX=x;e.prevPosY=e.lastTickPosY=y;e.prevPosZ=e.lastTickPosZ=z;}
    @SubscribeEvent public void client(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END||!ready||started)return;Minecraft mc=Minecraft.getMinecraft();
        if(mc.world==null||mc.world.getBlockState(new BlockPos(X+8,Y+3,Z+8)).getBlock()!=Blocks.GLOWSTONE)return;
        boolean rgb=com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled();if(rgb&&!RgbClient.active())return;
        for(int i=0;i<entities;i++){EntitySheep sheep=new EntitySheep(mc.world);sheep.setNoAI(true);sheep.setNoGravity(true);anchor(sheep,X+5.5+(i%8)*2.8,Y+1,Z+5.5+(i/8)*1.8);mc.world.addEntityToWorld(-43000-i,sheep);}
        for(int i=0;i<particles;i++)mc.effectRenderer.addEffect(new FixedParticle(mc.world,X+5.5+(i%32)*.65,Y+2+(i/1024)*.3,Z+5.5+((i/32)%32)*.45));
        started=true;
    }
    private static long gc(){return ManagementFactory.getGarbageCollectorMXBeans().stream().mapToLong(b->Math.max(0,b.getCollectionCount())).sum();}
    @SubscribeEvent public void frame(TickEvent.RenderTickEvent e){
        if(!started||finished)return;
        if(e.phase==TickEvent.Phase.START){start=System.nanoTime();allocated=memory.getThreadAllocatedBytes(Thread.currentThread().threadId());return;}
        long duration=System.nanoTime()-start,bytes=memory.getThreadAllocatedBytes(Thread.currentThread().threadId())-allocated;
        if(frames++<warm)return;
        if(times.isEmpty()){gcStart=gc();wallStart=System.nanoTime();}
        times.add(duration);allocations.add(bytes);
        if(times.size()<samples)return;
        report=new JsonObject();report.addProperty("valid",true);report.addProperty("warm_frames",warm);report.addProperty("sample_frames",samples);report.addProperty("entities",entities);report.addProperty("particles",particles);report.addProperty("rgb_active",RgbClient.active());report.addProperty("entity_render_debug",Minecraft.getMinecraft().renderGlobal.getDebugInfoEntities());report.addProperty("particle_render_debug",Minecraft.getMinecraft().effectRenderer.getStatistics());report.addProperty("jvm_gc_collections",gc()-gcStart);report.addProperty("sample_wall_ns",System.nanoTime()-wallStart);report.add("frame_ns",new Gson().toJsonTree(times));report.add("render_thread_allocated_bytes",new Gson().toJsonTree(allocations));finished=true;
    }
    private static final class FixedParticle extends Particle {
        FixedParticle(World world,double x,double y,double z){super(world,x,y,z);particleMaxAge=Integer.MAX_VALUE;particleRed=particleGreen=particleBlue=.8f;particleAlpha=.7f;}
        public void onUpdate(){prevPosX=posX;prevPosY=posY;prevPosZ=posZ;}
    }
}
