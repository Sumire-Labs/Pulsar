from pathlib import Path
import json,statistics,math
root=Path('E:/Github/Pulsar-RGB-20261016');records=[]
for variant in ['before','ready']:
 for i in range(1,5):
  name=f'ready-server-scalar-{variant}-{i}';folder=root/'runs'/name
  assert json.loads((folder/'status.json').read_text())['valid'],name
  observer=json.loads((folder/'results/observer.json').read_text());assert not observer.get('failure'),name
  files=list((folder/'results').glob('*-updates-*.json'));assert len(files)==1,name
  data=json.loads(files[0].read_text())['benchmark'];phases={}
  for phase in data['phases']:
   assert phase['sample_count']==1000 and phase['all_samples_verified'],(name,phase['name'])
   assert all(s['light_verified'] for s in phase['samples']),(name,phase['name'])
   phases[phase['name']]=phase['completion_summary_nanos']
  records.append({'run':name,'variant':variant,'index':i,'phases':phases,'gc':data['measurement_gc']})
comparisons={}
for phase in ['block_place','block_remove','sky_remove','sky_place']:
 a=[next(r for r in records if r['variant']=='before' and r['index']==i)['phases'][phase]['average'] for i in range(1,5)]
 b=[next(r for r in records if r['variant']=='ready' and r['index']==i)['phases'][phase]['average'] for i in range(1,5)]
 logs=[math.log(y/x) for x,y in zip(a,b)];mean=statistics.mean(logs);margin=3.182446*statistics.stdev(logs)/2
 comparisons[phase]={'before_median_of_means_us':statistics.median(a)/1000,'latest_median_of_means_us':statistics.median(b)/1000,'paired_geometric_change_percent':100*math.expm1(mean),'t95_interval_percent':[100*math.expm1(mean-margin),100*math.expm1(mean+margin)]}
(root/'phase8/server-performance-analysis.json').write_text(json.dumps({'records':records,'comparisons':comparisons,'all_samples_retained':True},indent=2)+'\n');print(json.dumps(comparisons,indent=2))
