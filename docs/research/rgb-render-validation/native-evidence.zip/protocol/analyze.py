from pathlib import Path
import json,statistics,math
root=Path('E:/Github/Pulsar-RGB-20261016')
records=[]
for mode,variants in [('scalar',['before','cached']),('rgb',['before','complete','cached'])]:
 for variant in variants:
  for i in range(1,5):
   name=f'sample-perf-{mode}-{variant}-{i}'
   d=json.loads((root/'runs'/name/'results/render-perf.json').read_text())
   assert d['valid'] and len(d['frame_ns'])==1200 and len(d['render_thread_allocated_bytes'])==1200,name
   frames=sorted(d['frame_ns']);alloc=d['render_thread_allocated_bytes']
   records.append({'mode':mode,'variant':variant,'index':i,'run':name,'mean_ms':statistics.mean(frames)/1e6,'median_ms':statistics.median(frames)/1e6,'p95_ms':frames[math.ceil(.95*len(frames))-1]/1e6,'allocated_bytes_per_frame':statistics.mean(alloc),'jvm_gc_collections':d['jvm_gc_collections'],'entities':d['entity_render_debug'],'particles':d['particle_render_debug']})
def comparison(mode,before,after,metric):
 pairs=[]
 for i in range(1,5):
  a=next(r[metric] for r in records if (r['mode'],r['variant'],r['index'])==(mode,before,i))
  b=next(r[metric] for r in records if (r['mode'],r['variant'],r['index'])==(mode,after,i))
  pairs.append(math.log(b/a))
 average=statistics.mean(pairs);margin=3.182446*statistics.stdev(pairs)/2
 return {'paired_geometric_change_percent':100*math.expm1(average),'t95_interval_percent':[100*math.expm1(average-margin),100*math.expm1(average+margin)],'pairs':4,'unit':'independent JVM means, not individual frames'}
summary={}
for mode,before,after in [('scalar','before','cached'),('rgb','before','complete'),('rgb','complete','cached'),('rgb','before','cached')]:
 summary[f'{mode}:{before}->{after}']={m:comparison(mode,before,after,m) for m in ['mean_ms','allocated_bytes_per_frame']}
result={'records':records,'comparisons':summary,'all_samples_retained':True,'cpu_interval':'FML RenderTick START-to-END; not whole-frame FPS','allocation':'Java render-thread allocation; not retained heap or GPU memory','rgb_before_has_no_object_RGB_rendering':True}
(root/'phase8/performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
