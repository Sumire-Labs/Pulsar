param([string]$Run,[ValidateSet('RGB','SCALAR')][string]$HostMode='RGB',[ValidateSet('RGB','SCALAR')][string]$ClientMode='RGB',[string]$Artifact='draw-final.jar',[switch]$Platform077)
$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
$prism='C:/Users/s12kuma01/AppData/Roaming/PrismLauncher/instances'
$instancePrefix=if($Platform077){"Pulsar-RGB-Peer077-20261017"}else{"Pulsar-RGB-PeerStable-20261017"}
$source=if($Platform077){"$prism/Pulsar-Issue22-20261017"}else{"$prism/Pulsar-RGB-20261016"}
$out="$root/peers/$Run"
if($Run -notmatch '^[a-z0-9-]+$' -or (Test-Path $out)){throw 'Invalid or existing peer run'}
New-Item -ItemType Directory -Force $out | Out-Null
function Owned([string]$role){@(Get-CimInstance Win32_Process -Filter "Name='javaw.exe'" | Where-Object CommandLine -like "*$instancePrefix-$role*")}
function Stage([string]$role,[string]$mode){
 $instance="$prism/$instancePrefix-$role";$game="$instance/minecraft"
 if((Owned $role).Count){throw "Owned peer $role already running"}
 if($Platform077 -and -not(Test-Path $instance)){
  $staged="C:/Users/s12kuma01/AppData/Local/Temp/$instancePrefix-$role-stage"
  if(Test-Path $staged){throw 'Owned peer instance staging already exists'}
  New-Item -ItemType Directory $staged | Out-Null
  Copy-Item "$source/patches" "$staged/patches" -Recurse
  Copy-Item "$source/libraries" "$staged/libraries" -Recurse
  Copy-Item "$source/instance.cfg" "$staged/instance.cfg"
  Copy-Item "$source/mmc-pack.json" "$staged/mmc-pack.json"
  if([IO.Path]::GetFullPath($staged) -ne [IO.Path]::GetFullPath("C:/Users/s12kuma01/AppData/Local/Temp/$instancePrefix-$role-stage") -or [IO.Path]::GetFullPath($instance) -ne [IO.Path]::GetFullPath("$prism/$instancePrefix-$role")){throw 'Unexpected owned instance move'}
  Move-Item -LiteralPath $staged -Destination $instance
 }
 New-Item -ItemType Directory -Force $instance | Out-Null
 Copy-Item "$source/mmc-pack.json" "$instance/mmc-pack.json"
 if($Platform077){Copy-Item "$source/patches/*" "$instance/patches" -Recurse -Force;Copy-Item "$source/libraries/*" "$instance/libraries" -Recurse -Force}
 $instanceCfg=Get-Content "$source/instance.cfg" -Raw
 $instanceCfg=[regex]::Replace($instanceCfg,'(?m)^name=.*$',"name=Pulsar RGB peer $role - disposable")
 [IO.File]::WriteAllText("$instance/instance.cfg",$instanceCfg)
 if(Test-Path $game){
  if([IO.Path]::GetFullPath($game) -ne [IO.Path]::GetFullPath("$instance/minecraft")){throw 'Unexpected peer game path'}
  Rename-Item -LiteralPath $game -NewName "minecraft-backup-$Run"
 }
 New-Item -ItemType Directory -Force "$game/mods" | Out-Null
 if($Platform077){
  Copy-Item 'E:/Github/Pulsar-Issue22-20261017/common-mods/*' "$game/mods" -Recurse
  New-Item -ItemType Directory -Force "$out/excluded-$role" | Out-Null
  foreach($old in @('+Fugue-0.24.4.jar','-cleanroom-relauncher-1.1.5.jar')){Move-Item -LiteralPath "$game/mods/$old" -Destination "$out/excluded-$role/$old"}
  Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/+Fugue-0.25.4.jar' "$game/mods"
  Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/-cleanroom-relauncher-1.2.1.jar' "$game/mods/!cleanroom-relauncher-1.2.1.jar"
 }else{Copy-Item "$root/common-mods/*" "$game/mods" -Recurse}
 Copy-Item "$root/frozen/config" "$game/config" -Recurse
 Copy-Item "$root/frozen/options.txt" "$game/options.txt"
 if($Platform077){Copy-Item "C:/Users/s12kuma01/AppData/Roaming/PrismLauncher/instances/Pulsar-Issue22-20261017/minecraft/config/relauncher.json" "$game/config/relauncher.json"}
 Copy-Item "$root/artifacts/$Artifact" "$game/mods/pulsar.jar"
 Copy-Item "$root/artifacts/peer-audit.jar" "$game/mods/peer-audit.jar"
 $cfg=Get-Content "$game/config/pulsar.cfg" -Raw
 $cfg=[regex]::Replace($cfg,'(?m)^\s*S:lightingMode=.*$','')
 [IO.File]::WriteAllText("$game/config/pulsar.cfg",$cfg.Replace('general {',"general {`n    S:lightingMode=$mode"))
 $data=@{role=$role;port=25391;output=$out;expected_rgb=($HostMode -eq 'RGB' -and $ClientMode -eq 'RGB')}
 [IO.File]::WriteAllText("$game/peer-role.json",($data|ConvertTo-Json))
 if($role -eq 'host'){
  New-Item -ItemType Directory -Force "$game/saves" | Out-Null
  Copy-Item "$root/templates/flat" "$game/saves/Bench Updates" -Recurse
  & node "$root/world.cjs" "$game/saves/Bench Updates" candidate updates $Run peerhost
  if($LASTEXITCODE -ne 0){throw 'Peer host world setup failed'}
  [IO.File]::WriteAllText("$game/lightbench-variant.txt",'candidate')
  [IO.File]::WriteAllText("$game/four-engine-mode.txt",'updates')
  [IO.File]::WriteAllText("$game/four-engine-bench.marker",'disposable loopback peer validation')
 }
}
Stage host $HostMode
Stage client $ClientMode
[IO.File]::WriteAllText("$out/stage.json",(@{platform077=[bool]$Platform077;host_mode=$HostMode;client_mode=$ClientMode;artifact_sha256=(Get-FileHash "$root/artifacts/$Artifact").Hash;helper_sha256=(Get-FileHash "$root/artifacts/peer-audit.jar").Hash}|ConvertTo-Json))
$launcher='C:/Users/s12kuma01/AppData/Local/Programs/PrismLauncher/prismlauncher.exe'
Start-Process $launcher -ArgumentList '-l',"$instancePrefix-host",'--offline','RGBHost' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(3)
while(-not (Test-Path "$out/host-ready.json")){
 if(Test-Path "$out/host-failure.json"){throw 'Peer host diagnostic failed'}
 if([DateTime]::UtcNow -gt $deadline){throw 'Peer host setup timed out; retained for diagnosis'}
 Start-Sleep -Seconds 2
}
Start-Process $launcher -ArgumentList '-l',"$instancePrefix-client",'--offline','RGBPeer' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(5);$clientSeen=$false
while([DateTime]::UtcNow -lt $deadline){
 Start-Sleep -Seconds 2
 if((Owned client).Count){$clientSeen=$true}
 if($clientSeen -and -not (Owned client).Count -and -not (Owned host).Count){break}
}
if((Owned host).Count -or (Owned client).Count){throw 'Peer run timed out; retained for diagnosis'}
foreach($role in @('host','client')){
 Copy-Item "$prism/$instancePrefix-$role/minecraft/logs/latest.log" "$out/$role.log"
}
$report=Get-Content "$out/peer-result.json" -Raw|ConvertFrom-Json
if($report.valid -ne $true -or $report.connected_remote -ne $true){throw 'Native peer verification failed'}
Write-Output "Peer run $Run valid=True"
