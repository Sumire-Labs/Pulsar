$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function MeasureRender([string]$mode,[string]$variant,[int]$index,[string]$artifact){
 $name="sample-perf-$($mode.ToLower())-$variant-$index"
 [IO.File]::WriteAllText("$root/phase8/perf-progress.json",(@{stage='timing';run=$name}|ConvertTo-Json))
 & "$root/phase7/run.ps1" -Run $name -Artifact $artifact -Mode $mode -Command 'renderperf 600 1200 64 1024'
 if((Get-Content "$root/runs/$name/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Rendering timing failed $name"}
}
# Four independent JVMs per variant, paired and counterbalanced.
foreach($pair in @(1,3)){
 MeasureRender SCALAR before $pair state.jar
 MeasureRender SCALAR cached $pair draw-ready.jar
 MeasureRender SCALAR cached ($pair+1) draw-ready.jar
 MeasureRender SCALAR before ($pair+1) state.jar
}
$variants=@{before='state.jar';complete='draw-final.jar';cached='draw-ready.jar'}
$orders=@(@('before','complete','cached'),@('cached','complete','before'),@('complete','before','cached'),@('cached','before','complete'))
for($i=0;$i -lt 4;$i++){
 foreach($variant in $orders[$i]){MeasureRender RGB $variant ($i+1) $variants[$variant]}
}
[IO.File]::WriteAllText("$root/phase8/perf-progress.json",'{"stage":"complete"}')

# Server latency is separate from client rendering; verify the common initial-send repair in SCALAR.
foreach($pair in @(1,3)){
 foreach($item in @(@{v='before';i=$pair;a='draw-final.jar'},@{v='ready';i=$pair;a='draw-ready.jar'},@{v='ready';i=$pair+1;a='draw-ready.jar'},@{v='before';i=$pair+1;a='draw-final.jar'})){
  $name="ready-server-scalar-$($item.v)-$($item.i)"
  [IO.File]::WriteAllText("$root/phase8/server-perf-progress.json",(@{stage='timing';run=$name}|ConvertTo-Json))
  & "$root/phase7/run.ps1" -Run $name -Artifact $item.a -Mode SCALAR -Command 'lightbench updates 2000 1000'
  if((Get-Content "$root/runs/$name/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Scalar latency failed $name"}
 }
}
[IO.File]::WriteAllText("$root/phase8/server-perf-progress.json",'{"stage":"complete"}')
