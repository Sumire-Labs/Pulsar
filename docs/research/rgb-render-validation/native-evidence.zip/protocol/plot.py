import sys
sys.path.insert(0,"E:/Github/Pulsar-RGB-20261016/tools/plotpackages")
from pathlib import Path
import json,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('E:/Github/Pulsar-RGB-20261016')
data=json.loads((root/'phase8/performance-analysis.json').read_text())['records']
labels=[('scalar','before','SCALAR before'),('scalar','cached','SCALAR latest'),('rgb','before','RGB terrain only'),('rgb','complete','RGB objects'),('rgb','cached','RGB objects + reuse')]
fig,axes=plt.subplots(1,2,figsize=(11,4.2),layout='constrained')
colors=['#8b98a5','#389bd5','#8b98a5','#e69f48','#54b88a']
for ax,metric,title,unit in [(axes[0],'mean_ms','Render callback time','ms'),(axes[1],'allocated_bytes_per_frame','Java render-thread allocation','KiB / frame')]:
 vals=[];lows=[];highs=[]
 for mode,variant,label in labels:
  xs=[r[metric] for r in data if r['mode']==mode and r['variant']==variant]
  if metric=='allocated_bytes_per_frame':xs=[x/1024 for x in xs]
  center=statistics.median(xs);vals.append(center);lows.append(center-min(xs));highs.append(max(xs)-center)
 ax.bar(range(len(labels)),vals,color=colors,yerr=[lows,highs],capsize=4)
 ax.set_xticks(range(len(labels)),[v[2] for v in labels],rotation=25,ha='right');ax.set_ylabel(unit);ax.set_title(title);ax.grid(axis='y',alpha=.22);ax.set_axisbelow(True)
 ax.spines[['top','right']].set_visible(False)
 for i,value in enumerate(vals):ax.annotate(f'{value:.3f}' if metric=='mean_ms' else f'{value:.1f}',(i,value),xytext=(0,5),textcoords='offset points',ha='center',fontsize=9)
fig.suptitle('64 entities and 1,024 particles — four independent JVMs per variant',fontsize=12)
fig.text(.5,-.03,'Bars: median of JVM means. Whiskers: range of JVM means. Render callback time is not FPS; allocation is not retained memory.',ha='center',fontsize=9)
fig.savefig(root/'phase8/client-rendering.png',dpi=180,bbox_inches='tight')
