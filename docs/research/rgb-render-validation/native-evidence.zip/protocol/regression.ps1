$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function Audit([string]$name,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root/phase8/regression-progress.json",(@{stage='running';run=$name}|ConvertTo-Json))
 & "$root/phase7/run.ps1" -Run $name -Artifact draw-ready.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 if((Get-Content "$root/runs/$name/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Latest regression failed $name"}
}
Audit 'ready2-actor-objects-celeritas' 'actoraudit day objects' 'flat' 'RGB' -Fast
Audit 'ready-vanilla-stable' 'skyaudit range'
Audit 'ready-celeritas-stable' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'ready-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'ready-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'ready-block-regression' 'rgbaudit'
Audit 'ready-block-celeritas' 'rgbaudit' 'flat' 'RGB' -Fast
Audit 'ready-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'ready-cqr' 'issueaudit ship' 'fresh-normal'
[IO.File]::WriteAllText("$root/phase8/regression-progress.json",'{"stage":"complete"}')
