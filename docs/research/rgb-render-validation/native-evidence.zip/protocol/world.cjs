const fs=require('fs'),zlib=require('zlib');
(async()=>{
 const {parseNbt,child,set,encodeTag}=await import('./tools/nbt-read.mjs');
 const [world,variant,mode,run,command]=process.argv.slice(2);
 if(!command) throw Error('Explicit benchmark command required');
 const nbt=parseNbt(zlib.gunzipSync(fs.readFileSync(world+'/level.dat')));
 const data=child(nbt,'Data'); set(data,'LevelName',8,'Bench Updates');
 set(child(data,'GameRules'),'gameLoopFunction',8,'perfbench:start'); set(child(data,'GameRules'),'fourbench_complete',8,'false');
 fs.writeFileSync(world+'/level.dat',zlib.gzipSync(encodeTag(nbt)));
 const dir=world+'/data/functions/perfbench';fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(dir+'/start.mcfunction','scoreboard objectives add benchwait dummy\ngamerule gameLoopFunction perfbench:wait\n');
 fs.writeFileSync(dir+'/wait.mcfunction','scoreboard players add @a benchwait 1\nexecute @a[score_benchwait_min=200] ~ ~ ~ function perfbench:setup\n');
 fs.writeFileSync(dir+'/setup.mcfunction','scoreboard players set @a benchwait 0\ngamerule gameLoopFunction perfbench:settle\ngamerule doMobSpawning false\ngamerule randomTickSpeed 0\ngamerule doFireTick false\ngamerule doWeatherCycle false\nweather clear\ntime set 6000\ngamerule doDaylightCycle false\ngamemode spectator @a\nexecute @a ~ ~ ~ tp @s 20000 280 20072 180 25\n');
 fs.writeFileSync(dir+'/settle.mcfunction','scoreboard players add @a benchwait 1\nexecute @a[score_benchwait_min=100] ~ ~ ~ function perfbench:run\n');
 if(command==='function perfbench:filteredupdates'){
 fs.writeFileSync(dir+'/filteredupdates.mcfunction','setblock 20032 255 20032 minecraft:stained_glass 14 replace\nexecute @a ~ ~ ~ lightbench updates 2000 1000\n');
}
 if(command==='function perfbench:nativeprotocol'){
 const pairs=[['short',2000,1000],['long',10000,10000],['long',10000,10000],['short',2000,1000]];
 fs.writeFileSync(dir+'/nativeprotocol.mcfunction',pairs.map(([name,w,n],i)=>`say NATIVE_PROTOCOL_${i}_${name}\nexecute @a ~ ~ ~ lightbench updates ${w} ${n}\n`).join(''));
}
 fs.writeFileSync(dir+'/run.mcfunction',`gamerule gameLoopFunction -\nexecute @a ~ ~ ~ ${command}\n${(command.startsWith("issueaudit")||command.startsWith("rgbaudit")||command.startsWith("skyaudit")||command.startsWith("actoraudit")||command.startsWith("renderperf")||command.startsWith("peerhost"))?"":"gamerule fourbench_complete true"}\nsay FOUR_ENGINE_COMMAND_RETURNED\n`);
})().catch(e=>{console.error(e);process.exitCode=1});
