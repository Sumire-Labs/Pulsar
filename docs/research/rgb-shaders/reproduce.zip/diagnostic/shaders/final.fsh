#version 120
uniform sampler2D colortex0;uniform sampler2D shadowcolor0;varying vec2 uv;void main(){gl_FragColor=uv.x<0.01?texture2D(shadowcolor0,uv):texture2D(colortex0,uv);}
