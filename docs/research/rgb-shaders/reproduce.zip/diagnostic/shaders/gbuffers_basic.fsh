#version 120
#define RGBA16F 0x881A
/* DRAWBUFFERS:012 */
const int colortex1Format=RGBA16F;
const int colortex2Format=RGBA16F;
uniform sampler2D texture;
varying vec2 uv;varying vec4 tint;varying vec3 relPos;varying vec3 probeNormal;
void GetLighting(inout vec3 albedo,vec3 worldPos){vec3 blockLighting=vec3(0.9);vec3 sceneLighting=vec3(0.1);albedo *= blockLighting + sceneLighting;}
void main(){vec4 material=texture2D(texture,uv)*tint;if(material.a<0.1)discard;vec3 lit=material.rgb;GetLighting(lit,relPos);gl_FragData[0]=vec4(lit,material.a);gl_FragData[1]=vec4(normalize(probeNormal)*0.5+0.5,0.375);gl_FragData[2]=vec4(0.125,0.25,0.625,material.a);}
