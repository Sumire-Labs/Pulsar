#version 120
varying vec2 uv;
varying vec4 tint;
varying vec3 relPos;
varying vec3 probeNormal;
uniform mat4 gbufferModelViewInverse;
void main(){gl_Position=ftransform();uv=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;tint=gl_Color;relPos=(gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex).xyz;probeNormal=gl_NormalMatrix*gl_Normal;}
