#version 120
#define RGBA16F 0x881A
const int shadowMapResolution=256;void main(){gl_FragData[0]=vec4(0.25,0.5,0.75,1.0);}
