package com.sumirelabs.shaderaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.PositionalColoredLightSource;
import com.sumirelabs.pulsar.core.RgbMixinSelection;
import com.sumirelabs.pulsar.rgb.RgbClient;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.command.*;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.GL30;
import org.lwjgl.BufferUtils;
import java.nio.file.*;
import java.util.Properties;

/** Original disposable shader integration diagnostics; never included in Pulsar. */
@Mod(modid="shaderaudit",name="Pulsar Shader Audit",version="1",dependencies="required-after:pulsar",clientSideOnly=true)
public final class ShaderAudit {
    private static int X=20000,Y=80,Z=20032;
    private static BlockPos SOURCE=new BlockPos(X+8,Y+4,Z+7);
    private static Block source, probe, probeFast;
    private static int normalDraws, fastDraws, particleDraws;
    private static final java.util.concurrent.atomic.AtomicLong CALLBACKS=new java.util.concurrent.atomic.AtomicLong();
    private WorldServer world;
    private JsonObject config;
    private JsonArray packs;
    private final JsonArray cases=new JsonArray();
    private volatile boolean ready;
    private int serverStage=-1,packIndex=-1,settle,clientTicks,exitTicks;
    private boolean finished;
    private int colorPhase;
    private long patchStart, samplerStart;
    private long[] diagnosticRed;
    private JsonObject initialClassic, skyRed;
    private boolean skyDone;
    private JsonObject currentCase;
    public ShaderAudit(){MinecraftForge.EVENT_BUS.register(this);}
    @SubscribeEvent public void blocks(RegistryEvent.Register<Block> event){
        source=new Source().setRegistryName("shaderaudit","source");event.getRegistry().register(source);probe=new Block(Material.GLASS){public boolean hasTileEntity(IBlockState state){return true;}public TileEntity createTileEntity(World w,IBlockState state){return new ProbeTile();}public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.INVISIBLE;}public boolean isOpaqueCube(IBlockState state){return false;}}.setRegistryName("shaderaudit","probe");event.getRegistry().register(probe);probeFast=new Block(Material.GLASS){public boolean hasTileEntity(IBlockState state){return true;}public TileEntity createTileEntity(World w,IBlockState state){return new FastTile();}public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.INVISIBLE;}public boolean isOpaqueCube(IBlockState state){return false;}}.setRegistryName("shaderaudit","probe_fast");event.getRegistry().register(probeFast);
    }
    @Mod.EventHandler public void pre(FMLPreInitializationEvent event){
        GameRegistry.registerTileEntity(SourceTile.class,new ResourceLocation("shaderaudit","source"));
        GameRegistry.registerTileEntity(ProbeTile.class,new ResourceLocation("shaderaudit","probe"));
        GameRegistry.registerTileEntity(FastTile.class,new ResourceLocation("shaderaudit","fast_probe"));
        net.minecraftforge.fml.client.registry.ClientRegistry.bindTileEntitySpecialRenderer(ProbeTile.class,new ProbeRenderer());
        net.minecraftforge.fml.client.registry.ClientRegistry.bindTileEntitySpecialRenderer(FastTile.class,new FastRenderer());
    }
    @Mod.EventHandler public void init(FMLInitializationEvent event)throws Exception{
        config=JsonParser.parseString(Files.readString(Minecraft.getMinecraft().gameDir.toPath().resolve("shader-audit.json"))).getAsJsonObject();
        packs=config.getAsJsonArray("packs");
        if(config.has("x")){X=config.get("x").getAsInt();Z=config.get("z").getAsInt();SOURCE=new BlockPos(X+8,Y+4,Z+7);}
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent event){event.registerServerCommand(new CommandBase(){
        public String getName(){return "shaderaudit";}
        public String getUsage(ICommandSender sender){return "/shaderaudit";}
        public int getRequiredPermissionLevel(){return 0;}
        public void execute(net.minecraft.server.MinecraftServer server,ICommandSender sender,String[] args){world=(WorldServer)sender.getEntityWorld();serverStage=0;}
    });}
    public static final class SourceTile extends TileEntity {
        int mode;
        public NBTTagCompound writeToNBT(NBTTagCompound nbt){super.writeToNBT(nbt);nbt.setInteger("mode",mode);return nbt;}
        public void readFromNBT(NBTTagCompound nbt){super.readFromNBT(nbt);mode=nbt.getInteger("mode");}
    }
    private static final class Source extends Block implements PositionalColoredLightSource {
        Source(){super(Material.GLASS);setLightLevel(1);setLightOpacity(0);}
        public boolean hasTileEntity(IBlockState state){return true;}
        public TileEntity createTileEntity(World world,IBlockState state){return new SourceTile();}
        public boolean isOpaqueCube(IBlockState state){return false;}
        public boolean isFullCube(IBlockState state){return false;}
        public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.INVISIBLE;}
        public int getColoredLightEmission(IBlockAccess world,BlockPos pos,IBlockState state){
            CALLBACKS.incrementAndGet();
            if(!(world instanceof WorldServer server)||!server.isCallingFromMinecraftThread())throw new IllegalStateException("RGB callback off world thread");
            var tile=world.getTileEntity(pos);return tile instanceof SourceTile t?(t.mode==1?0x00F:t.mode==2?0x0F0:t.mode==3?0:0xF00):0xF00;
        }
    }
    @SubscribeEvent public void server(TickEvent.ServerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||serverStage<0)return;
        try{
            if(serverStage==0){
                world.getGameRules().setOrCreateGameRule("doDaylightCycle","false");
                world.getGameRules().setOrCreateGameRule("doWeatherCycle","false");
                world.getGameRules().setOrCreateGameRule("doMobSpawning","false");world.setWorldTime(6000);
                for(int cx=(X>>4)-2;cx<=(X>>4)+2;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
                for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<20;z++)world.setBlockState(new BlockPos(X+x,Y+y,Z+z),
                        x==0||x==15||y==0||y==7||z==0||z==19?Blocks.QUARTZ_BLOCK.getDefaultState():Blocks.AIR.getDefaultState(),2);
                world.setBlockState(SOURCE,source.getDefaultState(),3);
                if(config.get("baseline").getAsBoolean())world.setBlockState(new BlockPos(X+2,Y+5,Z+16),Blocks.GLOWSTONE.getDefaultState(),3);
                var sheep=new EntitySheep(world);sheep.setNoAI(true);sheep.setPosition(X+9.5,Y+1,Z+6.5);world.spawnEntity(sheep);
                for(var player:world.playerEntities){player.setPositionAndUpdate(X+8.5,Y+1,Z+15.5);player.rotationYaw=180;player.rotationPitch=0;}
                world.setBlockState(new BlockPos(X+6,Y+2,Z+11),probe.getDefaultState(),3);
                world.setBlockState(new BlockPos(X+10,Y+2,Z+11),probeFast.getDefaultState(),3);
                for(var player:world.playerEntities)player.setHeldItem(EnumHand.MAIN_HAND,new net.minecraft.item.ItemStack(Blocks.QUARTZ_BLOCK));
                var manager=((PulsarWorld)world).pulsar$getLightManager();
                for(int cx=(X>>4)-2;cx<=(X>>4)+2;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)manager.forceRelightChunk(cx,cz);
                serverStage=1;return;
            }
            if(serverStage==1&&!((PulsarWorld)world).pulsar$getLightManager().hasUpdates()){ready=true;serverStage=2;}
        }catch(Throwable failure){failure.printStackTrace();finish(failure);}
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END||!ready||finished)return;
        var mc=Minecraft.getMinecraft();if(mc.world==null||mc.player==null)return;
        try{
            if(clientTicks%8==0)mc.effectRenderer.addEffect(new ProbeParticle(mc.world));
            if(++clientTicks>18000)throw new IllegalStateException("Shader matrix timeout");
            mc.gameSettings.hideGUI=true;mc.gameSettings.thirdPersonView=0;
            if(packIndex<0){packIndex=0;colorPhase=6;settle=0;return;}
            boolean rgb=RgbMixinSelection.rgbEnabled();
            if(rgb){
                if(!RgbClient.active())return;
                var snapshot=((com.sumirelabs.pulsar.rgb.RgbChunk)mc.world.getChunk(SOURCE)).pulsar$getRgbSnapshot();
                int expected=colorPhase==0||colorPhase==6?0xF00:colorPhase==4?0x0F0:colorPhase==7||colorPhase==8?0:0x00F;
                if(snapshot==null||snapshot.get(SOURCE.getX(),SOURCE.getY(),SOURCE.getZ())!=expected){settle=0;return;}
                if(colorPhase==7||colorPhase==8||colorPhase==1&&skyDone){var sky=((com.sumirelabs.pulsar.rgb.RgbChunk)mc.world.getChunk(SOURCE)).pulsar$getRgbSkySnapshot();int skyExpected=colorPhase==7?0xF00:colorPhase==8?0x00F:0;if(sky==null||sky.get(SOURCE.getX(),SOURCE.getY(),SOURCE.getZ())!=skyExpected){settle=0;return;}}
            }
            if(++settle<80)return;
            Object manager=Class.forName("net.coderbot.iris.Iris").getMethod("getPipelineManager").invoke(null);
            Object pipeline=manager.getClass().getMethod("getPipelineNullable").invoke(manager);
            String type=pipeline==null?"null":pipeline.getClass().getName();
            boolean compiled=type.endsWith("DeferredWorldRenderingPipeline");
            if(colorPhase==7){skyRed=capture("shader-audit-sky-red.png");roof(1);colorPhase=8;settle=0;return;
            }else if(colorPhase==8){JsonObject blue=capture("shader-audit-sky-blue.png");currentCase.add("sky_red",skyRed);currentCase.add("sky_blue",blue);currentCase.addProperty("sky_filter_changed",skyRed.get("red_blue_score").getAsDouble()-blue.get("red_blue_score").getAsDouble()>.15);skyDone=true;roof(-1);colorPhase=1;settle=0;return;
            }else if(colorPhase==6){initialClassic=capture("shader-audit-initial-classic-red.png");loadPack();return;}else if(colorPhase==4){
                JsonObject image=capture("shader-audit-nether-green.png");currentCase.add("nether_image",image);currentCase.addProperty("nether_dimension",mc.world.provider.getDimension());
                boolean green=image.get("green").getAsDouble()>image.get("red").getAsDouble()*1.5&&image.get("green").getAsDouble()>image.get("blue").getAsDouble()*1.5;
                currentCase.addProperty("dimension_field_reset",compiled&&runtimeBoolean("fieldReady")&&mc.world.provider.getDimension()==-1&&!mc.world.provider.hasSkyLight()&&green);
                hop(false);colorPhase=5;settle=0;return;
            }else if(colorPhase==5){
                JsonObject image=capture("shader-audit-overworld-blue.png");currentCase.add("returned_image",image);currentCase.addProperty("returned_dimension",mc.world.provider.getDimension());
                currentCase.addProperty("valid",currentCase.get("valid").getAsBoolean()&&currentCase.get("dimension_field_reset").getAsBoolean()&&mc.world.provider.getDimension()==0&&compiled&&runtimeBoolean("fieldReady")&&image.get("red_blue_score").getAsDouble() < -.15);
            }else if(colorPhase==2){
                currentCase.add("initial_classic",initialClassic);currentCase.addProperty("classic_vanilla_hook",RgbClient.vanillaRendered);currentCase.addProperty("classic_wall_tint",Integer.toHexString(RgbClient.tintAbgr(0xFFFFFFFF,X+8,Y+4,Z+1)));currentCase.addProperty("disabled_pipeline",type);currentCase.addProperty("disabled_bridge",!runtimeBoolean("active"));currentCase.addProperty("classic_terrain_hook",RgbClient.celeritasRendered);currentCase.addProperty("classic_tint",Integer.toHexString(RgbClient.tintAbgr(0xFFFFFFFF,X+8,Y+1,Z+8)));
                currentCase.addProperty("disabled_draw_error",GL11.glGetError());currentCase.add("disabled_image",capture("shader-audit-"+packIndex+"-disabled.png"));
                currentCase.addProperty("valid",currentCase.get("valid").getAsBoolean()&&!compiled&&!runtimeBoolean("active"));
                enablePack(true);colorPhase=3;settle=0;return;
            }else if(colorPhase==3){
                currentCase.addProperty("reenabled_pipeline",type);currentCase.addProperty("reenabled_bridge",runtimeBoolean("active"));
                currentCase.addProperty("reenabled_draw_error",GL11.glGetError());
                JsonObject image=capture("shader-audit-"+packIndex+"-reenabled.png");currentCase.add("reenabled_image",image);
                currentCase.addProperty("valid",currentCase.get("valid").getAsBoolean()&&compiled&&(rgb?(runtimeBoolean("active")&&runtimeBoolean("fieldReady")&&image.get("red_blue_score").getAsDouble() < -0.15):(!runtimeBoolean("active")&&!runtimeBoolean("fieldReady")&&CALLBACKS.get()==0&&currentCase.get("scalar_chunk_clean").getAsBoolean())));
            }else if(colorPhase==0){
                currentCase=new JsonObject();currentCase.addProperty("pack",packs.get(packIndex).getAsString());
                currentCase.addProperty("pipeline",type);currentCase.addProperty("rgb_mode",rgb);currentCase.addProperty("scalar_chunk_clean",rgb||!(((Object)mc.world.getChunk(SOURCE)) instanceof com.sumirelabs.pulsar.rgb.RgbChunk));currentCase.addProperty("source_callbacks",CALLBACKS.get());currentCase.addProperty("rgb_active",RgbClient.active());
                normalDraws=fastDraws=particleDraws=0;
                currentCase.addProperty("canonical_source",mc.world.getLightFor(EnumSkyBlock.BLOCK,SOURCE));
                currentCase.addProperty("compiled_pipeline",compiled);currentCase.addProperty("draw_error_red",GL11.glGetError());
                currentCase.add("red_image",capture("shader-audit-"+packIndex+"-red.png"));
                if(diagnostic()&&compiled)diagnosticRed=attachments(pipeline);
                if(compiled){
                    currentCase.addProperty("patched_programs",runtimeLong("patchedPrograms")-patchStart);
                    currentCase.addProperty("sampler_programs",runtimeLong("samplerPrograms")-samplerStart);
                    currentCase.addProperty("field_ready",runtimeBoolean("fieldReady"));
                    world.addScheduledTask(()->((SourceTile)world.getTileEntity(SOURCE)).mode=1);
                    colorPhase=1;settle=0;return;
                }
                currentCase.addProperty("valid",compiled&&!rgb);
            }else{
                currentCase.addProperty("normal_tesr_draws",normalDraws);currentCase.addProperty("fast_tesr_draws",fastDraws);currentCase.addProperty("particle_draws",particleDraws);
                currentCase.addProperty("draw_error_blue",GL11.glGetError());
                JsonObject image=capture("shader-audit-"+packIndex+"-blue.png");currentCase.add("blue_image",image);
                double difference=currentCase.getAsJsonObject("red_image").get("red_blue_score").getAsDouble()-image.get("red_blue_score").getAsDouble();
                if(diagnostic()){long[] blue=attachments(pipeline);currentCase.add("material_red",new Gson().toJsonTree(diagnosticRed));currentCase.add("material_blue",new Gson().toJsonTree(blue));currentCase.addProperty("normal_specular_alpha_unchanged",java.util.Arrays.equals(diagnosticRed,blue));}
                currentCase.addProperty("color_only_score_change",difference);currentCase.addProperty("uploaded_sections",runtimeLong("uploadedSections"));
                currentCase.addProperty("valid",compiled&&(rgb?(runtimeBoolean("active")&&runtimeBoolean("fieldReady")&&currentCase.get("patched_programs").getAsLong()>0&&currentCase.get("sampler_programs").getAsLong()>0&&difference>0.15):(!runtimeBoolean("active")&&!runtimeBoolean("fieldReady")&&CALLBACKS.get()==0&&currentCase.get("scalar_chunk_clean").getAsBoolean())));
            }
            if(colorPhase==1&&diagnostic()&&!skyDone){roof(0);colorPhase=7;settle=0;return;}
            if(colorPhase==3&&diagnostic()){hop(true);colorPhase=4;settle=0;return;}
            if(colorPhase==1&&config.has("lifecycle")&&config.get("lifecycle").getAsBoolean()){enablePack(false);colorPhase=2;settle=0;return;}
            cases.add(currentCase);System.out.println("PULSAR_SHADER_CASE "+currentCase);
            if(++packIndex>=packs.size()){finish(null);return;}
            loadPack();
        }catch(Throwable failure){failure.printStackTrace();finish(failure);}
    }
    private void loadPack()throws Exception{
        colorPhase=0;world.addScheduledTask(()->((SourceTile)world.getTileEntity(SOURCE)).mode=0);
        for(int i=0;i<16&&GL11.glGetError()!=0;i++){}
        patchStart=runtimeLong("patchedPrograms");samplerStart=runtimeLong("samplerPrograms");
        enablePack(true);
    }
    private void enablePack(boolean enabled)throws Exception{
        var file=Minecraft.getMinecraft().gameDir.toPath().resolve("config/shaders.properties");
        Properties properties=new Properties();if(Files.exists(file))try(var in=Files.newInputStream(file)){properties.load(in);}
        properties.setProperty("enableShaders",Boolean.toString(enabled));properties.setProperty("shaderPack",packs.get(packIndex).getAsString());
        try(var out=Files.newOutputStream(file)){properties.store(out,"Disposable Pulsar shader audit");}
        Class.forName("net.coderbot.iris.Iris").getMethod("reload").invoke(null);settle=0;
    }
    
    public static class ProbeTile extends TileEntity {}
    public static final class FastTile extends ProbeTile {public boolean hasFastRenderer(){return true;}}
    private static void vertices(net.minecraft.client.renderer.BufferBuilder b,double x,double y,double z){
        var sprite=Minecraft.getMinecraft().getTextureMapBlocks().getAtlasSprite("minecraft:blocks/quartz_block_side");
        for(int i=0;i<4;i++)b.pos(x+(i==1||i==2?1:0),y+(i>=2?1:0),z+.8).color(1f,1f,1f,.75f).tex(i==1||i==2?sprite.getMaxU():sprite.getMinU(),i>=2?sprite.getMinV():sprite.getMaxV()).lightmap(80,0).endVertex();
    }
    private static final class ProbeRenderer extends net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer<ProbeTile>{
        public void render(ProbeTile tile,double x,double y,double z,float partial,int destroy,float alpha){
            normalDraws++;bindTexture(net.minecraft.client.renderer.texture.TextureMap.LOCATION_BLOCKS_TEXTURE);
            var tess=net.minecraft.client.renderer.Tessellator.getInstance();tess.getBuffer().begin(7,net.minecraft.client.renderer.vertex.DefaultVertexFormats.BLOCK);vertices(tess.getBuffer(),x,y,z);tess.draw();
        }
    }
    private static final class FastRenderer extends net.minecraftforge.client.model.animation.FastTESR<FastTile>{
        public void renderTileEntityFast(FastTile tile,double x,double y,double z,float partial,int destroy,float alpha,net.minecraft.client.renderer.BufferBuilder buffer){fastDraws++;vertices(buffer,x,y,z);}
    }
    private static final class ProbeParticle extends net.minecraft.client.particle.Particle{
        ProbeParticle(World world){super(world,X+8.5,Y+2.5,Z+11.5);particleMaxAge=10;motionX=motionY=motionZ=0;particleGravity=0;particleScale=2;setParticleTexture(Minecraft.getMinecraft().getTextureMapBlocks().getAtlasSprite("minecraft:blocks/quartz_block_side"));}
        public int getFXLayer(){return 1;}
        public void renderParticle(net.minecraft.client.renderer.BufferBuilder b,net.minecraft.entity.Entity camera,float partial,float rx,float rz,float ryz,float rxy,float rxz){particleDraws++;super.renderParticle(b,camera,partial,rx,rz,ryz,rxy,rxz);}
    }

    private void roof(int color){world.addScheduledTask(()->{
        ((SourceTile)world.getTileEntity(SOURCE)).mode=color<0?1:3;
        IBlockState state=color<0?Blocks.QUARTZ_BLOCK.getDefaultState():Blocks.STAINED_GLASS.getDefaultState().withProperty(net.minecraft.block.BlockStainedGlass.COLOR,color==0?net.minecraft.item.EnumDyeColor.RED:net.minecraft.item.EnumDyeColor.BLUE);
        for(int x=1;x<15;x++)for(int z=1;z<19;z++)world.setBlockState(new BlockPos(X+x,Y+7,Z+z),state,3);
    });}
    private void hop(boolean nether){
        var player=Minecraft.getMinecraft().player.getUniqueID();
        world.addScheduledTask(()->{
            var server=world.getMinecraftServer();int dimension=nether?-1:0;
            if(nether&&net.minecraftforge.common.DimensionManager.getWorld(-1)==null)net.minecraftforge.common.DimensionManager.initDimension(-1);
            WorldServer target=server.getWorld(dimension);
            if(nether){
                target.getGameRules().setOrCreateGameRule("doMobSpawning","false");
                for(int cx=(X>>4)-1;cx<=(X>>4)+1;cx++)for(int cz=(Z>>4)-1;cz<=(Z>>4)+2;cz++)target.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
                for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<20;z++)target.setBlockState(new BlockPos(X+x,Y+y,Z+z),x==0||x==15||y==0||y==7||z==0||z==19?Blocks.QUARTZ_BLOCK.getDefaultState():Blocks.AIR.getDefaultState(),2);
                target.setBlockState(SOURCE,source.getDefaultState(),3);((SourceTile)target.getTileEntity(SOURCE)).mode=2;
                var light=((PulsarWorld)target).pulsar$getLightManager();for(int cx=(X>>4)-1;cx<=(X>>4)+1;cx++)for(int cz=(Z>>4)-1;cz<=(Z>>4)+2;cz++)light.forceRelightChunk(cx,cz);
            }
            var entity=server.getPlayerList().getPlayerByUUID(player);
            server.getPlayerList().transferPlayerToDimension(entity,dimension,new net.minecraft.world.Teleporter(target){
                public void placeInPortal(net.minecraft.entity.Entity entity,float yaw){entity.setLocationAndAngles(X+8.5,Y+1,Z+15.5,180,0);}
            });entity.setPositionAndUpdate(X+8.5,Y+1,Z+15.5);entity.rotationYaw=180;entity.rotationPitch=0;
        });
    }
    private boolean diagnostic(){return packs.get(packIndex).getAsString().contains("PulsarDiagnostic");}
    private static long[] attachments(Object pipeline)throws Exception{
        var field=pipeline.getClass().getDeclaredField("renderTargets");field.setAccessible(true);Object targets=field.get(pipeline);
        long[] result=new long[3];int previous=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),oldPack=GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        int fbo=GL30.glGenFramebuffers();GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,0);GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,fbo);
        try{for(int i=0;i<2;i++){
            Object target=targets.getClass().getMethod("get",int.class).invoke(targets,i+1);int texture=(int)target.getClass().getMethod("getMainTexture").invoke(target);
            GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER,GL30.GL_COLOR_ATTACHMENT0,GL11.GL_TEXTURE_2D,texture,0);GL11.glReadBuffer(GL30.GL_COLOR_ATTACHMENT0);
            if(GL30.glCheckFramebufferStatus(GL30.GL_READ_FRAMEBUFFER)!=GL30.GL_FRAMEBUFFER_COMPLETE)throw new IllegalStateException("Diagnostic attachment incomplete");
            var mc=Minecraft.getMinecraft();var bytes=BufferUtils.createByteBuffer(32*32*4);GL11.glReadPixels(mc.displayWidth/2-16,mc.displayHeight/2-16,32,32,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,bytes);
            long hash=1;while(bytes.hasRemaining())hash=31*hash+Byte.toUnsignedInt(bytes.get());result[i]=hash;
        }
            var sf=pipeline.getClass().getDeclaredField("shadowRenderTargets");sf.setAccessible(true);Object shadows=sf.get(pipeline);
            if(shadows==null)throw new IllegalStateException("Diagnostic shadow target absent");
            int shadow=(int)shadows.getClass().getMethod("getColorTextureId",int.class).invoke(shadows,0);
            GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER,GL30.GL_COLOR_ATTACHMENT0,GL11.GL_TEXTURE_2D,shadow,0);
            int size=(int)shadows.getClass().getMethod("getResolution").invoke(shadows);
            var pixels=BufferUtils.createByteBuffer(size*size*4);GL11.glReadPixels(0,0,size,size,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,pixels);long hash=1;int drawn=0;
            for(int i=0;i<size*size;i++){int red=Byte.toUnsignedInt(pixels.get(i*4)),green=Byte.toUnsignedInt(pixels.get(i*4+1)),blue=Byte.toUnsignedInt(pixels.get(i*4+2));if(Math.abs(red-64)<=1&&Math.abs(green-128)<=1&&Math.abs(blue-191)<=1)drawn++;hash=31*hash+red;hash=31*hash+green;hash=31*hash+blue;}
            if(drawn==0)throw new IllegalStateException("Diagnostic shadow shader did not draw");result[2]=hash;
        }finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,previous);GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,oldPack);GL30.glDeleteFramebuffers(fbo);}
        return result;
    }
    private static long runtimeLong(String name){
        try{return ((Number)Class.forName("com.sumirelabs.pulsar.rgb.RgbShaderRuntime").getMethod(name).invoke(null)).longValue();}
        catch(ReflectiveOperationException ignored){return 0;}
    }
    private static boolean runtimeBoolean(String name){
        try{return (boolean)Class.forName("com.sumirelabs.pulsar.rgb.RgbShaderRuntime").getMethod(name).invoke(null);}
        catch(ReflectiveOperationException ignored){return false;}
    }
    private JsonObject capture(String name)throws Exception{
        var mc=Minecraft.getMinecraft();var target=mc.getFramebuffer();
        int width=Math.min(mc.displayWidth,target.framebufferWidth),height=Math.min(mc.displayHeight,target.framebufferHeight);
        int previous=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),pack=GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        var pixels=BufferUtils.createByteBuffer(width*height*4);
        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,0);GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,target.framebufferObject);
        try{GL11.glReadPixels(0,0,width,height,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,pixels);}
        finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,previous);GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER,pack);}
        var image=new java.awt.image.BufferedImage(width,height,java.awt.image.BufferedImage.TYPE_INT_ARGB);
        double red=0,green=0,blue=0;int count=0;
        for(int y=0;y<height;y++)for(int x=0;x<width;x++){
            int at=(x+y*width)*4,r=Byte.toUnsignedInt(pixels.get(at)),g=Byte.toUnsignedInt(pixels.get(at+1)),b=Byte.toUnsignedInt(pixels.get(at+2));
            image.setRGB(x,height-y-1,0xFF000000|r<<16|g<<8|b);
            if(Math.abs(x-width/2)<64&&Math.abs(y-height/2)<64){red+=r;green+=g;blue+=b;count++;}
        }
        var path=mc.gameDir.toPath().resolve("screenshots").resolve(name);Files.createDirectories(path.getParent());javax.imageio.ImageIO.write(image,"png",path.toFile());
        JsonObject value=new JsonObject();value.addProperty("red",red/count);value.addProperty("green",green/count);value.addProperty("blue",blue/count);
        value.addProperty("red_blue_score",(red-blue)/(red+blue+1));value.addProperty("capture_error",GL11.glGetError());return value;
    }
    private void finish(Throwable failure){
        if(finished)return;finished=true;JsonObject result=new JsonObject();result.addProperty("completed",failure==null);
        if(failure!=null)result.addProperty("failure",failure.toString());result.add("cases",cases);
        result.addProperty("all_colored",cases.size()==packs.size()&&java.util.stream.StreamSupport.stream(cases.spliterator(),false).allMatch(e->e.getAsJsonObject().get("valid").getAsBoolean()));
        result.addProperty("all_compiled",cases.size()==packs.size()&&java.util.stream.StreamSupport.stream(cases.spliterator(),false).allMatch(e->e.getAsJsonObject().get("compiled_pipeline").getAsBoolean()));
        try{Path out=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/shader-audit.json");Files.createDirectories(out.getParent());Files.writeString(out,new GsonBuilder().setPrettyPrinting().create().toJson(result));}
        catch(Exception error){throw new RuntimeException(error);}
        world.addScheduledTask(() -> world.getGameRules().setOrCreateGameRule("fourbench_complete","true"));
    }
}
