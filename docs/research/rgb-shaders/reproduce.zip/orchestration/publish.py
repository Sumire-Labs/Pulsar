from pathlib import Path
import json,zipfile,hashlib,shutil,xml.etree.ElementTree as ET
root=Path('E:/Github/Pulsar-RGB-20261016')
repo=Path('C:/Users/s12kuma01/.codex/worktrees/rgb-completion/Pulsar')
out=repo/'docs/research/rgb-shaders'
raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
def read(run):return json.loads((root/'runs'/run/'results/shader-audit.json').read_text())
selected={}
for loader in ['demonica','actinium']:
 run=f'shader-rgb-{loader}-final-1';r=read(run);cases=r['cases'][:7]
 assert len(cases)==7 and all(c['valid'] and c['compiled_pipeline'] for c in cases)
 selected[loader]={'run':run,'cases':cases}
for mode in ['diagnostic','scalar']:
 for loader in ['demonica','actinium']:
  run=f'shader-diagnostic-{loader}-6' if mode=='diagnostic' else f'shader-scalar-{loader}-final-1'
  r=read(run);assert r['completed'] and r['all_compiled'] and r['all_colored'],(run,r)
  if mode=='diagnostic':
   c=r['cases'][0]
   assert c['normal_specular_alpha_unchanged'] and c['sky_filter_changed'] and c['dimension_field_reset']
   assert c['normal_tesr_draws']>0 and c['fast_tesr_draws']>0 and c['particle_draws']>0
  else:
   assert all(c['scalar_chunk_clean'] and c['source_callbacks']==0 and c['patched_programs']==0 and c['sampler_programs']==0 and not c['field_ready'] for c in r['cases'])
  selected[f'{mode}_{loader}']={'run':run,'report':r}
for entry in selected.values():
 run=entry['run'];dest=raw/run;dest.mkdir(exist_ok=True)
 for name,source in [('shader-audit.json','results/shader-audit.json'),('stage.json','stage.json'),('status.json','status.json')]:shutil.copy2(root/'runs'/run/source,dest/name)
 # Logs are compressed, with no external jar/pack content.
 with zipfile.ZipFile(dest/'log.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(root/'runs'/run/'game.log','game.log')
(out/'summary.json').write_text(json.dumps(selected,indent=2))
packs=json.loads((root/'phase10/shader-packs.json').read_text())
for pack in packs:
 file=root/'artifacts/shaders/packs'/pack['filename'];pack['sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
(out/'shader-packs.json').write_text(json.dumps(packs,indent=2))
shutil.copy2(root/'phase10/scalar-byte-proof.json',out/'scalar-byte-proof.json')
shutil.copy2(root/'phase10/unit-tests.json',out/'unit-tests.json')
loaders=[]
for file,url,version,license in [('Demonica-0.8.2.jar','https://github.com/ndellagrotte/Demonica','0.8.2','AGPL-3.0'),('Actinium-alpha-0.0.12.jar','https://github.com/Q-Engineering-Source/Actinium','alpha-0.0.12','GPL-3.0')]:
 jar=root/'artifacts/shaders'/file;loaders.append({'filename':file,'version':version,'license':license,'repository':url,'sha256':hashlib.sha256(jar.read_bytes()).hexdigest()})
(out/'loaders.json').write_text(json.dumps(loaders,indent=2))
failures={}
for folder in sorted((root/'runs').glob('shader-*')):
 if folder.name in {e['run'] for e in selected.values()}:continue
 report=folder/'results/shader-audit.json';status=folder/'status.json'
 if report.exists():
  r=json.loads(report.read_text());failures[folder.name]={'completed':r.get('completed'),'all_compiled':r.get('all_compiled'),'all_colored':r.get('all_colored'),'failure':r.get('failure')}
 elif status.exists():failures[folder.name]={'completed':False,'note':'No completed report; see retained local logs. Diagnostic5 was stopped because pure-primary sky expectations used unmodified dye filters.'}
(out/'attempts.json').write_text(json.dumps(failures,indent=2))
with zipfile.ZipFile(out/'reproduce.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(root/'helper/src/main/java/com/sumirelabs/shaderaudit/ShaderAudit.java','helper/ShaderAudit.java')
 for file in (root/'helper/src/main/resources/assets/shaderaudit').rglob('*'):
  if file.is_file():z.write(file,'helper/assets/shaderaudit/'+file.relative_to(root/'helper/src/main/resources/assets/shaderaudit').as_posix())
 with zipfile.ZipFile(root/'artifacts/shaders/packs/PulsarDiagnostic.zip') as diagnostic:
  for name in diagnostic.namelist():z.writestr('diagnostic/'+name,diagnostic.read(name))
 for name in ['run.ps1','run06.ps1','world.cjs','publish.py']:z.write(root/'phase10'/name,'orchestration/'+name)
 z.writestr('README.txt','Original diagnostic Java/GLSL: LGPL-3.0-only. Requires Pulsar/Minecraft/Forge dev environment and local Prism profiles. No loader or third-party shaderpack sources/assets included. RGB and SCALAR diagnostics use the same helper source; stage.json records each compiled artifact hash. Set the pure-primary test glass filters as in the run scripts. Do not run these scripts against valuable worlds.\n')
for loader in ['demonica','actinium']:
 run=f'shader-diagnostic-{loader}-6';dest=out/'screenshots'/loader;dest.mkdir(parents=True,exist_ok=True)
 for name in ['shader-audit-0-red.png','shader-audit-0-blue.png','shader-audit-sky-red.png','shader-audit-sky-blue.png','shader-audit-nether-green.png','shader-audit-overworld-blue.png']:
  shutil.copy2(root/'runs'/run/'screenshots'/name,dest/name)
for file in out.rglob("*"):
 if file.is_file() and file.suffix in [".json",".md"]:file.write_bytes(file.read_bytes().replace(b"\r\n",b"\n"))
checks={}
for file in sorted(out.rglob('*')):
 if file.is_file() and file.name!='SHA256SUMS':checks[file.relative_to(out).as_posix()]=hashlib.sha256(file.read_bytes()).hexdigest()
(out/'SHA256SUMS').write_bytes(''.join(f'{h}  {name}\n' for name,h in checks.items()).encode())
print('Published',len(checks),'evidence files')
