param([string]$Run,[string]$Mode='RGB',[string]$Command='rgbaudit',[switch]$Celeritas,[switch]$FastCeleritas,[string]$Template='flat',[string]$Artifact='parity-bytes.jar',[ValidateSet('demonica','actinium')][string]$Loader='demonica',[string]$PackFilter='',[int]$SceneX=20000,[int]$SceneZ=20032,[switch]$Lifecycle)
$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
$instance='C:\Users\s12kuma01\AppData\Roaming\PrismLauncher\instances\Pulsar-RGB-Parity077-20261018'
$game="$instance\minecraft"
function Owned { @(Get-CimInstance Win32_Process -Filter "Name='javaw.exe'" | Where-Object CommandLine -like '*Pulsar-RGB-Parity077-20261018*') }
if((Owned).Count){throw 'Owned RGB game is already running'}
if($Run -notmatch '^[a-z0-9-]+$'){throw 'Invalid run name'}
$out="$root\runs\$Run"
if(Test-Path $out){throw 'Run already exists'}
New-Item -ItemType Directory -Force $out | Out-Null
if(Test-Path $game){
    $resolved=[IO.Path]::GetFullPath($game)
    if($resolved -ne [IO.Path]::GetFullPath("$instance\minecraft")){throw 'Unexpected game path'}
    Rename-Item -LiteralPath $resolved -NewName "minecraft-backup-$Run"
    [IO.File]::WriteAllText("$out\previous-instance-path.txt", "$instance\minecraft-backup-$Run")
}
New-Item -ItemType Directory -Force "$game\mods","$game\saves" | Out-Null
Copy-Item "$root\common-mods\*" "$game\mods" -Recurse
Copy-Item "$root\frozen\config" "$game\config" -Recurse
Copy-Item "$root\frozen\options.txt" "$game\options.txt"
Copy-Item "$root\artifacts\$Artifact" "$game\mods\pulsar.jar"
if($Command -like 'issueaudit*'){
    Copy-Item "$root\artifacts\issue-audit-fresh.jar" "$game\mods\issue-audit.jar"
    if($Command -like 'issueaudit ship*'){Copy-Item 'E:\Github\Pulsar-Issues-20261015\cqr-mods\*.jar' "$game\mods"}
}
if($Command -like 'renderperf*'){Copy-Item "$root\artifacts\render-perf.jar" "$game\mods\render-perf.jar" }
if($Command -like 'actoraudit*'){Copy-Item "$root\artifacts\actor-audit.jar" "$game\mods\actor-audit.jar" }
if($Command -like 'actoraudit day*'){Copy-Item "$root\artifacts\actor-audit-day.jar" "$game\mods\actor-audit.jar" }
if($Command -like 'actoraudit*objects*'){Copy-Item "$root\artifacts\actor-audit-objects.jar" "$game\mods\actor-audit.jar" }
if($Command -like 'skyaudit*'){Copy-Item "$root\artifacts\phase6-sky-audit.jar" "$game\mods\sky-audit.jar"}
if($Command -like 'rgbaudit*'){Copy-Item "$root\artifacts\phase6-block-audit.jar" "$game\mods\filter-audit.jar"}
if($Run -like 'draw-render-profile*'){
    $relaunch=Get-Content "$game/config/relauncher.json" -Raw|ConvertFrom-Json
    $relaunch.args += " -XX:StartFlightRecording=filename=$out/profile.jfr,settings=profile,dumponexit=true"
    $relaunch|ConvertTo-Json|Set-Content "$game/config/relauncher.json" -Encoding UTF8
}
if($Run -like 'parity-packed*'){
 $relaunch=Get-Content "$game/config/relauncher.json" -Raw|ConvertFrom-Json
 $relaunch.args += ' -Dpulsar.rgb.packed=true'
 $relaunch|ConvertTo-Json|Set-Content "$game/config/relauncher.json" -Encoding UTF8
}
if($FastCeleritas){
    $relaunch=Get-Content "$game\config\relauncher.json" -Raw|ConvertFrom-Json
    $relaunch.args += ' -Dceleritas.useVintageFastBlockRenderer=true'
    $relaunch|ConvertTo-Json|Set-Content "$game\config\relauncher.json" -Encoding UTF8
}
if($Celeritas){Copy-Item 'E:\Github\Pulsar-Issues-20261015\compat-mods\celeritas*.jar' "$game\mods"}
Copy-Item "$root/artifacts/parity077-driver.jar" "$game/mods/four-engine-driver.jar" -Force
if($Command -like 'parityaudit*'){
 Copy-Item "$root/artifacts/parity-audit.jar" "$game/mods/parity-audit.jar"
 [IO.File]::WriteAllText("$game/config/pulsar-colors.cfg", "parityaudit:static_source = 0, 0, 15`n")
}
$cfg=Get-Content "$game\config\pulsar.cfg" -Raw
$cfg=[regex]::Replace($cfg,'(?m)^\s*S:lightingMode=.*$','')
$cfg=$cfg.Replace('general {',"general {`n    S:lightingMode=$Mode")
if($Run -like '*-max-*'){
 $cfg=[regex]::Replace($cfg,'(?m)^\s*S:rgbGameplayLight=.*$','')
 $cfg=$cfg.Replace('general {',"general {`n    S:rgbGameplayLight=RGB_MAX")
}
[IO.File]::WriteAllText("$game\config\pulsar.cfg",$cfg)

if($Command -eq 'shaderaudit'){
 $auditJar=if($Mode -eq "SCALAR"){ "shader-audit-scalar.jar" }else{ "shader-audit-color.jar" }; Copy-Item "$root/artifacts/shaders/$auditJar" "$game/mods/shader-audit.jar"
 $loaderJar=if($Loader -eq 'demonica'){'Demonica-0.8.2.jar'}else{'Actinium-alpha-0.0.12.jar'}
 Copy-Item "$root/artifacts/shaders/$loaderJar" "$game/mods/$loaderJar"
 New-Item -ItemType Directory -Force "$game/shaderpacks" | Out-Null
 [IO.File]::WriteAllText("$game/config/pulsar-filters.cfg","minecraft:stained_glass[color=red] = 0, 15, 15`nminecraft:stained_glass[color=blue] = 15, 15, 0`n")
 Copy-Item "$root/artifacts/shaders/packs/*.zip" "$game/shaderpacks"
 $packs=Get-Content "$root/phase10/shader-packs.json" -Raw|ConvertFrom-Json
 if($Mode -eq "SCALAR"){$packs=@($packs|Where-Object filename -ne "PulsarDiagnostic.zip")}
 if($PackFilter){$packs=@($packs | Where-Object filename -like "*$PackFilter*")}
 [IO.File]::WriteAllText("$game/shader-audit.json",(@{x=$SceneX;z=$SceneZ;lifecycle=[bool]$Lifecycle;loader=$Loader;packs=@($packs|ForEach-Object filename);baseline=($Mode -eq 'SCALAR')}|ConvertTo-Json -Depth 5))
 [IO.File]::WriteAllText("$game/config/shaders.properties","enableShaders=false`nshaderPack=`n")
}

Copy-Item "$root\templates\$Template" "$game\saves\Bench Updates" -Recurse
& node "$root\phase10\world.cjs" "$game\saves\Bench Updates" candidate updates $Run $Command
if($LASTEXITCODE -ne 0){throw 'World setup failed'}
$resultPath="$game\saves\Bench Updates\lightbench-results"
if(Test-Path $resultPath){
    if([IO.Path]::GetFullPath($resultPath) -ne [IO.Path]::GetFullPath("$instance\minecraft\saves\Bench Updates\lightbench-results")){throw 'Unexpected result path'}
    $archive=[IO.Path]::GetFullPath("$out\inherited-results")
    if(-not $archive.StartsWith([IO.Path]::GetFullPath("$root\runs")+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected results archive'}
    Move-Item -LiteralPath $resultPath -Destination $archive
}
New-Item -ItemType Directory -Force $resultPath | Out-Null
[IO.File]::WriteAllText("$game\lightbench-variant.txt",'candidate')
[IO.File]::WriteAllText("$game\four-engine-bench.marker",'disposable RGB validation')
[IO.File]::WriteAllText("$game\four-engine-mode.txt",'updates')

# Disposable 0.7 profile only: no direct Cleanroom patch can preempt the chosen relauncher version.
foreach($name in @('-cleanroom-relauncher-1.1.2.jar','+Fugue-0.24.3.jar','-Red-Core-MC-1.8-1.12-0.7.1.jar','Bubbles-2.4.10.jar','Thaumcraft-1.12.2-6.1.BETA26.jar','Fluidlogged-API-v3.3.3-mc1.12.2.jar')){
 $path=Join-Path "$game/mods" $name
 if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path}
}
Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/-cleanroom-relauncher-1.2.1.jar' "$game/mods/!cleanroom-relauncher-1.2.1.jar"
Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/+Fugue-0.25.4.jar' "$game/mods/+Fugue-0.25.4.jar"
$old=Get-Content "$game/config/relauncher.json" -Raw|ConvertFrom-Json
$config=@{selectedVersion='0.7.7-alpha';latestVersion='0.7.7-alpha';javaPath='C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot/bin/javaw.exe';args=$old.args;autoSetup=$true;enableRelauncher=$true;fetchUpdates=$false;clearCleanroomFolder=$false;clearJavaProvisionFolder=$false;darkMode=$false;targetJavaVersion=0}
$config|ConvertTo-Json|Set-Content "$game/config/relauncher.json" -Encoding UTF8

$diagnosticHashes=@{}
Get-ChildItem "$game\mods" -Filter '*.jar' | Where-Object { $_.Name -like '*audit*.jar' -or $_.Name -eq 'render-perf.jar' } | ForEach-Object {$diagnosticHashes[$_.Name]=(Get-FileHash -LiteralPath $_.FullName).Hash}
[IO.File]::WriteAllText("$out\stage.json",(@{diagnostic_sha256=$diagnosticHashes;mode=$Mode;command=$Command;artifact=$Artifact;sha256=(Get-FileHash "$game\mods\pulsar.jar").Hash;celeritas=[bool]$Celeritas;fast_celeritas=[bool]$FastCeleritas}|ConvertTo-Json))
Start-Process 'C:\Users\s12kuma01\AppData\Local\Programs\PrismLauncher\prismlauncher.exe' -ArgumentList '-l','Pulsar-RGB-Parity077-20261018','--offline','Serrecable' -WindowStyle Hidden
$seen=$false;$deadline=[DateTime]::UtcNow.AddMinutes(30)
while([DateTime]::UtcNow -lt $deadline){
    Start-Sleep -Seconds 2
    $processes=Owned
    if($processes.Count){$seen=$true}
    if($seen -and -not $processes.Count){break}
}
if((Owned).Count){throw 'RGB game timed out; retained for diagnosis'}
Copy-Item "$game\logs\latest.log" "$out\game.log"
if(Test-Path "$game\saves\Bench Updates\lightbench-results"){Copy-Item "$game\saves\Bench Updates\lightbench-results" "$out\results" -Recurse}
if(Test-Path "$game\screenshots"){Copy-Item "$game\screenshots" "$out\screenshots" -Recurse}
$valid=Test-Path "$out\results\observer.json"
if($Command -eq 'shaderaudit'){$valid=(Test-Path "$out/results/shader-audit.json") -and ((Get-Content "$out/results/shader-audit.json" -Raw|ConvertFrom-Json).completed)}
if($Command -like 'renderperf*'){Copy-Item "$root\artifacts\render-perf.jar" "$game\mods\render-perf.jar" }
if($Command -like 'renderperf*'){$valid=(Test-Path "$out\results\render-perf.json") -and ((Get-Content "$out\results\render-perf.json" -Raw|ConvertFrom-Json).valid -eq $true)}
if($Command -like 'actoraudit*'){$valid=(Test-Path "$out\results\actor-audit.json") -and ((Get-Content "$out\results\actor-audit.json" -Raw|ConvertFrom-Json).valid -eq $true)}
if($Command -like 'skyaudit*'){$valid=(Test-Path "$out\results\sky-audit.json") -and ((Get-Content "$out\results\sky-audit.json" -Raw|ConvertFrom-Json).valid -eq $true)}
if($Command -like 'rgbaudit*'){$valid=(Test-Path "$out\results\rgb-audit.json") -and ((Get-Content "$out\results\rgb-audit.json" -Raw|ConvertFrom-Json).valid -eq $true)}
if($Command -like 'parityaudit*'){$valid=(Test-Path "$out/results/parity-audit.json") -and ((Get-Content "$out/results/parity-audit.json" -Raw|ConvertFrom-Json).valid -eq $true)}
[IO.File]::WriteAllText("$out\status.json",(@{valid=$valid;finished=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
Write-Output "RGB run $Run valid=$valid"
