package com.sumirelabs.skyaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.api.BlockLightFilters;
import com.sumirelabs.pulsar.world.PulsarWorld;
import com.sumirelabs.pulsar.light.WorldLightManager;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.command.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.util.*;
import java.nio.file.*;
import java.nio.ByteOrder;
import java.util.concurrent.CompletableFuture;

/** Disposable native reference audit, never distributed in the production jar. */
@Mod(modid="skyaudit",name="RGB Sky Audit",version="1",dependencies="required-after:pulsar")
public final class SkyAudit {
    private static final int X=20000,Z=20032,Y=80,W=32,D=16,H=48;
    private final JsonObject report=new JsonObject();
    private final JsonArray cases=new JsonArray();
    private WorldServer world;
    private int step=-1,ticks,waited;
    private boolean sent,reload,range;
    private CompletableFuture<JsonObject> client;
    private int[][] expected;
    private String name;
    private static volatile String photo;
    private int frames;
    @Mod.EventHandler public void init(FMLInitializationEvent e) {
        BlockLightFilters.register(Blocks.GLASS.getDefaultState(),0,15,15);
        MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "skyaudit";}
            public String getUsage(ICommandSender s){return "/skyaudit [reload]";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer s,ICommandSender sender,String[] args){
                world=(WorldServer)sender.getEntityWorld(); reload=Arrays.asList(args).contains("reload");range=Arrays.asList(args).contains("range");step=0;ticks=0;
                report.add("cases",cases);report.addProperty("valid",false);
            }
        });
    }
    @SubscribeEvent public void photo(TickEvent.RenderTickEvent e) {
        if(e.phase!=TickEvent.Phase.END||photo==null||++frames<30)return;
        Minecraft mc=Minecraft.getMinecraft();
        net.minecraft.util.ScreenShotHelper.saveScreenshot(mc.gameDir,"sky-"+photo+".png",mc.displayWidth,mc.displayHeight,mc.getFramebuffer());photo=null;
    }
    private WorldLightManager manager(){return ((PulsarWorld)world).pulsar$getLightManager();}
    private void load(int x,int z,int w,int d){
        for(int cx=(x>>4)-2;cx<=((x+w-1)>>4)+2;cx++)for(int cz=(z>>4)-2;cz<=((z+d-1)>>4)+2;cz++)
            world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
    }
    private void teleport(boolean floating){
        var p=(net.minecraft.entity.player.EntityPlayerMP)world.playerEntities.get(0);
        p.setPositionAndUpdate(floating?X+152.5:X+17.5,floating?90:Y+H-5,floating?Z+24.5:Z+5.5);
        world.getPlayerChunkMap().updateMovingPlayer(p);
    }
    private void roof(IBlockState state){
        for(int x=X+1;x<X+W-1;x++)for(int z=Z+1;z<Z+D-1;z++)world.setBlockState(new BlockPos(x,Y+H-2,z),state,3);
    }
    private void wall(IBlockState state){
        for(int y=Y+1;y<Y+H-2;y++)for(int z=Z+1;z<Z+D-1;z++)world.setBlockState(new BlockPos(X+16,y,z),state,3);
    }
    private void canopy(IBlockState state){
        for(int x=X+128;x<X+176;x++)for(int z=Z;z<Z+48;z++)world.setBlockState(new BlockPos(x,126,z),state,3);
    }
    private boolean ready(boolean floating){
        int x=floating?X+128:X,z=Z,w=floating?48:W,d=floating?48:D;
        for(int cx=x>>4;cx<=(x+w-1)>>4;cx++)for(int cz=z>>4;cz<=(z+d-1)>>4;cz++){
            Chunk c=world.getChunkProvider().getLoadedChunk(cx,cz);
            if(c==null||!manager().canSendUpdatedChunkLight(cx,cz)||((RgbChunk)c).pulsar$getRgbSkySnapshot()==null)return false;
        }
        return true;
    }
    @SubscribeEvent public void tick(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||step<0||++ticks<20)return;ticks=0;
        try{
            if(step==0){
                load(X,Z,W,D);
                report.addProperty("cache_valid_main",((com.sumirelabs.pulsar.light.PulsarChunk)world.getChunk(X>>4,Z>>4)).pulsar$hasSavedLightValid());
                if(!reload){
                    for(int x=X;x<X+W;x++)for(int y=Y;y<Y+H;y++)for(int z=Z;z<Z+D;z++){
                        boolean wall=y<Y+H-1&&(x==X||x==X+W-1||z==Z||z==Z+D-1||y==Y||y==Y+H-2);
                        world.setBlockState(new BlockPos(x,y,z),wall?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
                    }
                    for(int cx=X>>4;cx<=(X+W-1)>>4;cx++)manager().forceRelightChunk(cx,Z>>4);
                }
                teleport(false);step=1;return;
            }
            if((step&1)==1){
                boolean floating=step>=21;
                if(!ready(floating)){if(++waited>120)throw new IllegalStateException("lighting timeout step="+step);return;}waited=0;
                if(!sent){
                    int x=floating?X+144:X,z=floating?Z+16:Z,w=floating?16:W;
                    for(int cx=x>>4;cx<=(x+w-1)>>4;cx++){
                        var entry=world.getPlayerChunkMap().getEntry(cx,z>>4);
                        if(entry!=null){entry.sendToPlayers();for(var p:world.playerEntities)entry.sendToPlayer((net.minecraft.entity.player.EntityPlayerMP)p);}
                    }
                    sent=true;return;
                }
                name=reload?(floating?"reload-floating":"reload-room"):switch(step){
                    case 1->"sealed";case 3->"red-glass";case 5->"blue-glass";case 7->"direct-red";
                    case 9->"sky-close";case 11->"sky-open";case 13->"boundary-wall";
                    case 15->"full-relight";case 17->"remove-wall";case 19->"final-blue";
                    case 21->"floating-red";case 23->"floating-close";case 25->"floating-open";default->"floating-restored-red";};
                expected=floating?floatingReference(step):reference();
                cases.add(compare(expected,floating));client=clientCheck(expected,floating);step++;return;
            }
            if(!client.isDone())return;
            JsonObject c=client.join();report.add("client-"+step,c);
            if(!c.get("valid").getAsBoolean()){
                if(++waited>30)throw new IllegalStateException("client mismatch step="+step+" "+c);
                client=clientCheck(expected,step>=22);return;
            }
            waited=0;sent=false;
            if(step==28){finish(null);return;}
            if(reload&&step==2)step=20;
            if(step==2)roof(Blocks.STAINED_GLASS.getStateFromMeta(EnumDyeColor.RED.getMetadata()));
            if(step==4)roof(Blocks.STAINED_GLASS.getStateFromMeta(EnumDyeColor.BLUE.getMetadata()));
            if(step==6)roof(Blocks.GLASS.getDefaultState());
            if(step==8)roof(Blocks.STONE.getDefaultState());
            if(step==10)roof(Blocks.AIR.getDefaultState());
            if(step==12){roof(Blocks.GLASS.getDefaultState());wall(Blocks.STONE.getDefaultState());}
            if(step==14){
                if(range){
                    var field=WorldLightManager.class.getDeclaredField("lightingGate");field.setAccessible(true);
                    var gate=(java.util.concurrent.locks.ReentrantReadWriteLock)field.get(manager());
                    gate.writeLock().lock();
                    try {
                        com.sumirelabs.pulsar.config.PulsarConfig.features.experimentalRangeRelight=true;
                        int count=manager().forceRelightChunks(List.of(
                                com.sumirelabs.pulsar.util.CoordinateUtils.getChunkKey(X>>4,Z>>4),
                                com.sumirelabs.pulsar.util.CoordinateUtils.getChunkKey((X+16)>>4,Z>>4)));
                        boolean superseded=manager().forceRelightChunk(X>>4,Z>>4);
                        report.addProperty("range_targets",count);report.addProperty("range_superseded",superseded);
                        report.addProperty("range_gate_held",gate.isWriteLockedByCurrentThread());
                        if(count!=2||!superseded)throw new IllegalStateException("Range test was not exercised");
                    } finally {com.sumirelabs.pulsar.config.PulsarConfig.features.experimentalRangeRelight=false;gate.writeLock().unlock();}
                } else for(int cx=X>>4;cx<=(X+W-1)>>4;cx++)manager().forceRelightChunk(cx,Z>>4);
            }
            if(step==16)wall(Blocks.AIR.getDefaultState());
            if(step==18)roof(Blocks.STAINED_GLASS.getStateFromMeta(EnumDyeColor.BLUE.getMetadata()));
            if(step==20){
                load(X+128,Z,48,48);
                report.addProperty("cache_valid_floating",((com.sumirelabs.pulsar.light.PulsarChunk)world.getChunk((X+144)>>4,(Z+16)>>4)).pulsar$hasSavedLightValid());
                if(!reload)canopy(Blocks.GLASS.getDefaultState());teleport(true);
            }
            if(reload&&step==22){finish(null);return;}
            if(step==22)canopy(Blocks.STONE.getDefaultState());
            if(step==24)canopy(Blocks.AIR.getDefaultState());
            if(step==26)canopy(Blocks.GLASS.getDefaultState());
            step++;
        }catch(Throwable t){t.printStackTrace();finish(t);}
    }
    private static int index(int x,int y,int z){return x+W*(z+D*y);}
    private int[][] reference(){
        int[][] levels=new int[4][W*D*H];
        for(int c=0;c<4;c++){
            ArrayDeque<Integer> queue=new ArrayDeque<>();
            for(int z=0;z<D;z++)for(int x=0;x<W;x++){int i=index(x,H-1,z);levels[c][i]=15;queue.add(i);}
            while(!queue.isEmpty()){
                int i=queue.remove(),x=i%W,z=(i/W)%D,y=i/(W*D),value=levels[c][i];
                for(var dir:net.minecraft.util.EnumFacing.VALUES){
                    int xx=x+dir.getXOffset(),yy=y+dir.getYOffset(),zz=z+dir.getZOffset();
                    if(xx<0||xx>=W||zz<0||zz>=D||yy<0||yy>=H)continue;
                    IBlockState dest=world.getBlockState(new BlockPos(X+xx,Y+yy,Z+zz));
                    int opacity=Math.min(15,dest.getLightOpacity()),filter=0;
                    if(c<3){
                        if(dest.getBlock()==Blocks.GLASS)filter=c==0?0:15;
                        if(dest.getBlock()==Blocks.STAINED_GLASS){var dye=EnumDyeColor.byMetadata(dest.getBlock().getMetaFromState(dest));filter=Math.round(15*(1-dye.getColorComponentValues()[c]));}
                    }
                    boolean direct=dir==net.minecraft.util.EnumFacing.DOWN&&value==15&&opacity==0&&filter==0
                            &&world.getBlockState(new BlockPos(X+x,Y+y,Z+z)).getLightOpacity()==0;
                    int target=direct?15:Math.max(0,value-Math.max(1,Math.max(opacity,filter)));
                    int j=index(xx,yy,zz);if(target>levels[c][j]){levels[c][j]=target;queue.add(j);}
                }
            }
        }
        return levels;
    }
    private int[][] floatingReference(int step){
        int[][] out=new int[4][16*16*96];
        int sky=step==23?0:15;
        for(int c=0;c<4;c++)Arrays.fill(out[c],c==3?sky:step==25?15:c==0?sky:0);
        return out;
    }
    private JsonObject compare(int[][] want,boolean floating){
        int x=floating?X+144:X,z=floating?Z+16:Z,y=floating?16:Y,w=floating?16:W,d=floating?16:D,h=floating?96:H;
        int rgbBad=0,canonicalBad=0,storedBad=0,blockBad=0;String first="";
        for(int yy=0;yy<h;yy++)for(int zz=0;zz<d;zz++)for(int xx=0;xx<w;xx++){
            int i=xx+w*(zz+d*yy);BlockPos p=new BlockPos(x+xx,y+yy,z+zz);
            RgbSnapshot s=((RgbChunk)world.getChunk(p)).pulsar$getRgbSkySnapshot();
            int rgb=RgbLight.pack(want[0][i],want[1][i],want[2][i]);
            if(s.get(p.getX(),p.getY(),p.getZ())!=rgb){rgbBad++;if(first.isEmpty())first=p+" actual="+Integer.toHexString(s.get(p.getX(),p.getY(),p.getZ()))+" expected="+Integer.toHexString(rgb);}
            if(s.canonical(p.getX(),p.getY(),p.getZ())!=want[3][i])canonicalBad++;
            if(world.getLightFor(EnumSkyBlock.SKY,p)!=want[3][i])storedBad++;
            if(world.getLightFor(EnumSkyBlock.BLOCK,p)!=0)blockBad++;
        }
        JsonObject out=new JsonObject();out.addProperty("name",name);out.addProperty("cells",w*d*h);
        out.addProperty("rgb_mismatches",rgbBad);out.addProperty("canonical_mismatches",canonicalBad);out.addProperty("stored_mismatches",storedBad);out.addProperty("block_mismatches",blockBad);out.addProperty("first",first);
        if(floating){int absent=0;for(var section:world.getChunk((X+144)>>4,(Z+16)>>4).getBlockStorageArray())if(section==null)absent++;out.addProperty("absent_physical_sections",absent);}
        System.out.println("SKY_AUDIT "+out);
        if(rgbBad+canonicalBad+storedBad+blockBad!=0)throw new IllegalStateException(out.toString());return out;
    }
    private CompletableFuture<JsonObject> clientCheck(int[][] want,boolean floating){
        var result=new CompletableFuture<JsonObject>();Minecraft mc=Minecraft.getMinecraft();
        String roof=world.getBlockState(new BlockPos(floating?X+152:X+18,126,floating?Z+24:Z+8)).toString();
        mc.addScheduledTask(()->{try{
            int x=floating?X+144:X,z=floating?Z+16:Z,y=floating?16:Y,w=floating?16:W,d=floating?16:D,h=floating?96:H;
            int rgbBad=0,canonicalBad=0,storedBad=0,blockBad=0;
            for(int yy=0;yy<h;yy++)for(int zz=0;zz<d;zz++)for(int xx=0;xx<w;xx++){
                int i=xx+w*(zz+d*yy);BlockPos p=new BlockPos(x+xx,y+yy,z+zz);
                Chunk chunk=mc.world.getChunkProvider().getLoadedChunk(p.getX()>>4,p.getZ()>>4);
                RgbSnapshot s=chunk==null?null:((RgbChunk)chunk).pulsar$getRgbSkySnapshot();
                if(s==null||s.get(p.getX(),p.getY(),p.getZ())!=RgbLight.pack(want[0][i],want[1][i],want[2][i]))rgbBad++;
                if(s==null||s.canonical(p.getX(),p.getY(),p.getZ())!=want[3][i])canonicalBad++;
                if(mc.world.getLightFor(EnumSkyBlock.SKY,p)!=want[3][i])storedBad++;
                if(mc.world.getLightFor(EnumSkyBlock.BLOCK,p)!=0)blockBad++;
            }
            boolean geometry=roof.equals(mc.world.getBlockState(new BlockPos(floating?X+152:X+18,126,floating?Z+24:Z+8)).toString());
            BlockPos pos=new BlockPos(X+18,Y+H-4,Z);int colored=0,vertices=0;
            if(!floating){
                BufferBuilder buffer=new BufferBuilder(65536);buffer.begin(7,DefaultVertexFormats.BLOCK);
                mc.getBlockRendererDispatcher().renderBlock(mc.world.getBlockState(pos),pos,mc.world,buffer);buffer.finishDrawing();vertices=buffer.getVertexCount();
                var bytes=buffer.getByteBuffer().duplicate().order(ByteOrder.nativeOrder());
                for(int i=0;i<vertices;i++){int color=bytes.getInt(i*DefaultVertexFormats.BLOCK.getSize()+DefaultVertexFormats.BLOCK.getColorOffset());if((color&255)!=(color>>8&255)||(color&255)!=(color>>16&255))colored++;}
            }
            mc.gameSettings.gammaSetting=1;mc.gameSettings.hideGUI=true;mc.player.rotationYaw=mc.player.prevRotationYaw=0;mc.player.rotationPitch=mc.player.prevRotationPitch=-15;
            photo=name;frames=0;
            JsonObject out=new JsonObject();out.addProperty("rgb_mismatches",rgbBad);out.addProperty("canonical_mismatches",canonicalBad);out.addProperty("stored_mismatches",storedBad);out.addProperty("block_mismatches",blockBad);out.addProperty("geometry_matches",geometry);out.addProperty("colored_vertices",colored);out.addProperty("vertices",vertices);out.addProperty("celeritas_hook",RgbClient.celeritasRendered);
            out.addProperty("valid",rgbBad+canonicalBad+storedBad+blockBad==0&&geometry&&(floating||vertices>0));result.complete(out);
        }catch(Throwable t){result.completeExceptionally(t);}});return result;
    }
    private void finish(Throwable error){
        step=-1;report.addProperty("valid",error==null);if(error!=null)report.addProperty("failure",error.toString());
        try{Path path=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/sky-audit.json");Files.createDirectories(path.getParent());Files.writeString(path,new GsonBuilder().setPrettyPrinting().create().toJson(report));}catch(Exception e){throw new RuntimeException(e);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("SKY_AUDIT_FINISHED "+report.get("valid"));
    }
}
