$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root\phase3\progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root\phase3-run.ps1" -Run $run -Artifact sky.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 $report=Get-Content "$root\runs\$run\results\$file" -Raw|ConvertFrom-Json
 if($report.valid -ne $true){throw "Audit failed $run"}
}
Audit 'sky-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'sky-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'sky-celeritas-range' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'sky-block-regression' 'rgbaudit'
Audit 'sky-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'sky-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)){
 foreach($mode in @('RGB','SCALAR')){
  $trials=@(
   @{v='before';i=$cohort;artifact='phase2.jar'},
   @{v='after';i=$cohort;artifact='sky.jar'},
   @{v='after';i=$cohort+1;artifact='sky.jar'},
   @{v='before';i=$cohort+1;artifact='phase2.jar'}
  )
  foreach($trial in $trials){
   $run="sky-perf-$($mode.ToLower())-$($trial.v)-$($trial.i)"
   [IO.File]::WriteAllText("$root\phase3\progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
   & "$root\phase3-run.ps1" -Run $run -Mode $mode -Command 'lightbench updates 2000 1000' -Artifact $trial.artifact
   if((Get-Content "$root\runs\$run\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
  }
 }
}
[IO.File]::WriteAllText("$root\phase3\progress.json",'{"stage":"complete"}')
