$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
if((Get-Content "$root\runs\sky-postdoc-final\results\sky-audit.json" -Raw|ConvertFrom-Json).valid -ne $true){throw 'Final vanilla validation failed'}
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root\phase3\opt-progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root\phase3-run.ps1" -Run $run -Artifact sky.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 if((Get-Content "$root\runs\$run\results\$file" -Raw|ConvertFrom-Json).valid -ne $true){throw "Audit failed $run"}
}
Audit 'sky-opt-celeritas' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'sky-opt-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'sky-opt-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'sky-opt-block' 'rgbaudit'
Audit 'sky-opt-scalar' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'sky-opt-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)){
 foreach($item in @(@{v='prototype';i=$cohort;artifact='sky-tested.jar'},@{v='optimized';i=$cohort;artifact='sky.jar'},@{v='optimized';i=$cohort+1;artifact='sky.jar'},@{v='prototype';i=$cohort+1;artifact='sky-tested.jar'})){
  $run="sky-opt-perf-$($item.v)-$($item.i)"
  [IO.File]::WriteAllText("$root\phase3\opt-progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
  & "$root\phase3-run.ps1" -Run $run -Mode RGB -Command 'lightbench updates 2000 1000' -Artifact $item.artifact
  if((Get-Content "$root\runs\$run\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
 }
}
[IO.File]::WriteAllText("$root\phase3\opt-progress.json",'{"stage":"complete"}')
