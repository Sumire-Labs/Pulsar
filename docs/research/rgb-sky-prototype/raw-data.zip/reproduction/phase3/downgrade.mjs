import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import {parseNbt,child,set,encodeTag} from './nbt-codec.mjs';
const world=path.resolve(process.argv[2]);
const allowed=path.resolve('E:/Github/Pulsar-RGB-20261016/templates/sky-migration');
if(world.toLowerCase()!==allowed.toLowerCase())throw Error('Only the disposable migration fixture is writable');
let changed=0;
const details=[];
function downgrade(node){
 if(node.type===10){
  for(const tag of node.value){
   if(tag.name==='PulsarLight'&&tag.type===10){
    set(tag,'rgbVersion',3,1);tag.value=tag.value.filter(n=>n.name!=='rgbSky');tag.dirty=true;changed++;
   }else downgrade(tag);
  }
 }else if(node.type===9)for(const item of node.value.items)downgrade(item);
}
for(const name of fs.readdirSync(path.join(world,'region')).filter(n=>n.endsWith('.mca'))){
 const target=path.join(world,'region',name),bytes=fs.readFileSync(target),header=Buffer.from(bytes.subarray(0,8192)),chunks=[];
 let sector=2;
 for(let i=0;i<1024;i++){
  const location=bytes.readUInt32BE(i*4),offset=location>>>8;
  if(!offset){header.writeUInt32BE(0,i*4);continue;}
  const length=bytes.readUInt32BE(offset*4096),type=bytes[offset*4096+4];
  if(type!==2&&type!==1)throw Error('Unexpected region compression');
  const compressed=bytes.subarray(offset*4096+5,offset*4096+4+length);
  const root=parseNbt(type===2?zlib.inflateSync(compressed):zlib.gunzipSync(compressed));
  const before=changed;downgrade(root);
  const payload=changed===before?compressed:zlib.deflateSync(encodeTag(root));
  const count=Math.ceil((payload.length+5)/4096);
  if(count>255)throw Error('Chunk too large');
  const record=Buffer.alloc(count*4096);record.writeUInt32BE(payload.length+1);record[4]=changed===before?type:2;payload.copy(record,5);
  header.writeUInt32BE((sector<<8)|count,i*4);sector+=count;chunks.push(record);
 }
 fs.writeFileSync(target,Buffer.concat([header,...chunks]));details.push({region:name,sectors:sector});
}
if(changed===0)throw Error('No cache was downgraded');
fs.writeFileSync('E:/Github/Pulsar-RGB-20261016/phase3/downgrade.json',JSON.stringify({changed,details,method:'v1 metadata; remove RGB sky; preserve color profile, block RGB and canonical light'},null,2));
console.log('Downgraded',changed,'chunk caches');
