from pathlib import Path
import json,hashlib,zipfile,statistics,subprocess,shutil
import xml.etree.ElementTree as E
study=Path("E:/Github/Pulsar-RGB-20261016");repo=Path("E:/Github/Pulsar")
out=repo/"docs/research/rgb-sky-prototype";out.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):(out/n).write_text(json.dumps(d,indent=2)+"\n",encoding="utf-8",newline="\n")
frozen=read(study/"phase3/source-freeze.json")
final=read(study/"phase3/final-source-freeze.json")
assert all(sha(repo/p)==v for p,v in final.items())
assert set(p for p in frozen if frozen[p]!=final[p])=={"src/main/java/com/sumirelabs/pulsar/config/PulsarConfig.java","src/main/java/com/sumirelabs/pulsar/rgb/RgbStorage.java"}
with zipfile.ZipFile(study/"artifacts/sky-tested.jar") as a,zipfile.ZipFile(study/"artifacts/sky.jar") as b:
 assert set(a.namelist())==set(b.namelist())
 diffs=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert set(diffs)=={"com/sumirelabs/pulsar/config/PulsarConfig.class","com/sumirelabs/pulsar/rgb/RgbStorage.class"},diffs
subprocess.run(["git","diff","--exit-code","HEAD","--","LICENSE.md","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarBlockEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarSkyEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/SkyLightColumnProcessor.java","src/main/java/com/sumirelabs/pulsar/light/engine/LightEngineCache.java"],cwd=repo,check=True)
core=["sky-postdoc-final","sky-opt-celeritas","sky-opt-cache-reload","sky-opt-cache-migration"]
validation={}
for run in core:
 d=read(study/"runs"/run/"results/sky-audit.json");assert d["valid"]
 artifact="sky.jar"
 assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts"/artifact)
 for c in d["cases"]:
  assert c["cells"]==24576
  assert c["rgb_mismatches"]==c["canonical_mismatches"]==c["stored_mismatches"]==c["block_mismatches"]==0
  if c["name"].startswith("floating") or c["name"]=="reload-floating":assert c["absent_physical_sections"]>=14
 for key,c in d.items():
  if key.startswith("client-"):
   assert c["valid"] and c["geometry_matches"]
   assert c["rgb_mismatches"]==c["canonical_mismatches"]==c["stored_mismatches"]==c["block_mismatches"]==0
 if "cache" not in run:
  assert len(d["cases"])==14
  assert d["range_targets"]==2 and d["range_superseded"] and d["range_gate_held"]
  for i in [4,6,8,14,16,18,20]:assert d["client-"+str(i)]["colored_vertices"]>0
 validation[run]=d
assert validation["sky-postdoc-final"]["split_roof_case"]
assert validation["sky-opt-celeritas"]["client-8"]["celeritas_hook"]
assert validation["sky-opt-cache-reload"]["cache_valid_main"] and validation["sky-opt-cache-reload"]["cache_valid_floating"]
assert not validation["sky-opt-cache-migration"]["cache_valid_main"]
for run in ["sky-opt-block","sky-opt-scalar"]:
 d=read(study/"runs"/run/"results/rgb-audit.json");assert d["valid"]
 if run=="sky-opt-scalar":assert d["scalar_has_no_rgb_chunk_fields"]
 else:
  assert len(d["cases"])==10
  for c in d["cases"]:assert c["mismatches"]==c["server_scalar_mismatches"]==c["server_snapshot_canonical_mismatches"]==0
  for k,c in d.items():
   if k.startswith("client-"):assert c["valid"] and c["mismatches"]==c["scalar_mismatches"]==c["snapshot_canonical_mismatches"]==0
 validation[run]=d
reg=study/"runs/sky-opt-cqr/results";d=read(reg/"issue-audit.json");assert d["valid"] and d["crystal_states"]==112
cases={c["name"]:c for c in d["cases"]}
for n in ["world-placement","direct-chunk-placement","full-relight"]:assert cases[n]["mismatches"]==0
assert cases["initial-send-race"]["context_pending"] and not cases["initial-send-race"]["sent_while_pending"]
assert cases["initial-send-after-drain"]["stored"]==10 and cases["initial-send-after-drain"]["retry_sent"]
assert not cases["existing-entry-watch-race"]["watching_while_pending"]
assert cases["existing-entry-watch-after-drain"]["watch_events_while_pending"]==0 and cases["existing-entry-watch-after-drain"]["watch_events_after_drain"]==1
assert cases["sealed-oak-room"]["lit_interior_cells"]==0
assert cases["native-cqr-generation"]["cells"]==68800
assert cases["native-cqr-vs-full-relight"]["sky_differences"]==cases["native-cqr-vs-full-relight"]["block_differences"]==0
corner=read(reg/"issue-client.json");assert corner["lit_interior_cells"]==corner["max_sky"]==0
assert all(v["sky"]==v["block"]==0 for m in corner["models"] for v in m["interior_face_lightmap"])
ship=read(reg/"issue-ship-client.json");assert all(v["sky_mismatches"]==v["block_mismatches"]==0 for v in ship)
validation["sky-opt-cqr"]={"server":d,"corner_client":corner,"ship_client":ship}
xml=[E.parse(p).getroot().attrib for p in (repo/"build/test-results/test").glob("TEST-*.xml")]
tests={k:sum(int(r.get(k,0)) for r in xml) for k in ["tests","failures","errors","skipped"]}
assert tests=={"tests":209,"failures":0,"errors":0,"skipped":0};validation["junit"]=tests
write("validation.json",validation)
runs=[];groups={}
for mode in ["rgb","scalar"]:
 for version in ["before","after"]:
  for i in [1,2,3,4]:
   run=f"sky-perf-{mode}-{version}-{i}"
   paths=list((study/"runs"/run/"results").glob("*updates*.json"));assert len(paths)==1
   d=read(paths[0])["benchmark"]
   assert d["preflight"]["initial_light_verified"] and d["preflight"]["post_measurement_volume_verified"]
   assert d["plan"]["warmup_pairs"]==2000 and d["plan"]["measured_pairs"]==1000
   artifact="phase2.jar" if version=="before" else "sky-tested.jar"
   assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts"/artifact)
   row={"run":run,"mode":mode,"version":version,"gc":d["measurement_gc"]}
   for p in d["phases"]:
    assert p["sample_count"]==1000 and p["all_samples_verified"] and all(s["light_verified"] for s in p["samples"])
    row[p["name"]]=p["completion_summary_nanos"]["average"]/1000
    groups.setdefault((mode,version,p["name"]),[]).append(row[p["name"]])
   runs.append(row)
timing={"unit":"microseconds","summary":"median of four independent JVM run means per mode/version","runs":runs,"groups":[{"mode":k[0],"version":k[1],"phase":k[2],"median":statistics.median(v),"minimum":min(v),"maximum":max(v)} for k,v in groups.items()]}
write("timing.json",timing)
opt_runs=[];opt_groups={}
for version in ["prototype","optimized"]:
 for i in [1,2,3,4]:
  run=f"sky-opt-perf-{version}-{i}"
  paths=list((study/"runs"/run/"results").glob("*updates*.json"));assert len(paths)==1
  d=read(paths[0])["benchmark"]
  assert d["preflight"]["initial_light_verified"] and d["preflight"]["post_measurement_volume_verified"]
  assert d["plan"]["warmup_pairs"]==2000 and d["plan"]["measured_pairs"]==1000
  artifact="sky-tested.jar" if version=="prototype" else "sky.jar"
  assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts"/artifact)
  row={"run":run,"mode":"rgb","version":version,"gc":d["measurement_gc"]}
  for p in d["phases"]:
   assert p["sample_count"]==1000 and p["all_samples_verified"] and all(s["light_verified"] for s in p["samples"])
   row[p["name"]]=p["completion_summary_nanos"]["average"]/1000
   opt_groups.setdefault((version,p["name"]),[]).append(row[p["name"]])
  opt_runs.append(row)
optimization={"unit":"microseconds","summary":"median of four independent JVM run means; counterbalanced RGB prototype versus optimized sky publication","runs":opt_runs,"groups":[{"version":k[0],"phase":k[1],"median":statistics.median(v),"minimum":min(v),"maximum":max(v)} for k,v in opt_groups.items()]}
write("optimization-timing.json",optimization)
protocol=read(repo/"docs/research/rgb-filters/protocol.json")
protocol["date"]="2026-10-17"
protocol["diagnostic_palette"]="SkyAudit registers GLASS filter (0,15,15); block regression alone registers pure RGB sources"
protocol["baseline_source"]="45039e4 (RGB block light and filters; scalar sky)"
protocol["order"]=[f"sky-perf-{mode}-{v}-{i}" for cohort in [1,3] for mode in ["rgb","scalar"] for v,i in [("before",cohort),("after",cohort),("after",cohort+1),("before",cohort+1)]]
protocol["optimization_order"]=[f"sky-opt-perf-{v}-{i}" for cohort in [1,3] for v,i in [("prototype",cohort),("optimized",cohort),("optimized",cohort+1),("prototype",cohort+1)]]
protocol["migration_fixture"]=read(study/"phase3/downgrade.json")
write("protocol.json",protocol)
write("artifacts.json",{"baseline_commit":"45039e4","license":"LGPL-3.0 unchanged","sha256":{n:sha(study/"artifacts"/n) for n in ["phase2.jar","sky-tested.jar","sky.jar","sky-audit.jar","sky-audit-tested.jar","filter-audit.jar","issue-audit-fresh.jar"]},"native_timing_source_sha256":frozen,"final_source_sha256":final,"optimized_jar_entry_changes":diffs,"optimization":"Resolve nearest non-null sky section once and reuse bottom-row extrusion; update English configuration description. All other jar entries are byte-identical. Final native checks and separate eight-run optimization cohort use the final jar."})
shutil.copy2(study/"runs/sky-postdoc-final/screenshots/sky-direct-red.png",out/"red-skylight.png")
with zipfile.ZipFile(out/"raw-data.zip","w",zipfile.ZIP_DEFLATED) as z:
 for run in core+["sky-opt-block","sky-opt-scalar","sky-opt-cqr"]+[r["run"] for r in runs+opt_runs]:
  for p in (study/"runs"/run/"results").glob("*.json"):z.write(p,f"runs/{run}/{p.name}")
  z.write(study/"runs"/run/"stage.json",f"runs/{run}/stage.json")
 for n in ["phase3-run.ps1","phase3-finish.ps1","phase3-opt-finish.ps1","world.cjs"]:z.write(study/n,"reproduction/"+n)
 for n in ["downgrade.mjs","nbt-codec.mjs"]:z.write(study/"phase3"/n,"reproduction/phase3/"+n)
 z.write(study/"tools/nbt-read.mjs","reproduction/tools/nbt-read.mjs")
 z.write(study/"helper/src/main/java/com/sumirelabs/skyaudit/SkyAudit.java","reproduction/SkyAudit.java")
 z.write(study/"phase3/SkyAudit-tested.java","reproduction/SkyAudit-tested.java")
 z.write(study/"helper/src/main/java/com/sumirelabs/rgbaudit/RgbAudit.java","reproduction/RgbAudit.java")
 for n in ["IssueAudit.java","IssueClientAudit.java","ShipAudit.java"]:z.write(study/"helper/src/main/java/com/sumirelabs/issueaudit"/n,"reproduction/"+n)
 z.write(Path(__file__),"reproduction/phase3/evidence.py")
assert zipfile.ZipFile(out/"raw-data.zip").testzip() is None
write("SHA256SUMS.json",{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!="SHA256SUMS.json"})
print(json.dumps(timing,indent=2))
