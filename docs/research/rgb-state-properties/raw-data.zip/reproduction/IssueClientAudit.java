package com.sumirelabs.issueaudit;

import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ScreenShotHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.ChunkCache;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.nio.*;
import java.nio.file.*;

public final class IssueClientAudit {
    private int ticks;private boolean done;
    private int raceTicks,raceSeen;private final JsonArray raceSamples=new JsonArray();
    private int shipTicks,shipSeen;private final JsonArray shipSamples=new JsonArray();
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;
        Minecraft client=Minecraft.getMinecraft();
        if(IssueAudit.racePhase>raceSeen&&client.world!=null&&++raceTicks>=20){
            raceSeen=IssueAudit.racePhase;raceTicks=0;BlockPos p=raceSeen<=2?IssueAudit.RACE_POS:IssueAudit.WATCH_POS;JsonObject v=new JsonObject();
            v.addProperty("phase",raceSeen);v.addProperty("state",client.world.getBlockState(p).toString());v.addProperty("stored",client.world.getLightFor(EnumSkyBlock.BLOCK,p));raceSamples.add(v);
            try{Files.createDirectories(client.gameDir.toPath().resolve("saves/Bench Updates/lightbench-results"));Files.writeString(client.gameDir.toPath().resolve("saves/Bench Updates/lightbench-results/issue-race-client.json"),new GsonBuilder().setPrettyPrinting().create().toJson(raceSamples));}catch(Exception x){throw new RuntimeException(x);}
        }
        if(ShipAudit.clientPhase>shipSeen&&client.world!=null&&++shipTicks>=40){
            shipSeen=ShipAudit.clientPhase;shipTicks=0;int ds=0,db=0,i=0;JsonArray examples=new JsonArray();
            for(int x=0;x<ShipAudit.size.getX();x++)for(int y=0;y<ShipAudit.size.getY();y++)for(int z=0;z<ShipAudit.size.getZ();z++,i++){
                BlockPos p=ShipAudit.origin.add(x,y,z);
                int actualSky=client.world.getLightFor(EnumSkyBlock.SKY,p);
                if(actualSky!=ShipAudit.clientSky[i]){ds++;if(examples.size()<32){JsonObject ex=new JsonObject();ex.addProperty("pos",p.toString());ex.addProperty("expected_sky",ShipAudit.clientSky[i]);ex.addProperty("client_sky",actualSky);ex.addProperty("state",client.world.getBlockState(p).toString());ex.addProperty("storage_absent",client.world.getChunk(p).getBlockStorageArray()[p.getY()>>4]==null);examples.add(ex);}}
                if(client.world.getLightFor(EnumSkyBlock.BLOCK,p)!=ShipAudit.clientBlock[i])db++;
            }
            JsonObject v=new JsonObject();v.addProperty("phase",shipSeen);v.addProperty("sky_mismatches",ds);v.addProperty("block_mismatches",db);v.add("examples",examples);v.addProperty("client_updates_pending",((com.sumirelabs.pulsar.world.PulsarWorld)client.world).pulsar$getLightManager().hasUpdates());shipSamples.add(v);
            try{Files.createDirectories(client.gameDir.toPath().resolve("saves/Bench Updates/lightbench-results"));Files.writeString(client.gameDir.toPath().resolve("saves/Bench Updates/lightbench-results/issue-ship-client.json"),new GsonBuilder().setPrettyPrinting().create().toJson(shipSamples));}catch(Exception x){throw new RuntimeException(x);}
            if(shipSeen==1)ShipAudit.clientBeforeDone=true;else ShipAudit.clientAfterDone=true;
        }
        if(done||!IssueAudit.cornerReady||++ticks<30)return;
        Minecraft mc=Minecraft.getMinecraft();if(mc.world==null||mc.player==null)return;
        BlockPos wall=new BlockPos(20082,96,20006);
        var wallState=mc.world.getBlockState(wall);
        var manager=((com.sumirelabs.pulsar.world.PulsarWorld)mc.world).pulsar$getLightManager();
        if(ticks<400&&(wallState.getBlock()!=net.minecraft.init.Blocks.LOG||(manager!=null&&manager.hasUpdates())))return;
        done=true;
        System.out.println("ISSUE_CORNER_CLIENT state="+wallState+" ticks="+ticks+" player="+mc.player.getPosition());
        JsonObject report=new JsonObject();
        try{
            int nonzero=0,max=0;
            for(int x=20083;x<=20089;x++)for(int z=20003;z<=20009;z++)for(int y=93;y<=99;y++){
                int v=mc.world.getLightFor(EnumSkyBlock.SKY,new BlockPos(x,y,z));if(v!=0)nonzero++;max=Math.max(max,v);
            }
            report.addProperty("lit_interior_cells",nonzero);report.addProperty("max_sky",max);
            JsonArray models=new JsonArray();
            for(int x=20083;x<=20089;x++){
                BlockPos p=new BlockPos(x,96,20002);var state=mc.world.getBlockState(p);
                ChunkCache cache=new ChunkCache(mc.world,p.add(-2,-2,-2),p.add(2,2,2),0);
                BufferBuilder buffer=new BufferBuilder(65536);buffer.begin(7,DefaultVertexFormats.BLOCK);
                var disp=mc.getBlockRendererDispatcher();disp.getBlockModelRenderer().renderModel(cache,disp.getModelForState(state),state,p,buffer,true,0L);
                buffer.finishDrawing();ByteBuffer bytes=buffer.getByteBuffer().duplicate().order(ByteOrder.nativeOrder());
                JsonArray light=new JsonArray();int size=DefaultVertexFormats.BLOCK.getSize(),offset=DefaultVertexFormats.BLOCK.getUvOffsetById(1);
                for(int i=0;i<buffer.getVertexCount();i++){
                    int start=i*size;if(Math.abs(bytes.getFloat(start+8)-(p.getZ()+1))>0.001)continue;
                    JsonObject v=new JsonObject();v.addProperty("block",Short.toUnsignedInt(bytes.getShort(start+offset)));v.addProperty("sky",Short.toUnsignedInt(bytes.getShort(start+offset+2)));light.add(v);
                }
                JsonObject m=new JsonObject();m.addProperty("x",x);m.add("interior_face_lightmap",light);models.add(m);
            }
            report.add("models",models);report.addProperty("valid",true);
            ScreenShotHelper.saveScreenshot(mc.gameDir,"issue-20-corner.png",mc.displayWidth,mc.displayHeight,mc.getFramebuffer());
        }catch(Throwable t){t.printStackTrace();report.addProperty("failure",t.toString());report.addProperty("valid",false);}
        try{Path p=mc.gameDir.toPath().resolve("saves/Bench Updates/lightbench-results/issue-client.json");Files.createDirectories(p.getParent());Files.writeString(p,new GsonBuilder().setPrettyPrinting().create().toJson(report));}catch(Exception t){throw new RuntimeException(t);}
    }
}
