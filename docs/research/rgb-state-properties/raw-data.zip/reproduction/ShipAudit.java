package com.sumirelabs.issueaudit;

import com.google.gson.*;
import net.minecraft.world.*;
import net.minecraft.util.math.BlockPos;
import java.nio.file.*;
import java.lang.reflect.*;

/** Invokes the installed CQR generator; no CQR implementation is copied. */
final class ShipAudit {
    static final BlockPos origin=new BlockPos(20016,120,20016);
    static BlockPos size;
    private static byte[] sky,block;
    static volatile int clientPhase;
    static volatile boolean clientBeforeDone,clientAfterDone;
    static byte[] clientSky,clientBlock;
    static void loaded(){size=new BlockPos(32,43,50);}
    static void generate(WorldServer world)throws Exception{
        for(int x=20010;x<=20055;x++)for(int z=20010;z<=20075;z++)world.setBlockState(new BlockPos(x,254,z),net.minecraft.init.Blocks.AIR.getDefaultState(),18);
        var manager=((com.sumirelabs.pulsar.world.PulsarWorld)world).pulsar$getLightManager();manager.publishContextualLight();
        for(int cx=1250;cx<=1254;cx++)for(int cz=1250;cz<=1255;cz++)manager.awaitPendingWork(cx,cz);
        Class<?> c=Class.forName("team.cqr.cqrepoured.world.structure.generation.structurefile.CQStructure");
        Object structure=c.getMethod("createFromFile",java.io.File.class).invoke(null,Path.of("E:/Github/Pulsar-Issues-20261015/Galleon.nbt").toFile());
        size=(BlockPos)c.getMethod("getSize").invoke(structure);
        Class<?> builder=Class.forName("team.cqr.cqrepoured.world.structure.generation.generation.GeneratableDungeon$Builder");
        Class<?> offset=Class.forName("team.cqr.cqrepoured.world.structure.generation.structurefile.Offset");
        Object b=builder.getConstructor(World.class,BlockPos.class,String.class,String.class).newInstance(world,origin,"Issue20-Galleon","DEFAULT");
        c.getMethod("addAll",builder,BlockPos.class,offset).invoke(structure,b,origin,Enum.valueOf((Class)offset,"NORTH_EAST"));
        Object dungeon=builder.getMethod("build",World.class).invoke(b,world);
        dungeon.getClass().getMethod("generate",World.class).invoke(dungeon,world);
        System.out.println("ISSUE_AUDIT_SHIP_GENERATED "+size);
    }
    private static byte[] snapshot(World world,EnumSkyBlock channel){
        byte[] values=new byte[size.getX()*size.getY()*size.getZ()];int i=0;
        for(int x=0;x<size.getX();x++)for(int y=0;y<size.getY();y++)for(int z=0;z<size.getZ();z++)values[i++]=(byte)world.getLightFor(channel,origin.add(x,y,z));
        return values;
    }
    static JsonObject before(World world){
        sky=snapshot(world,EnumSkyBlock.SKY);block=snapshot(world,EnumSkyBlock.BLOCK);
        clientSky=sky;clientBlock=block;clientPhase=1;
        JsonObject o=new JsonObject();o.addProperty("name","native-cqr-generation");o.addProperty("cells",sky.length);return o;
    }
    static JsonObject after(World world){
        byte[] s=snapshot(world,EnumSkyBlock.SKY),b=snapshot(world,EnumSkyBlock.BLOCK);int ds=0,db=0;JsonArray examples=new JsonArray();int i=0;
        for(int x=0;x<size.getX();x++)for(int y=0;y<size.getY();y++)for(int z=0;z<size.getZ();z++,i++){
            if(s[i]!=sky[i])ds++;if(b[i]!=block[i])db++;
            if((s[i]!=sky[i]||b[i]!=block[i])&&examples.size()<32){
                BlockPos p=origin.add(x,y,z);JsonObject e=new JsonObject();e.addProperty("position",p.toString());e.addProperty("state",world.getBlockState(p).toString());e.addProperty("sky_before",sky[i]);e.addProperty("sky_relit",s[i]);e.addProperty("block_before",block[i]);e.addProperty("block_relit",b[i]);examples.add(e);
            }
        }
        clientSky=s;clientBlock=b;clientPhase=2;
        JsonObject o=new JsonObject();o.addProperty("name","native-cqr-vs-full-relight");o.addProperty("sky_differences",ds);o.addProperty("block_differences",db);o.add("examples",examples);System.out.println("ISSUE_AUDIT_SHIP_DIFF sky="+ds+" block="+db);return o;
    }
    static void saveLegacy(WorldServer world,net.minecraft.server.MinecraftServer server)throws Exception{
        server.saveAllWorlds(false);net.minecraft.world.storage.ThreadedFileIOBase.getThreadedIOInstance().waitForFinish();
        Path out=Path.of("E:/Github/Pulsar-Issues-20261015/templates/normal"),src=world.getSaveHandler().getWorldDirectory().toPath();
        if(Files.exists(out))throw new IllegalStateException("Legacy fixture already exists");
        try(var paths=Files.walk(src)){for(Path p:paths.toList()){Path target=out.resolve(src.relativize(p));if(Files.isDirectory(p))Files.createDirectories(target);else Files.copy(p,target);}}
        System.out.println("ISSUE_AUDIT_LEGACY_SAVED");
    }
}
