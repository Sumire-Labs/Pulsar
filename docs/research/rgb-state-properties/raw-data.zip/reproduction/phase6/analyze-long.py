from pathlib import Path
import json,statistics,math,itertools,random
r=Path('E:/Github/Pulsar-RGB-20261016/phase6')
rows=json.loads((r/'long-results.json').read_text());lookup={(x['version'],x['pair']):x for x in rows}
assert len(rows)==8
result={}
for phase in ['sky_remove','sky_place','block_place','block_remove']:
 a=[lookup['before',i]['phases'][phase]['completion']['average'] for i in range(1,5)]
 b=[lookup['after',i]['phases'][phase]['completion']['average'] for i in range(1,5)]
 logs=[math.log(y/x) for x,y in zip(a,b)];mean=statistics.mean(logs);se=statistics.stdev(logs)/math.sqrt(4)
 def pct(x):return (math.exp(x)-1)*100
 observed=abs(mean)
 p=sum(abs(statistics.mean(x*s for x,s in zip(logs,signs)))>=observed-1e-15 for signs in itertools.product([-1,1],repeat=4))/16
 rng=random.Random(20261017);boot=sorted(statistics.mean(rng.choices(logs,k=4)) for _ in range(20000))
 result[phase]={'before_us':{'median_of_means':statistics.median(a)/1000,'range':[min(a)/1000,max(a)/1000]},'after_us':{'median_of_means':statistics.median(b)/1000,'range':[min(b)/1000,max(b)/1000]},'paired_geometric_change_percent':pct(mean),'paired_log_t_95_percent':[pct(mean-3.182446*se),pct(mean+3.182446*se)],'paired_bootstrap_95_percent':[pct(boot[499]),pct(boot[19499])],'exact_paired_sign_flip_p':p,'paired_changes_percent':[pct(x) for x in logs]}
for label,key in [('worker_cpu','worker_cpu_ns')]:
 a=[lookup['before',i][key] for i in range(1,5)];b=[lookup['after',i][key] for i in range(1,5)]
 result[label]={'before_median_ms':statistics.median(a)/1e6,'after_median_ms':statistics.median(b)/1e6,'paired_changes_percent':[(y/x-1)*100 for x,y in zip(a,b)]}
(r/'long-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
