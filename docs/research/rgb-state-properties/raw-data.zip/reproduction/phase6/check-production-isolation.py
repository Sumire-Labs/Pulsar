from pathlib import Path
import zipfile,json,hashlib
r=Path('E:/Github/Pulsar-RGB-20261016')
with zipfile.ZipFile(r/'artifacts/trim.jar') as a,zipfile.ZipFile(r/'artifacts/state.jar') as b:
 names=[n for n in a.namelist() if n.endswith('.class') and (n.startswith('com/sumirelabs/pulsar/light/') or n.startswith('com/sumirelabs/pulsar/mixin/') or n.startswith('com/sumirelabs/pulsar/core/')) and not n.rsplit('/',1)[-1].startswith('Rgb')]
 for n in names: assert a.read(n)==b.read(n),n
 d={'baseline_commit':'9672c0d','all_scalar_light_scheduler_contextual_and_mixin_classes_byte_identical':True,'classes':{n:hashlib.sha256(a.read(n)).hexdigest() for n in sorted(names)}}
 (r/'phase6/production-isolation.json').write_text(json.dumps(d,indent=2)+'\n')
 print('Unchanged SCALAR classes in new candidate:',len(names))
