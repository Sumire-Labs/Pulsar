from pathlib import Path
import json,statistics,hashlib,zipfile
r=Path('E:/Github/Pulsar-RGB-20261016');out=r/'phase6'
rows=[]
for p in sorted((r/'runs').glob('state-long-rgb-*/results/*updates*.json')):
 d=json.loads(p.read_text())['benchmark'];run=p.parent.parent.name
 assert d['preflight']['initial_light_verified'] and d['preflight']['post_measurement_volume_verified']
 assert d['plan']['warmup_pairs']==10000 and d['plan']['measured_pairs']==5000
 stage=json.loads((p.parent.parent/'stage.json').read_text())
 assert stage['mode']=='RGB'
 assert stage['sha256'].lower()==hashlib.sha256((r/'artifacts'/stage['artifact']).read_bytes()).hexdigest()
 row={'run':run,'version':run.split('-')[-2],'pair':int(run.split('-')[-1]),'gc':d['measurement_gc'],'worker_cpu_ns':d['pulsar_worker_cpu_nanos'],'phases':{}}
 for ph in d['phases']:
  assert ph['sample_count']==5000 and ph['all_samples_verified'] and all(s['light_verified'] for s in ph['samples'])
  row['phases'][ph['name']]={k:ph[k+'_summary_nanos'] for k in ['completion','submission','barrier']}
  row['phases'][ph['name']]['half_means']=[statistics.mean(s['completion_nanos'] for s in ph['samples'][a:b]) for a,b in [(0,2500),(2500,5000)]]
 rows.append(row)
 print(run, ' '.join(f"{ph['name']}={ph['completion_summary_nanos']['average']/1000:.1f}" for ph in d['phases']), 'worker_ms='+str(round(d['pulsar_worker_cpu_nanos']/1e6,1)), 'gc='+str(d['measurement_gc']['collection_count_delta']))
(out/'long-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Validated completed JVMs:',len(rows))
