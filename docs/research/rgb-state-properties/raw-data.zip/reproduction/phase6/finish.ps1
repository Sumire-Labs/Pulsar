$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root/phase6/progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root/phase6/run.ps1" -Run $run -Artifact state.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 if((Get-Content "$root/runs/$run/results/$file" -Raw|ConvertFrom-Json).valid -ne $true){throw "Audit failed $run"}
}
Audit 'state-vanilla-stable' 'skyaudit range'
Audit 'state-celeritas-stable' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'state-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'state-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'state-block-regression' 'rgbaudit'
Audit 'state-block-celeritas' 'rgbaudit' 'flat' 'RGB' -Fast
Audit 'state-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'state-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)) {
 foreach($mode in @('rgb','filtered')) {
  foreach($item in @(@{v='before';i=$cohort;artifact='trim.jar'},@{v='after';i=$cohort;artifact='state.jar'},@{v='after';i=$cohort+1;artifact='state.jar'},@{v='before';i=$cohort+1;artifact='trim.jar'})) {
   $run="state-perf-$mode-$($item.v)-$($item.i)"
   [IO.File]::WriteAllText("$root/phase6/progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
   $command=if($mode -eq 'filtered'){'function perfbench:filteredupdates'}else{'lightbench updates 2000 1000'}
   & "$root/phase6/run.ps1" -Run $run -Mode RGB -Command $command -Artifact $item.artifact
   if((Get-Content "$root/runs/$run/status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
  }
 }
}
[IO.File]::WriteAllText("$root/phase6/progress.json",'{"stage":"complete"}')
