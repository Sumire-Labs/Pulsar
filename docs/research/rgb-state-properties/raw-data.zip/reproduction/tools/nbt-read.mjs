import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

// Preserve untouched binary payloads (including modified-UTF strings) verbatim.
// Changed strings are restricted to the ASCII benchmark names/rules below.
export function parseNbt(bytes) {
  let offset = 0;
  const need = n => { if (n < 0 || offset + n > bytes.length) throw new Error('Truncated/invalid NBT'); };
  const u8 = () => { need(1); return bytes[offset++]; };
  const i32 = () => { need(4); const n = bytes.readInt32BE(offset); offset += 4; return n; };
  const string = () => { need(2); const n = bytes.readUInt16BE(offset); offset += 2; need(n); const b = bytes.subarray(offset, offset += n); return b.toString('utf8'); };
  function payload(type) {
    const start = offset;
    let value;
    if (type === 1) { need(1); value = bytes.readInt8(offset++); }
    else if (type === 2) { need(2); value = bytes.readInt16BE(offset); offset += 2; }
    else if (type === 3) value = i32();
    else if (type === 4) { need(8); value = bytes.readBigInt64BE(offset); offset += 8; }
    else if (type === 5) { need(4); value = bytes.readFloatBE(offset); offset += 4; }
    else if (type === 6) { need(8); value = bytes.readDoubleBE(offset); offset += 8; }
    else if (type === 7 || type === 11 || type === 12) {
      const count = i32(), width = type === 7 ? 1 : type === 11 ? 4 : 8;
      if (count < 0) throw new Error('Negative array length');
      need(count * width); value = bytes.subarray(offset, offset += count * width);
    } else if (type === 8) value = string();
    else if (type === 9) {
      const elementType = u8(), count = i32();
      if (count < 0 || (count > 0 && elementType === 0)) throw new Error('Invalid list');
      value = { elementType, items: Array.from({ length: count }, () => payload(elementType)) };
    } else if (type === 10) {
      value = [];
      while (true) { need(1); if (bytes[offset] === 0) { offset++; break; } value.push(named()); }
    } else throw new Error(`Unsupported NBT type ${type}`);
    return { type, value, rawPayload: bytes.subarray(start, offset), dirty: false };
  }
  function named() {
    const start = offset, type = u8();
    if (!type) throw new Error('Unexpected TAG_End');
    const name = string(), node = payload(type);
    node.name = name; node.rawTag = bytes.subarray(start, offset);
    return node;
  }
  const root = named();
  if (offset !== bytes.length || root.type !== 10) throw new Error('Unexpected root/trailing NBT');
  return root;
}
const dirty = n => n.dirty || (n.type === 10 && n.value.some(dirty)) || (n.type === 9 && n.value.items.some(dirty));
function utf(s) {
  if (!/^[\x20-\x7e]*$/.test(s)) throw new Error('Changed NBT strings must be ASCII');
  const b = Buffer.from(s), len = Buffer.alloc(2); len.writeUInt16BE(b.length); return Buffer.concat([len, b]);
}
function encodePayload(n) {
  if (!dirty(n)) return n.rawPayload;
  if (n.type === 10) return Buffer.concat([...n.value.map(encodeTag), Buffer.from([0])]);
  if (n.type === 8) return utf(n.value);
  if (n.type === 1) { const b = Buffer.alloc(1); b.writeInt8(n.value); return b; }
  throw new Error(`Modification of type ${n.type} is not supported`);
}
function encodeTag(n) {
  return !dirty(n) ? n.rawTag : Buffer.concat([Buffer.from([n.type]), utf(n.name), encodePayload(n)]);
}
export function child(n, name) { return n.value.find(x => x.name === name); }
function set(n, name, type, value) {
  let tag = child(n, name);
  if (tag && tag.type !== type) throw new Error(`Unexpected type for ${name}`);
  if (!tag) { tag = { name, type, value, dirty: true }; n.value.push(tag); }
  else { tag.value = value; tag.dirty = true; }
}
function inspect(root) {
  const data = child(root, 'Data');
  if (!data || data.type !== 10) throw new Error('No Data compound');
  const get = n => { const v = child(data, n)?.value; return typeof v === 'bigint' ? v.toString() : v; };
  const rules = child(data, 'GameRules');
  return { LevelName: get('LevelName'), RandomSeed: get('RandomSeed'), generatorName: get('generatorName'),
    generatorVersion: get('generatorVersion'), generatorOptions: get('generatorOptions'), MapFeatures: get('MapFeatures'),
    GameType: get('GameType'), Difficulty: get('Difficulty'), Time: get('Time'), DayTime: get('DayTime'),
    GameRules: rules ? Object.fromEntries(rules.value.map(n => [n.name, n.value])) : null };
}
export { encodeTag, set };
