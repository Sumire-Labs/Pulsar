package com.sumirelabs.rgbaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.api.BlockLightColors;
import com.sumirelabs.pulsar.light.WorldLightManager;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ScreenShotHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.util.*;
import java.nio.file.*;
import java.nio.ByteOrder;
import java.util.concurrent.CompletableFuture;

/** Disposable integrated-game audit; never packaged in the production mod. */
@Mod(modid="rgbaudit",name="RGB Audit",version="1",dependencies="required-after:pulsar")
public final class RgbAudit {
    private static final int X=20000,Z=20032,Y=79,W=32,D=16,H=10;
    private static final BlockPos RED=new BlockPos(X+14,Y+3,Z+8), GREEN=new BlockPos(X+18,Y+3,Z+8), BLUE=new BlockPos(X+16,Y+3,Z+11);
    private static final JsonObject REPORT=new JsonObject();
    private static final JsonArray CASES=new JsonArray();
    private WorldServer world;
    private int phase=-1, ticks, waited;
    private CompletableFuture<JsonObject> client;
    private boolean reload, scalarOnly;
    private static volatile String photo;
    private static int photoFrames;
    @SubscribeEvent public void renderPhoto(TickEvent.RenderTickEvent e) {
        if(e.phase!=TickEvent.Phase.END||photo==null||++photoFrames<30)return;
        Minecraft mc=Minecraft.getMinecraft();
        ScreenShotHelper.saveScreenshot(mc.gameDir,"rgb-"+photo+".png",mc.displayWidth,mc.displayHeight,mc.getFramebuffer());photo=null;
    }
    private int[][] lastExpected;
    private String lastName;
    private boolean resent;
    private int worldTicks;
    @SubscribeEvent public void worldTick(TickEvent.WorldTickEvent e) { if(e.world==world&&e.phase==TickEvent.Phase.END)worldTicks++; }
    @Mod.EventHandler public void init(FMLInitializationEvent e) {
        BlockLightColors.register(Blocks.GLOWSTONE.getDefaultState(),15,0,0);
        BlockLightColors.register(Blocks.LIT_PUMPKIN.getDefaultState(),0,15,0);
        BlockLightColors.register(Blocks.SEA_LANTERN.getDefaultState(),0,0,15);
        MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "rgbaudit";}
            public String getUsage(ICommandSender s){return "/rgbaudit [reload]";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer s,ICommandSender sender,String[] args){
                world=(WorldServer)sender.getEntityWorld();scalarOnly=args.length>0&&args[0].equals("scalar");reload=args.length>0&&!scalarOnly;phase=0;ticks=0;
                REPORT.add("cases",CASES);REPORT.addProperty("valid",false);
                System.out.println("RGB_AUDIT_STARTED");
            }
        });
    }
    @SubscribeEvent public void tick(TickEvent.ServerTickEvent e) {
        if(e.phase!=TickEvent.Phase.END||phase<0||++ticks<20)return;
        ticks=0;
        try {
            if(phase==0 && scalarOnly) {
                Chunk chunk=world.getChunk(world.playerEntities.get(0).getPosition());
                boolean noPalette=!(new net.minecraft.world.chunk.BlockStateContainer() instanceof com.sumirelabs.pulsar.rgb.RgbFilterPalette);
                REPORT.addProperty("scalar_has_no_rgb_palette_fields",noPalette);
                boolean valid=noPalette && !com.sumirelabs.pulsar.core.RgbMixinSelection.rgbEnabled() && !(chunk instanceof RgbChunk);
                REPORT.addProperty("scalar_has_no_rgb_chunk_fields",valid);
                if(!valid)throw new IllegalStateException("RGB mixins leaked into SCALAR");
                finish(null);return;
            }
            if(phase==0){ snapshotAllocation(); prepare();phase++;return; }
            if(phase%2==1){
                if(!ready()){if(++waited>90)throw new IllegalStateException("lighting did not drain");return;}waited=0;
                if(!resent) {
                    for(int cx=X>>4;cx<=(X+W-1)>>4;cx++) {
                        var entry=world.getPlayerChunkMap().getEntry(cx,Z>>4);
                        System.out.println("RGB_ENTRY "+cx+" sent="+(entry!=null&&entry.isSentToPlayers())+" watching="+(entry==null?-1:entry.getWatchingPlayers().size()));
                        if(entry!=null)for(var player:world.playerEntities)entry.sendToPlayer((net.minecraft.entity.player.EntityPlayerMP)player);
                    }
                    resent=true;return;
                }
                String name=reload?"reload":switch(phase){case 1->"mixed";case 3->"remove-red";case 5->"opaque-barrier";case 7->"same-brightness-color-swap";case 9->"full-relight";case 11->"red-glass";case 13->"blue-glass-swap";case 15->"red-glass-pane";case 17->"filtered-full-relight";default->"remove-glass";};
                int[][] expected=reference();
                JsonObject check=compare(name,expected);CASES.add(check);
                lastExpected=expected;lastName=name;client=clientCheck(expected,name);phase++;return;
            }
            if(!client.isDone())return;
            JsonObject c=client.join();REPORT.add("client-"+phase,c);
            if(!c.get("valid").getAsBoolean()) {
                System.out.println("RGB_CLIENT_WAIT "+c);
                if(++waited>20)throw new IllegalStateException("client check failed "+c);
                client=clientCheck(lastExpected,lastName);return;
            }
            waited=0;
            if(reload||phase==20){finish(null);return;}
            if(phase==2) world.setBlockState(RED,Blocks.AIR.getDefaultState(),3);
            if(phase==4) for(int z=Z+1;z<Z+D-1;z++)for(int y=Y+1;y<Y+H-1;y++)world.setBlockState(new BlockPos(X+16,y,z),Blocks.STONE.getDefaultState(),3);
            if(phase==6) world.setBlockState(GREEN,Blocks.SEA_LANTERN.getDefaultState(),3);
            if(phase==8) for(int cx=X>>4;cx<=(X+W-1)>>4;cx++)manager().forceRelightChunk(cx,Z>>4);
            if(phase==10||phase==12||phase==14||phase==18) for(int z=Z+1;z<Z+D-1;z++)for(int y=Y+1;y<Y+H-1;y++)world.setBlockState(new BlockPos(X+16,y,z),phase==18?Blocks.AIR.getDefaultState():(phase==14?Blocks.STAINED_GLASS_PANE:Blocks.STAINED_GLASS).getStateFromMeta((phase==10||phase==14?net.minecraft.item.EnumDyeColor.RED:net.minecraft.item.EnumDyeColor.BLUE).getMetadata()),3);
            if(phase==16) for(int cx=X>>4;cx<=(X+W-1)>>4;cx++)manager().forceRelightChunk(cx,Z>>4);
            phase++;
        } catch(Throwable t){t.printStackTrace();finish(t);}
    }
    private static volatile RgbSnapshot sink;
    private void snapshotAllocation() {
        RgbStorage storage=new RgbStorage(-1,18);
        com.sumirelabs.pulsar.light.SWMRNibbleArray[] canonical=new com.sumirelabs.pulsar.light.SWMRNibbleArray[18];
        for(int s=0;s<18;s++){
            byte[] bytes=new byte[2048];Arrays.fill(bytes,(byte)0x76);
            canonical[s]=new com.sumirelabs.pulsar.light.SWMRNibbleArray(bytes.clone());
            for(int c=0;c<3;c++)storage.channels[c][s]=new com.sumirelabs.pulsar.light.SWMRNibbleArray(bytes.clone());
        }
        RgbSnapshot previous=storage.snapshot(1,canonical);
        var bean=(com.sun.management.ThreadMXBean)java.lang.management.ManagementFactory.getThreadMXBean();
        long thread=Thread.currentThread().threadId();
        JsonObject result=new JsonObject();
        for(boolean reuse:new boolean[]{false,true}){
            for(int i=0;i<2000;i++) sink=reuse?storage.snapshot(i+2,canonical,previous):storage.snapshot(i+2,canonical);
            long before=bean.getThreadAllocatedBytes(thread),start=System.nanoTime();
            for(int i=0;i<5000;i++) sink=reuse?storage.snapshot(i+2,canonical,previous):storage.snapshot(i+2,canonical);
            result.addProperty(reuse?"reuse_bytes_per_snapshot":"copy_bytes_per_snapshot",(bean.getThreadAllocatedBytes(thread)-before)/5000.0);
            result.addProperty(reuse?"reuse_ns_per_snapshot":"copy_ns_per_snapshot",(System.nanoTime()-start)/5000.0);
        }
        REPORT.add("snapshot_allocation",result);
    }
    private WorldLightManager manager(){return ((PulsarWorld)world).pulsar$getLightManager();}
    private void prepare() {
        for(int cx=(X>>4)-2;cx<=(X>>4)+3;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+2;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
        REPORT.addProperty("cached_light_valid_0",((com.sumirelabs.pulsar.light.PulsarChunk)world.getChunk(X>>4,Z>>4)).pulsar$hasSavedLightValid());
        if(!reload){
            for(int x=X;x<X+W;x++)for(int y=Y;y<Y+H;y++)for(int z=Z;z<Z+D;z++){
                boolean wall=x==X||x==X+W-1||y==Y||y==Y+H-1||z==Z||z==Z+D-1;
                world.setBlockState(new BlockPos(x,y,z),wall?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
            }
            world.setBlockState(RED,Blocks.GLOWSTONE.getDefaultState(),3);
            world.setBlockState(GREEN,Blocks.LIT_PUMPKIN.getDefaultState(),3);
            world.setBlockState(BLUE,Blocks.SEA_LANTERN.getDefaultState(),3);
        }
        if(!reload)for(int cx=X>>4;cx<=(X+W-1)>>4;cx++)manager().forceRelightChunk(cx,Z>>4);
        for(var player:world.playerEntities){player.setPositionAndUpdate(X+16.5,Y+5,Z+4.5);player.rotationYaw=0;player.rotationPitch=35;}
    }
    private boolean ready(){
        for(int cx=X>>4;cx<=(X+W-1)>>4;cx++){
            Chunk c=world.getChunkProvider().getLoadedChunk(cx,Z>>4);
            if(c==null||!manager().canSendUpdatedChunkLight(cx,Z>>4)||((RgbChunk)c).pulsar$getRgbSnapshot()==null)return false;
        }
        return true;
    }
    private static int index(int x,int y,int z){return (x-X)+W*((z-Z)+D*(y-Y));}
    private int[][] reference(){
        int[][] result=new int[4][W*H*D];
        for(int c=0;c<4;c++){
            ArrayDeque<BlockPos> queue=new ArrayDeque<>();
            for(int x=X;x<X+W;x++)for(int y=Y;y<Y+H;y++)for(int z=Z;z<Z+D;z++){
                BlockPos p=new BlockPos(x,y,z);IBlockState state=world.getBlockState(p);
                int value=c==3?state.getLightValue(world,p):RgbLight.channel(BlockLightColors.emission(state,state.getLightValue(world,p)),c);
                result[c][index(x,y,z)]=value;if(value>0)queue.add(p);
            }
            while(!queue.isEmpty()){
                BlockPos p=queue.remove();int value=result[c][index(p.getX(),p.getY(),p.getZ())];
                for(var dir:net.minecraft.util.EnumFacing.VALUES){BlockPos q=p.offset(dir);
                    int x=q.getX(),y=q.getY(),z=q.getZ();if(x<X||x>=X+W||y<Y||y>=Y+H||z<Z||z>=Z+D)continue;
                    IBlockState dest=world.getBlockState(q);
                    int absorption=Math.max(1,dest.getLightOpacity(world,q));
                    if(c<3 && (dest.getBlock()==Blocks.STAINED_GLASS||dest.getBlock()==Blocks.STAINED_GLASS_PANE)) {
                        var dye=net.minecraft.item.EnumDyeColor.byMetadata(dest.getBlock().getMetaFromState(dest));
                        absorption=Math.max(absorption,Math.round(15*(1-dye.getColorComponentValues()[c])));
                    }
                    int target=Math.max(0,value-absorption);
                    int i=index(x,y,z);if(target>result[c][i]){result[c][i]=target;queue.add(q);}
                }
            }
        }
        return result;
    }
    private JsonObject compare(String name,int[][] expected){
        int mismatches=0, scalarMismatches=0, canonicalMismatches=0;String first="";
        for(int x=X;x<X+W;x++)for(int y=Y;y<Y+H;y++)for(int z=Z;z<Z+D;z++){
            int value=((RgbChunk)world.getChunk(x>>4,z>>4)).pulsar$getRgbSnapshot().get(x,y,z),i=index(x,y,z);
            int want=RgbLight.pack(expected[0][i],expected[1][i],expected[2][i]);
            if(((RgbChunk)world.getChunk(x>>4,z>>4)).pulsar$getRgbSnapshot().canonical(x,y,z)!=expected[3][i])canonicalMismatches++;
            if(world.getLightFor(EnumSkyBlock.BLOCK,new BlockPos(x,y,z))!=expected[3][i])scalarMismatches++;
            if(value!=want){if(mismatches++==0)first=x+","+y+","+z+" got="+Integer.toHexString(value)+" want="+Integer.toHexString(want);}
        }
        JsonObject out=new JsonObject();
        var entry=world.getPlayerChunkMap().getEntry(X>>4,Z>>4);
        try {
            var field=RgbNetwork.class.getDeclaredField("DIRTY");field.setAccessible(true);
            var dirty=(Map<?,?>)((Map<?,?>)field.get(null)).get(world);
            out.addProperty("dirty_count",dirty==null?-1:dirty.size());
            var clients=RgbNetwork.class.getDeclaredField("CLIENTS");clients.setAccessible(true);
            out.addProperty("rgb_clients",((Set<?>)clients.get(null)).size());
        }catch(Exception ignored){}
        out.addProperty("world_ticks",worldTicks);out.addProperty("world_time",world.getTotalWorldTime());out.addProperty("capture_snapshots",world.captureBlockSnapshots);
        out.addProperty("server_revision_0",((RgbChunk)world.getChunk(X>>4,Z>>4)).pulsar$getRgbSnapshot().revision);
        out.addProperty("server_revision_1",((RgbChunk)world.getChunk((X+16)>>4,Z>>4)).pulsar$getRgbSnapshot().revision);
        out.addProperty("server_populated",world.getChunk(X>>4,Z>>4).isPopulated());
        out.addProperty("entry_sent",entry!=null&&entry.isSentToPlayers());
        out.addProperty("entry_chunk_same",entry!=null&&entry.getChunk()==world.getChunk(X>>4,Z>>4));
        out.addProperty("neighbours_ready",manager().areNeighboursLightReady(X>>4,Z>>4));
        out.addProperty("server_snapshot_canonical_mismatches",canonicalMismatches);out.addProperty("server_scalar_mismatches",scalarMismatches);out.addProperty("name",name);out.addProperty("cells",W*H*D);out.addProperty("mismatches",mismatches);out.addProperty("first",first);
        System.out.println("RGB_AUDIT "+out);
        if(mismatches!=0||scalarMismatches!=0||canonicalMismatches!=0)throw new IllegalStateException(out.toString());
        return out;
    }
    private CompletableFuture<JsonObject> clientCheck(int[][] expected,String name){
        CompletableFuture<JsonObject> future=new CompletableFuture<>();
        Minecraft mc=Minecraft.getMinecraft();
        mc.addScheduledTask(()->{
            try{
                mc.gameSettings.gammaSetting=1;mc.gameSettings.hideGUI=true;
                mc.player.rotationYaw=mc.player.prevRotationYaw=0;
                mc.player.rotationPitch=mc.player.prevRotationPitch=35;
                int bad=0,scalarBad=0,canonicalBad=0;
                for(int x=X;x<X+W;x++)for(int y=Y;y<Y+H;y++)for(int z=Z;z<Z+D;z++){
                    Chunk chunk=mc.world.getChunkProvider().getLoadedChunk(x>>4,z>>4);int i=index(x,y,z);
                    RgbSnapshot snapshot=chunk==null?null:((RgbChunk)chunk).pulsar$getRgbSnapshot();
                    if(snapshot==null||snapshot.canonical(x,y,z)!=expected[3][i])canonicalBad++;
                    if(snapshot==null||snapshot.get(x,y,z)!=RgbLight.pack(expected[0][i],expected[1][i],expected[2][i]))bad++;
                    if(mc.world.getLightFor(EnumSkyBlock.BLOCK,new BlockPos(x,y,z))!=expected[3][i])scalarBad++;
                }
                BlockPos pos=new BlockPos(X+18,Y,Z+8);BufferBuilder buffer=new BufferBuilder(65536);buffer.begin(7,DefaultVertexFormats.BLOCK);
                mc.getBlockRendererDispatcher().renderBlock(mc.world.getBlockState(pos),pos,mc.world,buffer);buffer.finishDrawing();
                var bytes=buffer.getByteBuffer().duplicate().order(ByteOrder.nativeOrder());int colored=0;
                for(int i=0;i<buffer.getVertexCount();i++){int color=bytes.getInt(i*DefaultVertexFormats.BLOCK.getSize()+DefaultVertexFormats.BLOCK.getColorOffset());if((color&255)!=(color>>8&255)||(color&255)!=(color>>16&255))colored++;}
                photoFrames=0;photo=name;
                JsonObject out=new JsonObject();var r0=((RgbChunk)mc.world.getChunk(X>>4,Z>>4)).pulsar$getRgbSnapshot();
                var r1=((RgbChunk)mc.world.getChunk((X+16)>>4,Z>>4)).pulsar$getRgbSnapshot();
                out.addProperty("client_revision_0",r0==null?-1:r0.revision);out.addProperty("client_revision_1",r1==null?-1:r1.revision);
                out.addProperty("blue_block",mc.world.getBlockState(BLUE).toString());out.addProperty("red_block",mc.world.getBlockState(RED).toString());
                out.addProperty("client_chunk_class",mc.world.getChunkProvider().getLoadedChunk(pos.getX()>>4,pos.getZ()>>4).getClass().getName());out.addProperty("client_chunk_loaded",mc.world.getChunkProvider().getLoadedChunk(pos.getX()>>4,pos.getZ()>>4)!=null);out.addProperty("floor",mc.world.getBlockState(pos).toString());out.addProperty("player",mc.player.getPosition().toString());out.addProperty("vertices",buffer.getVertexCount());out.addProperty("mismatches",bad);out.addProperty("snapshot_canonical_mismatches",canonicalBad);out.addProperty("scalar_mismatches",scalarBad);out.addProperty("colored_vertices",colored);out.addProperty("vanilla_hook",RgbClient.vanillaRendered);out.addProperty("celeritas_hook",RgbClient.celeritasRendered);out.addProperty("valid",bad==0&&scalarBad==0&&canonicalBad==0&&colored>0);future.complete(out);
            }catch(Throwable t){future.completeExceptionally(t);}
        });
        return future;
    }
    private void finish(Throwable failure){
        phase=-1;REPORT.addProperty("valid",failure==null);if(failure!=null)REPORT.addProperty("failure",failure.toString());
        try{Path path=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/rgb-audit.json");Files.createDirectories(path.getParent());Files.writeString(path,new GsonBuilder().setPrettyPrinting().create().toJson(REPORT));}catch(Exception e){throw new RuntimeException(e);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("RGB_AUDIT_COMPLETED "+REPORT);
    }
}
