$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
if((Get-Content "$root\phase4\progress.json" -Raw|ConvertFrom-Json).stage -ne 'complete'){throw 'Main cohort still running'}
foreach($trial in @(@{v='before';i=1;artifact='sky.jar'},@{v='after';i=1;artifact='white.jar'},@{v='after';i=2;artifact='white.jar'},@{v='before';i=2;artifact='sky.jar'})){
 $run="white-filtered-$($trial.v)-$($trial.i)"
 [IO.File]::WriteAllText("$root\phase4\filtered-progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
 & "$root\phase4-run.ps1" -Run $run -Mode RGB -Command 'function perfbench:filteredupdates' -Artifact $trial.artifact
 if((Get-Content "$root\runs\$run\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Filtered timing failed $run"}
}
[IO.File]::WriteAllText("$root\phase4\filtered-progress.json",'{"stage":"complete"}')
