$ErrorActionPreference='Stop'
$root='E:\Github\Pulsar-RGB-20261016'
$first=Get-Content "$root\runs\white-vanilla-final\results\sky-audit.json" -Raw|ConvertFrom-Json
if($first.valid -ne $true){throw 'Initial white validation failed'}
function Audit([string]$run,[string]$command,[string]$template='flat',[string]$mode='RGB',[switch]$Fast){
 [IO.File]::WriteAllText("$root\phase4\progress.json",(@{stage='correctness';run=$run}|ConvertTo-Json))
 & "$root\phase4-run.ps1" -Run $run -Artifact white.jar -Mode $mode -Command $command -Template $template -Celeritas:$Fast -FastCeleritas:$Fast
 $file=if($command -like 'issueaudit*'){'issue-audit.json'}elseif($command -like 'rgbaudit*'){'rgb-audit.json'}else{'sky-audit.json'}
 if((Get-Content "$root\runs\$run\results\$file" -Raw|ConvertFrom-Json).valid -ne $true){throw "Audit failed $run"}
}
Audit 'white-celeritas-final' 'skyaudit range' 'flat' 'RGB' -Fast
Audit 'white-cache-reload' 'skyaudit reload' 'sky-cache'
Audit 'white-cache-migration' 'skyaudit reload' 'sky-migration'
Audit 'white-block-regression' 'rgbaudit'
Audit 'white-scalar-audit' 'rgbaudit scalar' 'flat' 'SCALAR'
Audit 'white-cqr' 'issueaudit ship' 'fresh-normal'
foreach($cohort in @(1,3)){
 foreach($mode in @('RGB','SCALAR')){
  foreach($item in @(@{v='before';i=$cohort;artifact='sky.jar'},@{v='after';i=$cohort;artifact='white.jar'},@{v='after';i=$cohort+1;artifact='white.jar'},@{v='before';i=$cohort+1;artifact='sky.jar'})){
   $run="white-perf-$($mode.ToLower())-$($item.v)-$($item.i)"
   [IO.File]::WriteAllText("$root\phase4\progress.json",(@{stage='timing';run=$run}|ConvertTo-Json))
   & "$root\phase4-run.ps1" -Run $run -Mode $mode -Command 'lightbench updates 2000 1000' -Artifact $item.artifact
   if((Get-Content "$root\runs\$run\status.json" -Raw|ConvertFrom-Json).valid -ne $true){throw "Timing failed $run"}
  }
 }
}
[IO.File]::WriteAllText("$root\phase4\progress.json",'{"stage":"complete"}')
