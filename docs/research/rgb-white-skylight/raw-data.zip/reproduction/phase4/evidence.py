from pathlib import Path
import json,hashlib,zipfile,statistics,subprocess
import xml.etree.ElementTree as E
study=Path("E:/Github/Pulsar-RGB-20261016");repo=Path("E:/Github/Pulsar")
out=repo/"docs/research/rgb-white-skylight";out.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):(out/n).write_text(json.dumps(d,indent=2)+"\n",encoding="utf-8",newline="\n")
frozen=read(study/"phase4/source-freeze.json");assert all(sha(repo/p)==v for p,v in frozen.items())
unchanged=["LICENSE.md","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarBlockEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/ScalarSkyEngine.java","src/main/java/com/sumirelabs/pulsar/light/engine/SkyLightColumnProcessor.java","src/main/java/com/sumirelabs/pulsar/light/engine/LightEngineCache.java","src/main/java/com/sumirelabs/pulsar/light/ContextualLightPalette.java","src/main/java/com/sumirelabs/pulsar/light/ContextualLightPaletteChecks.java","src/main/java/com/sumirelabs/pulsar/mixin/MixinBlockStateContainerSamples.java"]
subprocess.run(["git","diff","--exit-code","HEAD","--",*unchanged],cwd=repo,check=True)
core=["white-vanilla-final","white-celeritas-final","white-cache-reload","white-cache-migration"]
validation={}
for run in core:
 d=read(study/"runs"/run/"results/sky-audit.json");assert d["valid"] and d["palette_mutation_checks"]
 assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts/white.jar")
 for c in d["cases"]:
  if c["name"].startswith("outer-"):assert c["rgb"]==0xE00 and c["canonical"]==14 and c["cells"]==1
  else:
   assert c["cells"]==24576
   assert c["rgb_mismatches"]==c["canonical_mismatches"]==c["stored_mismatches"]==c["block_mismatches"]==0
   if c["name"].startswith("floating") or c["name"]=="reload-floating":assert c["absent_physical_sections"]>=14
 for k,c in d.items():
  if k.startswith("client-"):
   assert c["valid"] and c["geometry_matches"]
   assert c["rgb_mismatches"]==c["canonical_mismatches"]==c["stored_mismatches"]==c["block_mismatches"]==0
  if k.startswith("boundary-client-"):assert c["valid"] and c["geometry_matches"] and c["rgb"]==0xE00 and c["canonical"]==c["stored"]==14
 if "cache" not in run:
  assert len(d["cases"])==16 and d["range_targets"]==2 and d["range_superseded"] and d["range_gate_held"]
  assert d["boundary_white_eligible"] and d["white_storage_released"] and d["split_roof_case"]
  for i in [4,6,8,14,16,18,20]:assert d["client-"+str(i)]["colored_vertices"]>0
 validation[run]=d
assert validation["white-celeritas-final"]["client-8"]["celeritas_hook"]
assert validation["white-cache-reload"]["cache_valid_main"] and validation["white-cache-reload"]["cache_valid_floating"]
assert not validation["white-cache-migration"]["cache_valid_main"]
for run in ["white-block-regression","white-scalar-audit"]:
 d=read(study/"runs"/run/"results/rgb-audit.json");assert d["valid"]
 if run=="white-scalar-audit":assert d["scalar_has_no_rgb_chunk_fields"] and d["scalar_has_no_rgb_palette_fields"]
 else:
  assert len(d["cases"])==10
  for c in d["cases"]:assert c["mismatches"]==c["server_scalar_mismatches"]==c["server_snapshot_canonical_mismatches"]==0
  for k,c in d.items():
   if k.startswith("client-"):assert c["valid"] and c["mismatches"]==c["scalar_mismatches"]==c["snapshot_canonical_mismatches"]==0
 validation[run]=d
reg=study/"runs/white-cqr/results";d=read(reg/"issue-audit.json");assert d["valid"] and d["crystal_states"]==112
cases={c["name"]:c for c in d["cases"]}
for n in ["world-placement","direct-chunk-placement","full-relight"]:assert cases[n]["mismatches"]==0
assert cases["initial-send-race"]["context_pending"] and not cases["initial-send-race"]["sent_while_pending"]
assert cases["initial-send-after-drain"]["stored"]==10 and cases["initial-send-after-drain"]["retry_sent"]
assert not cases["existing-entry-watch-race"]["watching_while_pending"]
assert cases["existing-entry-watch-after-drain"]["watch_events_while_pending"]==0 and cases["existing-entry-watch-after-drain"]["watch_events_after_drain"]==1
assert cases["sealed-oak-room"]["lit_interior_cells"]==0
assert cases["native-cqr-generation"]["cells"]==68800
assert cases["native-cqr-vs-full-relight"]["sky_differences"]==cases["native-cqr-vs-full-relight"]["block_differences"]==0
corner=read(reg/"issue-client.json");assert corner["lit_interior_cells"]==corner["max_sky"]==0
assert all(v["sky"]==v["block"]==0 for m in corner["models"] for v in m["interior_face_lightmap"])
ship=read(reg/"issue-ship-client.json");assert all(v["sky_mismatches"]==v["block_mismatches"]==0 for v in ship)
validation["white-cqr"]={"server":d,"corner_client":corner,"ship_client":ship}
xml=[E.parse(p).getroot().attrib for p in (repo/"build/test-results/test").glob("TEST-*.xml")]
tests={k:sum(int(r.get(k,0)) for r in xml) for k in ["tests","failures","errors","skipped"]}
assert tests=={"tests":212,"failures":0,"errors":0,"skipped":0};validation["junit"]=tests
write("validation.json",validation)
runs=[];groups={}
for mode in ["rgb","scalar","filtered"]:
 for version in ["before","after"]:
  for i in ([1,2] if mode=="filtered" else [1,2,3,4]):
   run=f"white-filtered-{version}-{i}" if mode=="filtered" else f"white-perf-{mode}-{version}-{i}"
   paths=list((study/"runs"/run/"results").glob("*updates*.json"));assert len(paths)==1
   d=read(paths[0])["benchmark"]
   assert d["preflight"]["initial_light_verified"] and d["preflight"]["post_measurement_volume_verified"]
   assert d["plan"]["warmup_pairs"]==2000 and d["plan"]["measured_pairs"]==1000
   artifact="sky.jar" if version=="before" else "white.jar"
   assert read(study/"runs"/run/"stage.json")["sha256"].lower()==sha(study/"artifacts"/artifact)
   row={"run":run,"mode":mode,"version":version,"gc":d["measurement_gc"]}
   for p in d["phases"]:
    assert p["sample_count"]==1000 and p["all_samples_verified"] and all(s["light_verified"] for s in p["samples"])
    row[p["name"]]=p["completion_summary_nanos"]["average"]/1000
    groups.setdefault((mode,version,p["name"]),[]).append(row[p["name"]])
   runs.append(row)
timing={"unit":"microseconds","summary":"median of independent JVM run means; four per main variant, two per filtered variant","runs":runs,"groups":[{"mode":k[0],"version":k[1],"phase":k[2],"median":statistics.median(v),"minimum":min(v),"maximum":max(v)} for k,v in groups.items()]}
write("timing.json",timing)
protocol=read(repo/"docs/research/rgb-sky-prototype/protocol.json")
protocol["baseline_source"]="0a291d9"
protocol["order"]=[f"white-perf-{mode}-{v}-{i}" for cohort in [1,3] for mode in ["rgb","scalar"] for v,i in [("before",cohort),("after",cohort),("after",cohort+1),("before",cohort+1)]]
protocol.pop("optimization_order",None)
protocol["filtered_order"]=["white-filtered-before-1","white-filtered-after-1","white-filtered-after-2","white-filtered-before-2"]
protocol["filtered_fixture"]="One red stained glass at (20032,255,20032), outside checked air volume and measured hole frontier; forces full color work without changing canonical expected light."
write("protocol.json",protocol)
write("artifacts.json",{"baseline_commit":"0a291d9","license":"LGPL-3.0 unchanged","sha256":{n:sha(study/"artifacts"/n) for n in ["sky.jar","white.jar","white-audit.jar","white-block-audit.jar","issue-audit-fresh.jar"]},"production_source_sha256":frozen})
with zipfile.ZipFile(out/"raw-data.zip","w",zipfile.ZIP_DEFLATED) as z:
 for run in core+["white-block-regression","white-scalar-audit","white-cqr"]+[r["run"] for r in runs]:
  for p in (study/"runs"/run/"results").glob("*.json"):z.write(p,f"runs/{run}/{p.name}")
  z.write(study/"runs"/run/"stage.json",f"runs/{run}/stage.json")
 for n in ["phase4-run.ps1","phase4-finish.ps1","phase4-filtered.ps1","world.cjs"]:z.write(study/n,"reproduction/"+n)
 z.write(study/"tools/nbt-read.mjs","reproduction/tools/nbt-read.mjs")
 z.write(study/"helper/src/main/java/com/sumirelabs/skyaudit/SkyAudit.java","reproduction/SkyAudit.java")
 z.write(study/"helper/src/main/java/com/sumirelabs/rgbaudit/RgbAudit.java","reproduction/RgbAudit.java")
 for n in ["IssueAudit.java","IssueClientAudit.java","ShipAudit.java"]:z.write(study/"helper/src/main/java/com/sumirelabs/issueaudit"/n,"reproduction/"+n)
 z.write(Path(__file__),"reproduction/phase4/evidence.py")
assert zipfile.ZipFile(out/"raw-data.zip").testzip() is None
write("SHA256SUMS.json",{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!="SHA256SUMS.json"})
print(json.dumps(timing,indent=2))
