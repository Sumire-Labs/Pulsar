package com.sumirelabs.fluidhueaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.BlockLightColors;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.world.PulsarWorld;
import git.jbredwards.fluidlogged_api.api.util.*;
import net.minecraft.command.*;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.nio.file.*;

/** Disposable native fluid color regression; never packaged with Pulsar. */
@Mod(modid="fluidhueaudit",name="Fluid Hue Audit",version="1",dependencies="required-after:pulsar;required-after:fluidlogged_api")
public final class FluidHueAudit {
    private static final BlockPos POS=new BlockPos(20040,110,20040);
    private WorldServer world; private int stage=-1,ticks,settle; private volatile int request=-1,accepted=-1;
    private final JsonArray cases=new JsonArray();
    @Mod.EventHandler public void init(FMLInitializationEvent event){
        for(var state:Blocks.LAVA.getBlockState().getValidStates())BlockLightColors.register(state,15,0,0);
        for(var state:Blocks.FLOWING_LAVA.getBlockState().getValidStates())BlockLightColors.register(state,15,0,0);
        // The non-emissive containing block deliberately has a conflicting blue hue.
        BlockLightColors.register(Blocks.GLASS.getDefaultState(),0,0,15);
        MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent event){event.registerServerCommand(new CommandBase(){
        public String getName(){return "fluidhueaudit";}
        public String getUsage(ICommandSender sender){return "/fluidhueaudit";}
        public int getRequiredPermissionLevel(){return 0;}
        public void execute(net.minecraft.server.MinecraftServer server,ICommandSender sender,String[] args){world=(WorldServer)sender.getEntityWorld();stage=0;}
    });}
    private void put(FluidState fluid){
        FluidloggedUtils.setFluidState(world,POS,world.getBlockState(POS),fluid,false);
        if(FluidState.get(world,POS)!=fluid)throw new IllegalStateException("Fluid mutation rejected");
    }
    private static int sample(World world,BlockPos pos){
        var snapshot=((RgbChunk)world.getChunk(pos)).pulsar$getRgbSnapshot();
        return snapshot==null?-1:snapshot.get(pos.getX(),pos.getY(),pos.getZ());
    }
    @SubscribeEvent public void server(TickEvent.ServerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||stage<0)return;
        try{
            if(++ticks>1200)throw new IllegalStateException("Fluid color timeout stage="+stage+" source="+Integer.toHexString(sample(world,POS)));
            var manager=((PulsarWorld)world).pulsar$getLightManager();
            if(stage==0){
                for(int cx=1250;cx<=1254;cx++)for(int cz=1250;cz<=1254;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
                // Seal a stable glass-contained lava cell, with one glass observation cell.
                for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++)for(int z=-2;z<=2;z++)world.setBlockState(POS.add(x,y,z),Blocks.STONE.getDefaultState(),2);
                world.setBlockState(POS,Blocks.GLASS.getDefaultState(),3);
                world.setBlockState(POS.east(),Blocks.GLASS.getDefaultState(),3);
                put(FluidState.of(Blocks.LAVA));
                for(int cx=1250;cx<=1254;cx++)for(int cz=1250;cz<=1254;cz++)manager.forceRelightChunk(cx,cz);
                stage=1;settle=0;return;
            }
            if(manager.hasPendingLightWorkNear(POS.getX()>>4,POS.getZ()>>4)){settle=0;return;}
            if(++settle<5)return;
            int expected=stage==3?0:0xF00,near=stage==3?0:0xE00;
            if(sample(world,POS)!=expected||sample(world,POS.east())!=near)throw new AssertionError("Wrong fluid hue stage="+stage+" source="+Integer.toHexString(sample(world,POS))+" neighbor="+Integer.toHexString(sample(world,POS.east())));
            request=stage;if(accepted!=stage)return;
            JsonObject row=new JsonObject();row.addProperty("name",stage==1?"insert-fluid-hue":stage==2?"cold-relight-fluid-hue":"remove-fluid-without-ghost");row.addProperty("source_rgb",Integer.toHexString(expected));row.addProperty("neighbor_rgb",Integer.toHexString(near));row.addProperty("client_verified",true);cases.add(row);
            if(stage==1)manager.forceRelightChunk(POS.getX()>>4,POS.getZ()>>4);
            if(stage==2)put(FluidState.EMPTY);
            if(stage==3){finish(null);return;}
            stage++;settle=0;
        }catch(Throwable failure){failure.printStackTrace();finish(failure);}
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END||request<1||accepted==request)return;
        var world=net.minecraft.client.Minecraft.getMinecraft().world;
        if(world==null||!world.isBlockLoaded(POS)||!RgbClient.active())return;
        int expected=request==3?0:0xF00,near=request==3?0:0xE00;
        if(sample(world,POS)==expected&&sample(world,POS.east())==near)accepted=request;
    }
    private void finish(Throwable failure){
        stage=-1;JsonObject result=new JsonObject();result.addProperty("valid",failure==null);if(failure!=null)result.addProperty("failure",failure.toString());result.add("cases",cases);
        try{var output=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/fluid-hue.json");Files.createDirectories(output.getParent());Files.writeString(output,new GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception error){throw new RuntimeException(error);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");
    }
}
