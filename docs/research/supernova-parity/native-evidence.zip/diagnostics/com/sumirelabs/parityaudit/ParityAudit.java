package com.sumirelabs.parityaudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.*;
import com.sumirelabs.pulsar.core.RgbMixinSelection;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import java.nio.file.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Private native parity diagnostics; not part of the Pulsar distribution. */
@Mod(modid="parityaudit",name="RGB Parity Audit",version="1",dependencies="required-after:pulsar")
public final class ParityAudit {
    private static final int X=20000,Y=80,Z=20032;
    private static final BlockPos SOURCE=new BlockPos(X+2,Y+2,Z+4), FILTER=new BlockPos(X+4,Y+2,Z+4),
            AFTER=new BlockPos(X+5,Y+2,Z+4), SKY_FILTER=new BlockPos(X+10,Y+6,Z+10), SKY=new BlockPos(X+10,Y+5,Z+10),
            STATIC_SOURCE=new BlockPos(X+11,Y+2,Z+4), ABSOLUTE=new BlockPos(X+35,Y+34,Z+7);
    private static final AtomicInteger CALLBACKS=new AtomicInteger(), STATIC_CALLBACKS=new AtomicInteger();
    private static volatile String callbackFailure;
    private static Block source,filter,staticSource,absoluteSource;
    private static volatile int expectedSource,expectedAfter,expectedSky,clientGeneration=-1,requestGeneration=-1;
    private static volatile int clientCanonical=15; private static volatile boolean clientAccepted; private static volatile String clientState="not observed";
    private WorldServer world;
    private int stage=-1,ticks,wait,generation; private int auxiliary=0x00F; private static volatile int clientAuxiliary=0x00F;
    private final JsonArray cases=new JsonArray();

    public ParityAudit(){MinecraftForge.EVENT_BUS.register(this);}
    @SubscribeEvent public void blocks(RegistryEvent.Register<Block> event){
        source=new DynamicSource().setRegistryName("parityaudit","dynamic_source");
        filter=new DynamicFilter().setRegistryName("parityaudit","dynamic_filter");
        staticSource=new StaticSource().setRegistryName("parityaudit","static_source");
        absoluteSource=new AbsoluteSource().setRegistryName("parityaudit","absolute_source");event.getRegistry().registerAll(source,filter,staticSource,absoluteSource);
    }
    @Mod.EventHandler public void pre(FMLPreInitializationEvent event){
        GameRegistry.registerTileEntity(ColorTile.class,new ResourceLocation("parityaudit","color"));
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent event){
        event.registerServerCommand(new CommandBase(){
            public String getName(){return "parityaudit";}
            public String getUsage(ICommandSender sender){return "/parityaudit";}
            public int getRequiredPermissionLevel(){return 0;}
            public void execute(MinecraftServer server,ICommandSender sender,String[] args){world=(WorldServer)sender.getEntityWorld();stage=0;ticks=wait=0;}
        });
    }
    public static final class ColorTile extends TileEntity {
        int mode;
        public NBTTagCompound writeToNBT(NBTTagCompound nbt){super.writeToNBT(nbt);nbt.setInteger("mode",mode);return nbt;}
        public void readFromNBT(NBTTagCompound nbt){super.readFromNBT(nbt);mode=nbt.getInteger("mode");}
    }
    private static class ColorBlock extends Block {
        ColorBlock(){super(Material.GLASS);setLightOpacity(0);}
        public boolean isOpaqueCube(IBlockState state){return false;}
        public boolean hasTileEntity(IBlockState state){return true;}
        public TileEntity createTileEntity(World world,IBlockState state){return new ColorTile();}
    }
    private static void callback(IBlockAccess access){
        CALLBACKS.incrementAndGet();
        if(!(access instanceof WorldServer)||!((WorldServer)access).isCallingFromMinecraftThread()) {
            callbackFailure="Positional RGB callback ran off the server world thread: "+Thread.currentThread().getName();
            throw new IllegalStateException(callbackFailure);
        }
    }
    private static int mode(IBlockAccess world,BlockPos pos){TileEntity tile=world.getTileEntity(pos);return tile instanceof ColorTile?((ColorTile)tile).mode:0;}
    private static final class DynamicSource extends ColorBlock implements PositionalColoredLightSource {
        DynamicSource(){setLightLevel(1);}
        public int getColoredLightEmission(IBlockAccess access,BlockPos pos,IBlockState state){
            callback(access);int mode=mode(access,pos);return mode==0?0xF00:mode==1?0x00F:mode==3?0x840:0;
        }
    }
    private static final class DynamicFilter extends ColorBlock implements PositionalColoredTranslucency {
        public int getColoredTransmittance(IBlockAccess access,BlockPos pos,IBlockState state){callback(access);return mode(access,pos)==0?0xF00:0x00F;}
    }
    private static final class AbsoluteSource extends Block implements ColoredLightSource {
        AbsoluteSource(){super(Material.GLASS);setLightOpacity(0);}
        public boolean isOpaqueCube(IBlockState state){return false;}
        public int getColoredLightEmission(IBlockState state){STATIC_CALLBACKS.incrementAndGet();return 0x840;}
    }
    private static final class StaticSource extends Block implements ColoredLightSource {
        StaticSource(){super(Material.ROCK);setLightLevel(1);}
        public int getColoredLightEmission(IBlockState state){STATIC_CALLBACKS.incrementAndGet();return 0x0F0;}
    }
    private ColorTile tile(BlockPos pos){TileEntity tile=world.getTileEntity(pos);if(!(tile instanceof ColorTile))throw new IllegalStateException("Missing color tile "+pos);return (ColorTile)tile;}
    private int rgb(BlockPos pos,boolean sky){
        var chunk=world.getChunk(pos);var snapshot=sky?((RgbChunk)chunk).pulsar$getRgbSkySnapshot():((RgbChunk)chunk).pulsar$getRgbSnapshot();
        return snapshot==null?-1:snapshot.get(pos.getX(),pos.getY(),pos.getZ());
    }
    private String progress(){ var c=world.getChunk(SOURCE); var m=((PulsarWorld)world).pulsar$getLightManager(); var e=world.getPlayerChunkMap().getEntry(c.x,c.z); return "canonical="+c.getLightFor(EnumSkyBlock.BLOCK,SOURCE)+" pending="+m.hasPendingLightWorkNear(c.x,c.z)+" selfReady="+((com.sumirelabs.pulsar.light.PulsarChunk)c).pulsar$isLightReady()+" neighbours="+m.areNeighboursLightReady(c.x,c.z)+" sendReady="+m.canSendUpdatedChunkLight(c.x,c.z)+" entry="+(e==null?"null":e.isSentToPlayers()+"/"+(e.getChunk()==c))+" request="+requestGeneration+" client="+clientState; } private void setup(){
        world.getGameRules().setOrCreateGameRule("doDaylightCycle","false");world.setWorldTime(6000);
        for(int cx=(X>>4)-2;cx<=(X>>4)+4;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+2;cz++)world.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
        for(int x=0;x<16;x++)for(int y=0;y<=6;y++)for(int z=0;z<16;z++)world.setBlockState(new BlockPos(X+x,Y+y,Z+z),
                x==0||x==15||y==0||y==6||z==0||z==15?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
        // Two sealed one-cell tunnels ensure a filter cannot be bypassed around its sides.
        for(int x=1;x<15;x++)for(int y=1;y<=3;y++)for(int z=3;z<=5;z++)world.setBlockState(new BlockPos(X+x,Y+y,Z+z),
                y==2&&z==4&&x!=1&&x!=8&&x!=14?Blocks.AIR.getDefaultState():Blocks.STONE.getDefaultState(),2);
        for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++)for(int z=-2;z<=2;z++)world.setBlockState(ABSOLUTE.add(x,y,z),
                Math.abs(x)==2||Math.abs(y)==2||Math.abs(z)==2?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
        world.setBlockState(ABSOLUTE,absoluteSource.getDefaultState(),3);
        world.setBlockState(SOURCE,source.getDefaultState(),3);world.setBlockState(FILTER,filter.getDefaultState(),3);
        world.setBlockState(SKY_FILTER,filter.getDefaultState(),3);world.setBlockState(STATIC_SOURCE,staticSource.getDefaultState(),3);
        EntityPlayerMP player=(EntityPlayerMP)world.playerEntities.get(0);player.setGameType(GameType.CREATIVE);
        player.capabilities.isFlying=true;player.sendPlayerAbilities();player.connection.setPlayerLocation(X+10.5,Y+3,Z+13.5,180,0);
        world.getPlayerChunkMap().updateMovingPlayer(player);
    }
    @SubscribeEvent public void server(TickEvent.ServerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||stage<0)return;
        try{
            if(++wait%100==0)System.out.println("PARITY_PROGRESS "+progress()); if(wait>900)throw new IllegalStateException("Timed out stage "+stage+" source="+(RgbMixinSelection.rgbEnabled()?rgb(SOURCE,false):-1)+" callbacks="+CALLBACKS+" canonical="+world.getChunk(SOURCE).getLightFor(EnumSkyBlock.BLOCK,SOURCE)+" pending="+((PulsarWorld)world).pulsar$getLightManager().hasPendingLightWorkNear(X>>4,Z>>4)+" request="+requestGeneration+" client="+clientState);
            if(callbackFailure!=null)throw new IllegalStateException(callbackFailure);
            if(stage==0){setup();stage=1;wait=ticks=0;return;}
            if(++ticks<20)return;
            if(((PulsarWorld)world).pulsar$getLightManager().hasPendingLightWorkNear(X>>4,Z>>4)||((PulsarWorld)world).pulsar$getLightManager().hasPendingLightWorkNear(ABSOLUTE.getX()>>4,ABSOLUTE.getZ()>>4))return;
            boolean rgb=RgbMixinSelection.rgbEnabled();
            if(stage==1){if(!accept("initial",0xF00,0xC00,0xF00,rgb))return;
                tile(SOURCE).mode=1; // No block update, checkLight or notify: scalar emission remains 15.
                stage=2;ticks=wait=0;return;
            }
            if(stage==2){if(!accept("color-only-source",0x00F,0,0xF00,rgb))return;
                tile(FILTER).mode=1;tile(SKY_FILTER).mode=1;stage=3;ticks=wait=0;return;
            }
            if(stage==3){if(!accept("color-only-block-and-sky-filter",0x00F,0x00C,0x00F,rgb))return;
                tile(SOURCE).mode=2;stage=4;ticks=wait=0;return;
            }
            if(stage==4){if(!accept("disabled-rgb-independent-scalar",0,0,0x00F,rgb))return;
                world.setBlockState(new BlockPos(X+8,Y+2,Z+4),Blocks.AIR.getDefaultState(),3);
                tile(SOURCE).mode=0;stage=5;ticks=wait=0;return;
            }
            if(stage==5){if(!accept("overlapping-source-channels",0xF06,0x009,0x00F,rgb))return;
                tile(FILTER).mode=0;auxiliary=0x00F;stage=6;ticks=wait=0;return;
            }
            if(stage==6){if(!accept("filter-keeps-independent-blue-source",0xF00,0xC09,0x00F,rgb))return;
                tile(SOURCE).mode=2;auxiliary=0x00F;stage=7;ticks=wait=0;return;
            }
            if(stage==7){if(!accept("remove-red-without-blue-ghosts",0,0x009,0x00F,rgb))return;
                tile(SOURCE).mode=3;stage=8;ticks=wait=0;return;
            }
            if(stage==8){if(!accept("weak-api-emission-keeps-strength",0x840,0x509,0x00F,rgb))return;
                ((PulsarWorld)world).pulsar$getLightManager().forceRelightChunk(ABSOLUTE.getX()>>4,ABSOLUTE.getZ()>>4);stage=9;ticks=wait=0;return;
            }
            if(stage==9){if(!accept("absolute-api-source-cold-relight",0x840,0x509,0x00F,rgb))return;
                JsonObject result=new JsonObject();result.addProperty("valid",true);result.addProperty("rgb",rgb);result.addProperty("packed_requested",Boolean.getBoolean("pulsar.rgb.packed"));result.addProperty("rgb_max_gameplay",RgbSettings.projectsGameplayLight());
                result.addProperty("world_thread_callbacks",CALLBACKS.get());result.addProperty("static_callbacks",STATIC_CALLBACKS.get());
                if(rgb&&CALLBACKS.get()==0)throw new IllegalStateException("No dynamic callbacks");
                if(!rgb&&(CALLBACKS.get()!=0||STATIC_CALLBACKS.get()!=0))throw new IllegalStateException("RGB callbacks executed in SCALAR");
                result.addProperty("mutations_without_lighting_notifications",true);result.add("cases",cases);finish(result);
            }
        }catch(Throwable failure){failure.printStackTrace();JsonObject result=new JsonObject();result.addProperty("valid",false);result.addProperty("failure",failure.toString());result.addProperty("progress",progress());result.add("cases",cases);finish(result);}
    }
    private boolean accept(String name,int sourceColor,int afterColor,int skyColor,boolean colored){
        int canonical=colored&&RgbSettings.projectsGameplayLight()?Math.max(sourceColor>>8&15,Math.max(sourceColor>>4&15,sourceColor&15)):15;
        if(world.getChunk(SOURCE).getLightFor(EnumSkyBlock.BLOCK,SOURCE)!=canonical) return false;
        if(colored&&(rgb(ABSOLUTE,false)!=(RgbSettings.projectsGameplayLight()?0x840:0)||rgb(SOURCE,false)!=sourceColor||rgb(AFTER,false)!=afterColor||rgb(SKY,true)!=skyColor||rgb(STATIC_SOURCE,false)!=auxiliary))return false;
        if(requestGeneration<generation){clientCanonical=canonical;expectedSource=sourceColor;expectedAfter=afterColor;expectedSky=skyColor;clientAuxiliary=auxiliary;clientAccepted=false;requestGeneration=generation;}
        if(!clientAccepted||clientGeneration!=generation)return false;
        int checked=colored?verifyVolume():0; JsonObject row=new JsonObject();row.addProperty("independent_reference_cells",checked);row.addProperty("name",name);row.addProperty("canonical_source",canonical);
        row.addProperty("client_verified",true);if(colored){row.addProperty("source_rgb",Integer.toHexString(rgb(SOURCE,false)));
            row.addProperty("after_filter_rgb",Integer.toHexString(rgb(AFTER,false)));row.addProperty("sky_rgb",Integer.toHexString(rgb(SKY,true)));
            row.addProperty("user_override_rgb",Integer.toHexString(rgb(STATIC_SOURCE,false)));row.addProperty("absolute_api_rgb",Integer.toHexString(rgb(ABSOLUTE,false)));}
        cases.add(row);generation++;return true;
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return; var observed=net.minecraft.client.Minecraft.getMinecraft().world; if(observed!=null)clientState=observed.getBlockState(SOURCE)+" canonical="+observed.getChunk(SOURCE).getLightFor(EnumSkyBlock.BLOCK,SOURCE); if(requestGeneration<0||clientGeneration==requestGeneration)return;
        var mc=net.minecraft.client.Minecraft.getMinecraft();if(mc.world==null||mc.world.getBlockState(SOURCE).getBlock()!=source)return;
        var chunk=mc.world.getChunk(SOURCE);
        if(RgbMixinSelection.rgbEnabled()){
            if(!RgbClient.active()||!RgbClient.skyActive())return;
            RgbSnapshot block=((RgbChunk)chunk).pulsar$getRgbSnapshot(),sky=((RgbChunk)chunk).pulsar$getRgbSkySnapshot();
            if(block==null||sky==null||block.get(SOURCE.getX(),SOURCE.getY(),SOURCE.getZ())!=expectedSource
                    ||block.get(AFTER.getX(),AFTER.getY(),AFTER.getZ())!=expectedAfter
                    ||sky.get(SKY.getX(),SKY.getY(),SKY.getZ())!=expectedSky||block.get(STATIC_SOURCE.getX(),STATIC_SOURCE.getY(),STATIC_SOURCE.getZ())!=clientAuxiliary)return;
        }else if(chunk instanceof RgbChunk)throw new IllegalStateException("RGB chunk fields in SCALAR");
        if(chunk.getLightFor(EnumSkyBlock.BLOCK,SOURCE)!=clientCanonical)return;
        clientGeneration=requestGeneration;clientAccepted=true;
    }
    private int verifyVolume(){
        final int cells=16*16*8;
        int[][] block=new int[3][cells],sky=new int[3][cells];
        int[][] opacity=new int[3][cells];int[] raw=new int[cells];
        int[] dx={1,-1,0,0,0,0},dy={0,0,1,-1,0,0},dz={0,0,0,0,1,-1};
        for(int i=0;i<cells;i++){
            int x=i&15,z=i>>4&15,y=i>>8;BlockPos pos=new BlockPos(X+x,Y+y,Z+z);
            Block b=world.getBlockState(pos).getBlock();raw[i]=b==Blocks.STONE||b==staticSource?15:0;
            int color=b==source?(tile(pos).mode==0?0xF00:tile(pos).mode==1?0x00F:tile(pos).mode==3?0x840:0):b==staticSource?0x00F:0;
            int filterColor=b==filter?(tile(pos).mode==0?0x0FF:0xFF0):0;
            for(int c=0;c<3;c++){block[c][i]=color>>((2-c)*4)&15;opacity[c][i]=Math.max(raw[i],filterColor>>((2-c)*4)&15);if(y==7)sky[c][i]=15;}
        }
        for(int c=0;c<3;c++)for(int lane=0;lane<2;lane++){
            int[] values=lane==0?block[c]:sky[c];java.util.ArrayDeque<Integer> queue=new java.util.ArrayDeque<>();
            for(int i=0;i<cells;i++)if(values[i]>0)queue.add(i);
            while(!queue.isEmpty()){
                int i=queue.remove(),x=i&15,z=i>>4&15,y=i>>8,level=values[i];
                for(int d=0;d<6;d++){
                    int nx=x+dx[d],ny=y+dy[d],nz=z+dz[d];if(nx<0||nx>=16||nz<0||nz>=16||ny<0||ny>=8)continue;
                    int n=nx|nz<<4|ny<<8;
                    int next=lane==1&&dy[d]==-1&&level==15&&opacity[c][n]==0?15:Math.max(0,level-Math.max(1,opacity[c][n]));
                    if(next>values[n]){values[n]=next;queue.add(n);}
                }
            }
        }
        for(int i=0;i<cells;i++){
            int x=i&15,z=i>>4&15,y=i>>8;BlockPos pos=new BlockPos(X+x,Y+y,Z+z);
            int expectedBlock=block[0][i]<<8|block[1][i]<<4|block[2][i],expectedSky=sky[0][i]<<8|sky[1][i]<<4|sky[2][i];
            int actualBlock=rgb(pos,false),actualSky=rgb(pos,true);
            if(RgbSettings.projectsGameplayLight()){
                int cb=world.getChunk(pos).getLightFor(EnumSkyBlock.BLOCK,pos),cs=world.getChunk(pos).getLightFor(EnumSkyBlock.SKY,pos);
                int eb=Math.max(block[0][i],Math.max(block[1][i],block[2][i])),es=Math.max(sky[0][i],Math.max(sky[1][i],sky[2][i]));
                if(cb!=eb||cs!=es)throw new IllegalStateException("Canonical RGB max "+pos+" block "+cb+"/"+eb+" sky "+cs+"/"+es);
            }
            if(actualBlock!=expectedBlock||actualSky!=expectedSky)throw new IllegalStateException("Independent RGB reference "+pos+" block "+Integer.toHexString(actualBlock)+"/"+Integer.toHexString(expectedBlock)+" sky "+Integer.toHexString(actualSky)+"/"+Integer.toHexString(expectedSky));
        }
        return cells;
    }
    private void finish(JsonObject result){
        stage=-1;
        try{Path output=world.getSaveHandler().getWorldDirectory().toPath().resolve("lightbench-results/parity-audit.json");
            Files.createDirectories(output.getParent());Files.writeString(output,new GsonBuilder().setPrettyPrinting().create().toJson(result));}
        catch(Exception failure){throw new RuntimeException(failure);}
        world.getGameRules().setOrCreateGameRule("fourbench_complete","true");System.out.println("PARITY_AUDIT_FINISHED "+result);
    }
}
