package com.sumirelabs.peeraudit;

import com.google.gson.*;
import com.sumirelabs.pulsar.api.BlockLightColors;
import com.sumirelabs.pulsar.core.RgbMixinSelection;
import com.sumirelabs.pulsar.rgb.*;
import com.sumirelabs.pulsar.world.PulsarWorld;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.command.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.nio.file.*;
import java.net.InetAddress;

/** Two independent native JVMs, connected only through a loopback LAN endpoint. */
@Mod(modid="peeraudit",name="RGB Peer Audit",version="1",dependencies="required-after:pulsar",clientSideOnly=true)
public final class PeerAudit {
    private static final int X=20000,Y=80,Z=20032;
    private JsonObject config;
    private Path output;
    private boolean clientRole,connected,teleported,hostStarted;
    private volatile boolean complete;
    private int stage=-1,serverTicks,clientTicks,exitTicks;
    private WorldServer world,nether;
    private EntityPlayerMP lastPeer;
    private int clientPhase,reconnectDelay,diagnosticSends,connectionAttempts;
    private World previousWorld;
    private Object previousConnection;
    private final JsonArray cases=new JsonArray();
    private final java.util.Map<Integer,Integer> worldTickCounts=new java.util.HashMap<>();
    @Mod.EventHandler public void init(FMLInitializationEvent e)throws Exception {
        config=JsonParser.parseString(Files.readString(Minecraft.getMinecraft().gameDir.toPath().resolve("peer-role.json"))).getAsJsonObject();
        output=Path.of(config.get("output").getAsString());Files.createDirectories(output);clientRole=config.get("role").getAsString().equals("client");
        // Deterministic offline identities in these disposable JVMs; no launcher account is changed.
        String name=clientRole?"RGBPeer":"RGBHost";
        java.util.UUID id=java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        var session=new net.minecraft.util.Session(name,id.toString(),"0","legacy");
        for(var field:Minecraft.class.getDeclaredFields())if(field.getType()==net.minecraft.util.Session.class){field.setAccessible(true);field.set(Minecraft.getMinecraft(),session);}

        BlockLightColors.register(Blocks.GLOWSTONE.getDefaultState(),15,0,0);BlockLightColors.register(Blocks.SEA_LANTERN.getDefaultState(),0,0,15);MinecraftForge.EVENT_BUS.register(this);
    }
    @Mod.EventHandler public void start(FMLServerStartingEvent e){
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "peerhost";}
            public String getUsage(ICommandSender s){return "/peerhost";}
            public int getRequiredPermissionLevel(){return 0;}
            public boolean checkPermission(MinecraftServer server,ICommandSender sender){return true;}
            public void execute(MinecraftServer server,ICommandSender sender,String[] args){world=(WorldServer)sender.getEntityWorld();stage=0;}
        });
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "peerphase";}
            public String getUsage(ICommandSender s){return "/peerphase nether|overworld";}
            public int getRequiredPermissionLevel(){return 0;}
            public boolean checkPermission(MinecraftServer server,ICommandSender sender){return true;}
            public void execute(MinecraftServer server,ICommandSender sender,String[] args){
                EntityPlayerMP player=(EntityPlayerMP)sender;int dimension=args[0].equals("nether")?-1:0;
                WorldServer destination=server.getWorld(dimension);prepare(destination,dimension==-1);
                for(int cx=X>>4;cx<=(X+31)>>4;cx++)((PulsarWorld)destination).pulsar$getLightManager().forceRelightChunk(cx,Z>>4);
                server.getPlayerList().transferPlayerToDimension(player,dimension,new Teleporter(destination){
                    public void placeInPortal(net.minecraft.entity.Entity entity,float yaw){entity.setLocationAndAngles(X+12.5,Y+5,Z+12.5,180,10);}
                });
                player.connection.setPlayerLocation(X+12.5,Y+5,Z+12.5,180,10);destination.getPlayerChunkMap().updateMovingPlayer(player);
                System.out.println("PEER_PHASE_WATCH dimension="+dimension+" watchers="+destination.getPlayerChunkMap().getEntry(X>>4,Z>>4).getWatchingPlayers().size());
            }
        });
        e.registerServerCommand(new CommandBase(){
            public String getName(){return "peerack";}
            public String getUsage(ICommandSender s){return "/peerack";}
            public int getRequiredPermissionLevel(){return 0;}
            public boolean checkPermission(MinecraftServer server,ICommandSender sender){return true;}
            public void execute(MinecraftServer server,ICommandSender sender,String[] args){
                if(!sender.getName().equals("RGBPeer"))throw new IllegalArgumentException("Unexpected acknowledgement owner");
                world.getGameRules().setOrCreateGameRule("fourbench_complete","true");complete=true;stage=-1;
            }
        });
    }
    private void prepare(WorldServer target,boolean blue){
        for(int cx=(X>>4)-2;cx<=(X>>4)+3;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)target.getChunkProvider().provideChunk(cx,cz).setTerrainPopulated(true);
        for(int x=X;x<X+32;x++)for(int y=Y;y<Y+10;y++)for(int z=Z;z<Z+16;z++)target.setBlockState(new BlockPos(x,y,z),x==X||x==X+31||y==Y||y==Y+9||z==Z||z==Z+15?Blocks.STONE.getDefaultState():Blocks.AIR.getDefaultState(),2);
        target.setBlockState(new BlockPos(X+8,Y+3,Z+8),(blue?Blocks.SEA_LANTERN:Blocks.GLOWSTONE).getDefaultState(),3);
        // Manual terrain completion bypasses normal population callbacks; relight the complete halo.
        for(int cx=(X>>4)-2;cx<=(X>>4)+3;cx++)for(int cz=(Z>>4)-2;cz<=(Z>>4)+3;cz++)((PulsarWorld)target).pulsar$getLightManager().forceRelightChunk(cx,cz);
    }
    private void write(String name,JsonObject value){try {Files.writeString(output.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}catch(Exception failure){throw new RuntimeException(failure);}}
    @SubscribeEvent public void network(net.minecraftforge.fml.common.network.FMLNetworkEvent.ServerConnectionFromClientEvent event){
        if(event.isLocal())return;var channel=event.getManager().channel();
        System.out.println("PEER_PIPELINE "+channel.pipeline().names());
        if(channel.pipeline().get("encoder")==null)return;
        channel.pipeline().addAfter("encoder","peer_audit_packets",new io.netty.channel.ChannelOutboundHandlerAdapter(){
            public void write(io.netty.channel.ChannelHandlerContext ctx,Object packet,io.netty.channel.ChannelPromise promise)throws Exception {
                String kind=packet.getClass().getName();Object state=ctx.channel().attr(net.minecraft.network.NetworkManager.PROTOCOL_ATTRIBUTE_KEY).get();
                promise.addListener(f->{if(!f.isSuccess())System.out.println("PEER_SEND_FAILED packet="+kind+" state="+state+" cause="+f.cause());});super.write(ctx,packet,promise);
            }
        });
    }
    @SubscribeEvent public void worldTick(TickEvent.WorldTickEvent e){
        if(!e.world.isRemote&&e.phase==TickEvent.Phase.END)worldTickCounts.merge(e.world.provider.getDimension(),1,Integer::sum);
    }
    @SubscribeEvent public void server(TickEvent.ServerTickEvent e){
        if(clientRole||e.phase!=TickEvent.Phase.END||stage<0)return;
        try {
            if(++serverTicks>6000)throw new IllegalStateException("Peer host timeout");
            if(stage==0){
                prepare(world,false);nether=world.getMinecraftServer().getWorld(-1);prepare(nether,true);stage=1;return;
            }
            if(stage==1&&!((PulsarWorld)world).pulsar$getLightManager().hasUpdates()&&!((PulsarWorld)nether).pulsar$getLightManager().hasUpdates()){
                MinecraftServer server=world.getMinecraftServer();
                if(RgbMixinSelection.rgbEnabled()){
                    var field=RgbNetwork.class.getDeclaredField("CLIENTS");field.setAccessible(true);
                    @SuppressWarnings("unchecked") var clients=(java.util.Set<EntityPlayerMP>)field.get(null);
                    if(clients.isEmpty())return;
                    var before=new java.util.ArrayList<>(clients);
                    var missing=new EntityPlayerMP(server,world,new com.mojang.authlib.GameProfile(new java.util.UUID(0,99),"TransientRGB"),new net.minecraft.server.management.PlayerInteractionManager(world));
                    var stale=new EntityPlayerMP(server,world,new com.mojang.authlib.GameProfile(new java.util.UUID(0,100),"StaleRGB"),new net.minecraft.server.management.PlayerInteractionManager(world));
                    clients.add(missing);clients.add(stale);
                    new RgbNetwork().logout(new net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent(missing));
                    if(clients.size()!=before.size()||!clients.containsAll(before))throw new IllegalStateException("Null logout removed a live RGB peer or retained a stale peer");
                }
                // Mirror the public-LAN flag without broadcasting or binding beyond loopback.
                for(var f:net.minecraft.server.integrated.IntegratedServer.class.getDeclaredFields())if(f.getType()==boolean.class&&!java.lang.reflect.Modifier.isStatic(f.getModifiers())){
                    f.setAccessible(true);boolean before=f.getBoolean(server);f.setBoolean(server,true);if(((net.minecraft.server.integrated.IntegratedServer)server).getPublic())break;f.setBoolean(server,before);
                }
                if(!((net.minecraft.server.integrated.IntegratedServer)server).getPublic())throw new IllegalStateException("Loopback host is not public");
                server.setOnlineMode(false);server.getNetworkSystem().addEndpoint(InetAddress.getByName("127.0.0.1"),config.get("port").getAsInt());
                JsonObject ready=new JsonObject();ready.addProperty("ready",true);ready.addProperty("rgb_server",RgbMixinSelection.rgbEnabled());ready.addProperty("null_logout_keeps_live_peer",true);write("host-ready.json",ready);stage=2;return;
            }
            if(stage==2&&serverTicks%40==0){
                JsonObject progress=new JsonObject();progress.addProperty("host_paused",Minecraft.getMinecraft().isGamePaused());progress.addProperty("host_public",((net.minecraft.server.integrated.IntegratedServer)world.getMinecraftServer()).getPublic());
                for(WorldServer target:world.getMinecraftServer().worlds)if(target.playerEntities.stream().anyMatch(p->p.getName().equals("RGBPeer"))){
                    var point=new BlockPos(X+8,Y+3,Z+8);progress.addProperty("dimension",target.provider.getDimension());progress.addProperty("world_time",target.getTotalWorldTime());progress.addProperty("world_ticks",worldTickCounts.getOrDefault(target.provider.getDimension(),0));progress.addProperty("dimension_manager_same",net.minecraftforge.common.DimensionManager.getWorld(target.provider.getDimension())==target);progress.addProperty("block",target.getBlockState(point).toString());progress.addProperty("canonical",target.getLightFor(EnumSkyBlock.BLOCK,point));progress.addProperty("lighting_pending",((PulsarWorld)target).pulsar$getLightManager().hasUpdates());
                    var entry=target.getPlayerChunkMap().getEntry(X>>4,Z>>4);progress.addProperty("watchers",entry==null?-1:entry.getWatchingPlayers().size());if(entry!=null){progress.addProperty("sent",entry.isSentToPlayers());var chunk=entry.getChunk();progress.addProperty("entry_chunk_world_same",chunk!=null&&chunk.getWorld()==target);progress.addProperty("entry_chunk_loaded_same",chunk!=null&&target.getChunkProvider().getLoadedChunk(X>>4,Z>>4)==chunk);progress.addProperty("chunk_populated",chunk!=null&&chunk.isPopulated());progress.addProperty("pulsar_ready",chunk!=null&&((com.sumirelabs.pulsar.light.PulsarChunk)chunk).pulsar$isLightReady());progress.addProperty("neighbors_ready",((PulsarWorld)target).pulsar$getLightManager().areNeighboursLightReady(X>>4,Z>>4));progress.addProperty("send_ready",((PulsarWorld)target).pulsar$getLightManager().canSendUpdatedChunkLight(X>>4,Z>>4));for(var player:target.playerEntities)if(player.getName().equals("RGBPeer"))progress.addProperty("contains_peer",entry.containsPlayer((EntityPlayerMP)player));}try{JsonObject queues=new JsonObject();for(var f:net.minecraft.server.management.PlayerChunkMap.class.getDeclaredFields())if(f.getGenericType().getTypeName().contains("PlayerChunkMapEntry")&&java.util.Collection.class.isAssignableFrom(f.getType())){f.setAccessible(true);var list=(java.util.Collection<?>)f.get(target.getPlayerChunkMap());queues.addProperty(f.getName()+"_size",list.size());queues.addProperty(f.getName()+"_contains_source",list.contains(entry));}progress.add("entry_queues",queues);}catch(Exception reflection){throw new RuntimeException(reflection);}
                }
                write("server-progress.json",progress);
            }
            if(stage==2){
                for(var player:world.playerEntities)if(player.getName().equals("RGBPeer")){
                    var remote=(EntityPlayerMP)player;if(remote==lastPeer)continue;lastPeer=remote;remote.setGameType(GameType.SPECTATOR);remote.connection.setPlayerLocation(X+12.5,Y+5,Z+12.5,180,10);world.getPlayerChunkMap().updateMovingPlayer(remote);teleported=true;System.out.println("PEER_TELEPORT dimension="+remote.dimension+" x="+remote.posX+" y="+remote.posY+" z="+remote.posZ);
                }
            }
        }catch(Throwable failure){failure.printStackTrace();JsonObject report=new JsonObject();report.addProperty("valid",false);report.addProperty("failure",failure.toString());write("host-failure.json",report);world.getGameRules().setOrCreateGameRule("fourbench_complete","true");complete=true;stage=-1;}
    }
    @SubscribeEvent public void client(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;Minecraft mc=Minecraft.getMinecraft();
        if(!clientRole){
            if(mc.world!=null&&mc.currentScreen!=null)mc.displayGuiScreen(null);
            if(complete){if(++exitTicks>=20)mc.shutdown();return;}
            if(!hostStarted&&mc.world==null&&mc.currentScreen instanceof GuiMainMenu&&++clientTicks>10){hostStarted=true;mc.displayGuiScreen(null);mc.launchIntegratedServer("Bench Updates","Bench Updates",null);}
            return;
        }
        if(complete){if(++exitTicks>=20)mc.shutdown();return;}
        try {
            if(++clientTicks>6000)throw new IllegalStateException("Peer client timeout, active="+RgbClient.active());
            if(clientTicks%40==0){
                JsonObject progress=new JsonObject();progress.addProperty("phase",clientPhase);progress.addProperty("active",RgbClient.active());progress.addProperty("connected",connected);
                if(mc.world!=null){progress.addProperty("dimension",mc.world.provider.getDimension());progress.addProperty("block",mc.world.getBlockState(new BlockPos(X+8,Y+3,Z+8)).toString());progress.addProperty("canonical",mc.world.getLightFor(EnumSkyBlock.BLOCK,new BlockPos(X+8,Y+3,Z+8)));}
                if(mc.player!=null){progress.addProperty("x",mc.player.posX);progress.addProperty("y",mc.player.posY);progress.addProperty("z",mc.player.posZ);}
                write("peer-progress.json",progress);
            }
            if(reconnectDelay>0){--reconnectDelay;return;}
            if(connected&&mc.world==null&&mc.currentScreen instanceof net.minecraft.client.gui.GuiDisconnected){
                if(connectionAttempts>=6)throw new IllegalStateException("Native login failed six connection attempts");
                System.out.println("PEER_UNASSISTED_LOGIN_RETRY attempt="+connectionAttempts);
                connected=false;reconnectDelay=40;return;
            }
            if(!connected){connected=true;connectionAttempts++;mc.displayGuiScreen(new GuiConnecting(new GuiMainMenu(),mc,"127.0.0.1",config.get("port").getAsInt()));return;}
            if(mc.world==null||mc.player==null)return;
            int dimension=clientPhase==1?-1:0;boolean blue=dimension==-1;
            if(mc.world.provider.getDimension()!=dimension||clientPhase>0&&mc.world==previousWorld)return;
            if(mc.world.getBlockState(new BlockPos(X+8,Y+3,Z+8)).getBlock()!=(blue?Blocks.SEA_LANTERN:Blocks.GLOWSTONE))return;
            boolean expected=config.get("expected_rgb").getAsBoolean();if(RgbClient.active()!=expected)return;
            int canonical=config.has("zero_source")&&config.get("zero_source").getAsBoolean()&&!blue?0:15;
            if(mc.world.getLightFor(EnumSkyBlock.BLOCK,new BlockPos(X+8,Y+3,Z+8))!=canonical)return;
            boolean authority=config.has("expected_authority")&&config.get("expected_authority").getAsBoolean();
            if(com.sumirelabs.pulsar.rgb.CanonicalLightClient.active(mc.world)!=authority)return;
            int tint=RgbClient.tintAbgr(-1,X+9.5,Y+3.5,Z+8.5);
            if(expected&&canonical!=0&&(blue?((tint>>>16&255)<200||(tint&255)>100):((tint&255)<200||(tint>>>8&255)>100)))return;
            JsonObject sample=new JsonObject();sample.addProperty("phase",clientPhase);sample.addProperty("dimension",dimension);sample.addProperty("tint",Integer.toHexString(tint));sample.addProperty("canonical_source",canonical);sample.addProperty("canonical_authority",authority);sample.addProperty("active",RgbClient.active());cases.add(sample);
            if(clientPhase<3){
                previousWorld=mc.world;previousConnection=mc.getConnection();
                if(clientPhase==0)mc.player.sendChatMessage("/peerphase nether");
                else if(clientPhase==1)mc.player.sendChatMessage("/peerphase overworld");
                else {mc.world.sendQuittingDisconnectingPacket();mc.loadWorld(null);mc.displayGuiScreen(new GuiMainMenu());connected=false;reconnectDelay=40;}
                ++clientPhase;return;
            }
            if(mc.getConnection()==previousConnection)throw new IllegalStateException("Rejoin reused the old connection");
            JsonObject report=new JsonObject();report.addProperty("valid",true);report.addProperty("rgb_client_config",RgbMixinSelection.rgbEnabled());report.addProperty("rgb_channel_active",RgbClient.active());report.addProperty("expected_rgb",expected);report.addProperty("canonical_source",canonical);report.addProperty("canonical_authority",authority);report.addProperty("test_only_login_state_workaround",false);report.addProperty("sample_tint",Integer.toHexString(tint));report.addProperty("rgb_buffer_fields",new net.minecraft.client.renderer.BufferBuilder(256) instanceof RgbDynamicVertices);report.addProperty("connection_attempts",connectionAttempts);report.addProperty("connected_remote",!mc.isIntegratedServerRunning());report.addProperty("test_only_initial_send_retry",false);report.add("world_transitions",cases);report.addProperty("rejoin_new_connection",true);write("peer-result.json",report);
            mc.player.sendChatMessage("/peerack");complete=true;
        }catch(Throwable failure){failure.printStackTrace();JsonObject report=new JsonObject();report.addProperty("valid",false);report.addProperty("failure",failure.toString());write("peer-result.json",report);complete=true;}
    }
}


