param([string]$Run,[ValidateSet('RGB','SCALAR')][string]$HostMode='RGB',[ValidateSet('RGB','SCALAR')][string]$ClientMode='SCALAR',[string]$Artifact='parity-absolute.jar')
$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
$prism='C:/Users/s12kuma01/AppData/Roaming/PrismLauncher/instances'
$prefix='Pulsar-RGB-PeerFinal077-20261018'
$out="$root/peers/$Run"
if($Run -notmatch '^[a-z0-9-]+$' -or (Test-Path $out)){throw 'Invalid or existing final peer run'}
New-Item -ItemType Directory $out | Out-Null
function Owned([string]$role){@(Get-CimInstance Win32_Process -Filter "Name='javaw.exe'" | Where-Object CommandLine -like "*$prefix-$role*")}
function Stage([string]$role,[string]$mode){
 $instance="$prism/$prefix-$role";$game="$instance/minecraft"
 if((Owned $role).Count){throw 'Owned peer still running'}
 if(-not(Test-Path $instance)){
  $staged="C:/Users/s12kuma01/AppData/Local/Temp/$prefix-$role-stage"
  if(Test-Path $staged){throw 'Existing peer staging directory'}
  New-Item -ItemType Directory $staged | Out-Null
  foreach($file in @('instance.cfg','mmc-pack.json')){Copy-Item "$prism/Pulsar-RGB-Parity-20261018/$file" "$staged/$file"}
  if([IO.Path]::GetFullPath($staged) -ne [IO.Path]::GetFullPath("C:/Users/s12kuma01/AppData/Local/Temp/$prefix-$role-stage") -or [IO.Path]::GetFullPath($instance) -ne [IO.Path]::GetFullPath("$prism/$prefix-$role")){throw 'Unexpected peer staging move'}
  Move-Item -LiteralPath $staged -Destination $instance
 }
 if(Test-Path $game){
  if([IO.Path]::GetFullPath($game) -ne [IO.Path]::GetFullPath("$instance/minecraft")){throw 'Unexpected peer backup path'}
  Rename-Item -LiteralPath $game -NewName "minecraft-backup-$Run"
 }
 New-Item -ItemType Directory -Force "$game/mods","$game/config" | Out-Null
 Copy-Item "$root/common-mods/*" "$game/mods" -Recurse
 foreach($name in @('-cleanroom-relauncher-1.1.2.jar','+Fugue-0.24.3.jar','-Red-Core-MC-1.8-1.12-0.7.1.jar','Bubbles-2.4.10.jar','Thaumcraft-1.12.2-6.1.BETA26.jar','Fluidlogged-API-v3.3.3-mc1.12.2.jar')){
  $path=Join-Path "$game/mods" $name;if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path}
 }
 Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/-cleanroom-relauncher-1.2.1.jar' "$game/mods/!cleanroom-relauncher-1.2.1.jar"
 Copy-Item 'E:/Github/Pulsar-Issue22-20261017/artifacts/platform077/+Fugue-0.25.4.jar' "$game/mods/+Fugue-0.25.4.jar"
 Copy-Item "$root/frozen/config/*" "$game/config" -Recurse
 Copy-Item "$root/frozen/options.txt" "$game/options.txt"
 Copy-Item "$root/artifacts/$Artifact" "$game/mods/pulsar.jar"
 Copy-Item "$root/artifacts/peer-audit-retry-diagnostic.jar" "$game/mods/peer-audit.jar"
 $config=@{selectedVersion='0.7.7-alpha';latestVersion='0.7.7-alpha';javaPath='C:/Program Files/Eclipse Adoptium/jdk-25.0.4.101-hotspot/bin/javaw.exe';args='-XX:+UseCompactObjectHeaders -Dpulsar.rgb.packed=true -Djdk.net.unixdomain.tmpdir=E:/Github/Pulsar';autoSetup=$true;enableRelauncher=$true;fetchUpdates=$false;clearCleanroomFolder=$false;clearJavaProvisionFolder=$false;darkMode=$false;targetJavaVersion=25}
 $config|ConvertTo-Json|Set-Content "$game/config/relauncher.json" -Encoding UTF8
 $cfg=Get-Content "$game/config/pulsar.cfg" -Raw
 $cfg=[regex]::Replace($cfg,'(?m)^\s*S:(lightingMode|rgbGameplayLight)=.*$','')
 [IO.File]::WriteAllText("$game/config/pulsar.cfg",$cfg.Replace('general {',"general {`n    S:lightingMode=$mode`n    S:rgbGameplayLight=RGB_MAX"))
 if($role -eq 'host' -and $HostMode -eq 'RGB'){[IO.File]::WriteAllText("$game/config/pulsar-colors.cfg","minecraft:glowstone = 0, 0, 0`n")}
 $authority=$HostMode -eq 'RGB'
 $data=@{role=$role;port=25391;output=$out;expected_rgb=($HostMode -eq 'RGB' -and $ClientMode -eq 'RGB');expected_authority=$authority;zero_source=$authority}
 [IO.File]::WriteAllText("$game/peer-role.json",($data|ConvertTo-Json))
 if($role -eq 'host'){
  New-Item -ItemType Directory -Force "$game/saves" | Out-Null
  Copy-Item "$root/templates/flat" "$game/saves/Bench Updates" -Recurse
  & node "$root/phase9/world.cjs" "$game/saves/Bench Updates" candidate updates $Run peerhost
  if($LASTEXITCODE -ne 0){throw 'Peer world setup failed'}
 }
}
Stage host $HostMode
Stage client $ClientMode
[IO.File]::WriteAllText("$out/stage.json",(@{platform='0.7.7-alpha';host_mode=$HostMode;client_mode=$ClientMode;gameplay='RGB_MAX';test_only_login_state_workaround=$false;artifact_sha256=(Get-FileHash "$root/artifacts/$Artifact").Hash;helper_sha256=(Get-FileHash "$root/artifacts/peer-audit-retry-diagnostic.jar").Hash}|ConvertTo-Json))
$launcher='C:/Users/s12kuma01/AppData/Local/Programs/PrismLauncher/prismlauncher.exe'
Start-Process $launcher -ArgumentList '-l',"$prefix-host",'--offline','RGBHost' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(4)
while(-not(Test-Path "$out/host-ready.json")){
 if(Test-Path "$out/host-failure.json"){throw 'Final peer host failed'}
 if([DateTime]::UtcNow -gt $deadline){throw 'Final peer host timed out; preserved'}
 Start-Sleep -Seconds 2
}
Start-Process $launcher -ArgumentList '-l',"$prefix-client",'--offline','RGBPeer' -WindowStyle Hidden
$deadline=[DateTime]::UtcNow.AddMinutes(6);$seen=$false
while([DateTime]::UtcNow -lt $deadline){
 Start-Sleep -Seconds 2
 if((Owned client).Count){$seen=$true}
 if($seen -and -not(Owned client).Count -and -not(Owned host).Count){break}
}
if((Owned client).Count -or (Owned host).Count){throw 'Final peer run timed out; preserved'}
foreach($role in @('host','client')){Copy-Item "$prism/$prefix-$role/minecraft/logs/latest.log" "$out/$role.log"}
$result=Get-Content "$out/peer-result.json" -Raw|ConvertFrom-Json
if(-not $result.valid -or -not $result.connected_remote){throw 'Final peer verification failed'}
Write-Output "Final peer $Run valid=True"
