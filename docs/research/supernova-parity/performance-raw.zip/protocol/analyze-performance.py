from pathlib import Path
import json,statistics,math
root=Path('E:/Github/Pulsar-RGB-20261016');server=[];client=[]
def interval(a,b):
 values=[math.log(y/x) for x,y in zip(a,b)];average=statistics.mean(values);margin=3.182446*statistics.stdev(values)/2
 return {'paired_geometric_change_percent':100*math.expm1(average),'t95_interval_percent':[100*math.expm1(average-margin),100*math.expm1(average+margin)],'pairs':4,'before_median_of_means':statistics.median(a),'after_median_of_means':statistics.median(b),'statistical_unit':'independent JVM mean'}
for mode,variants in [('scalar',['before','final']),('rgb',['reference','packed'])]:
 for variant in variants:
  for i in range(1,5):
   name=f'parity-perf-scalar-server-{variant}-{i}' if mode=='scalar' else f'parity-packed-perf-max-rgb-server-{variant}-{i}'
   folder=root/'runs'/name;assert json.loads((folder/'status.json').read_text())['valid'],name
   files=list((folder/'results').glob('*-updates-*.json'));assert len(files)==1,name
   data=json.loads(files[0].read_text())['benchmark'];phases={}
   for phase in data['phases']:
    assert phase['sample_count']==1000 and phase['all_samples_verified'],(name,phase['name'])
    assert all(x['light_verified'] for x in phase['samples']),(name,phase['name'])
    phases[phase['name']]=phase['completion_summary_nanos']
   server.append({'run':name,'mode':mode,'variant':variant,'index':i,'phases':phases,'gc':data['measurement_gc']})
server_summary={}
for mode,before,after in [('scalar','before','final'),('rgb','reference','packed')]:
 server_summary[mode]={}
 for phase in ['block_place','block_remove','sky_remove','sky_place']:
  a=[next(x for x in server if (x['mode'],x['variant'],x['index'])==(mode,before,i))['phases'][phase]['average']/1000 for i in range(1,5)]
  b=[next(x for x in server if (x['mode'],x['variant'],x['index'])==(mode,after,i))['phases'][phase]['average']/1000 for i in range(1,5)]
  server_summary[mode][phase]=interval(a,b)
for mode,variants in [('scalar',['before','final']),('rgb',['final'])]:
 for variant in variants:
  for i in range(1,5):
   name=f'parity-perf-scalar-client-{variant}-{i}' if mode=='scalar' else f'parity-packed-perf-max-rgb-client-{variant}-{i}'
   data=json.loads((root/'runs'/name/'results/render-perf.json').read_text())
   assert data['valid'] and len(data['frame_ns'])==1200 and len(data['render_thread_allocated_bytes'])==1200,name
   values=sorted(data['frame_ns'])
   client.append({'run':name,'mode':mode,'variant':variant,'index':i,'mean_ms':statistics.mean(values)/1e6,'p95_ms':values[math.ceil(.95*len(values))-1]/1e6,'allocated_bytes_per_frame':statistics.mean(data['render_thread_allocated_bytes']),'gc_collections':data['jvm_gc_collections'],'entities':data['entity_render_debug'],'particles':data['particle_render_debug']})
client_summary={}
for metric in ['mean_ms','allocated_bytes_per_frame']:
 a=[next(x[metric] for x in client if (x['mode'],x['variant'],x['index'])==('scalar','before',i)) for i in range(1,5)]
 b=[next(x[metric] for x in client if (x['mode'],x['variant'],x['index'])==('scalar','final',i)) for i in range(1,5)]
 client_summary[metric]=interval(a,b)
result={'server_records':server,'server_comparisons':server_summary,'client_records':client,'scalar_client_comparisons':client_summary,'server_time_unit':'microseconds to verified completion; includes async wait','client_interval':'FML RenderTick START-to-END; not full-frame FPS','allocation':'Java render-thread allocation; not retained memory','rgb_client_comparison':'Four final RGB JVMs reported descriptively; RGB and SCALAR have different rendering work.'}
(root/'phase9/performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'server':server_summary,'scalar_client':client_summary},indent=2))
