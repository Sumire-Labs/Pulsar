$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function MeasureLightingRun([string]$mode,[string]$kind,[string]$variant,[int]$index,[string]$artifact){
 $name=if($mode -eq 'RGB'){"parity-packed-perf-max-rgb-$kind-$variant-$index"}else{"parity-perf-scalar-$kind-$variant-$index"}
 [IO.File]::WriteAllText("$root/phase9/perf-progress.json",(@{stage='timing';run=$name;started=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
 $command=if($kind -eq 'server'){'lightbench updates 2000 1000'}else{'renderperf 600 1200 64 1024'}
 & "$root/phase9/runperf.ps1" -Run $name -Artifact $artifact -Mode $mode -Command $command
 if($LASTEXITCODE -ne 0 -or -not((Get-Content "$root/runs/$name/status.json" -Raw|ConvertFrom-Json).valid)){throw "Performance run failed: $name"}
}
# JVM, not individual block edits/frames, is the independent statistical unit.
foreach($pair in @(1,3)){
 MeasureLightingRun SCALAR server before $pair deferred-only.jar
 MeasureLightingRun SCALAR server final $pair parity-defaults.jar
 MeasureLightingRun SCALAR server final ($pair+1) parity-defaults.jar
 MeasureLightingRun SCALAR server before ($pair+1) deferred-only.jar
}
foreach($pair in @(1,3)){
 MeasureLightingRun RGB server reference $pair parity-defaults.jar
 MeasureLightingRun RGB server packed $pair parity-defaults.jar
 MeasureLightingRun RGB server packed ($pair+1) parity-defaults.jar
 MeasureLightingRun RGB server reference ($pair+1) parity-defaults.jar
}
foreach($pair in @(1,3)){
 MeasureLightingRun SCALAR client before $pair deferred-only.jar
 MeasureLightingRun SCALAR client final $pair parity-defaults.jar
 MeasureLightingRun SCALAR client final ($pair+1) parity-defaults.jar
 MeasureLightingRun SCALAR client before ($pair+1) deferred-only.jar
}
foreach($index in 1..4){MeasureLightingRun RGB client final $index parity-defaults.jar}
[IO.File]::WriteAllText("$root/phase9/perf-progress.json",'{"stage":"complete"}')
