import sys
sys.path.insert(0,'E:/Github/Pulsar-RGB-20261016/tools/plotpackages')
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('C:/Users/s12kuma01/.codex/worktrees/rgb-completion/Pulsar/docs/research/supernova-parity')
d=json.loads((out/'performance.json').read_text())['server_comparisons']
fig,axes=plt.subplots(1,2,figsize=(11,4.4),layout='constrained')
keys=['block_place','block_remove','sky_remove','sky_place'];labels=['Block placement','Block removal','Sky opening','Sky closing']
for ax,mode,title,color in [(axes[0],'scalar','SCALAR: final vs baseline','#2787bd'),(axes[1],'rgb','RGB: packed vs three passes','#32965e')]:
 values=[d[mode][k]['paired_geometric_change_percent'] for k in keys]
 lows=[v-d[mode][k]['t95_interval_percent'][0] for k,v in zip(keys,values)]
 highs=[d[mode][k]['t95_interval_percent'][1]-v for k,v in zip(keys,values)]
 ax.errorbar(values,range(4),xerr=[lows,highs],fmt='o',color=color,capsize=5,markersize=7)
 ax.axvline(0,color='#69737c',linestyle='--',linewidth=1)
 ax.set_yticks(range(4),labels);ax.invert_yaxis();ax.set_xlim(-38,34)
 ax.set_xlabel('Completion time change (%) — lower is faster')
 ax.set_title(title,fontweight='bold');ax.grid(axis='x',alpha=.2)
fig.suptitle('Verified lighting updates: 4 paired independent JVMs\nPoints: geometric change; bars: 95% t intervals',fontsize=13)
fig.savefig(out/'server-performance.png',dpi=180,facecolor='white')
