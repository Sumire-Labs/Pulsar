$ErrorActionPreference='Stop'
$root='E:/Github/Pulsar-RGB-20261016'
function MeasureRetestRun([string]$mode,[string]$variant,[int]$index,[string]$artifact){
 $name=if($mode -eq 'RGB'){"parity-final2-max-rgb-server-$variant-$index"}else{"parity-final2-scalar-server-$variant-$index"}
 [IO.File]::WriteAllText("$root/phase9/retest-progress.json",(@{stage='timing';run=$name;started=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
 & "$root/phase9/runperf.ps1" -Run $name -Artifact $artifact -Mode $mode -Command 'lightbench updates 10000 3000'
 if($LASTEXITCODE -ne 0 -or -not((Get-Content "$root/runs/$name/status.json" -Raw|ConvertFrom-Json).valid)){throw "Retest failed: $name"}
}
foreach($pair in @(1,3)){
 MeasureRetestRun SCALAR before $pair deferred-only.jar
 MeasureRetestRun SCALAR bytes $pair parity-bytes.jar
 MeasureRetestRun SCALAR bytes ($pair+1) parity-bytes.jar
 MeasureRetestRun SCALAR before ($pair+1) deferred-only.jar
}
foreach($pair in @(1,3)){
 MeasureRetestRun RGB reference $pair parity-bytes.jar
 MeasureRetestRun RGB packed $pair parity-bytes.jar
 MeasureRetestRun RGB packed ($pair+1) parity-bytes.jar
 MeasureRetestRun RGB reference ($pair+1) parity-bytes.jar
}
[IO.File]::WriteAllText("$root/phase9/retest-progress.json",'{"stage":"complete"}')
